import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import updateAccInfo from "@salesforce/apex/Epos.updateAccInfo";
import insertNewAcc from "@salesforce/apex/Epos.insertNewAcc";
import insertContact from "@salesforce/apex/Epos.insertContact";
import getDependentMap from "@salesforce/apex/Epos.getDependentMap";
import createNewAddress from "@salesforce/apex/Epos.createNewAddress";

export default class EposAccount extends LightningElement {

    @api order;
    @api accountid;
    @api accountname;
    @api contactname;
    @api contactid;
    copyOrderForSave;
    accProfileFilter = " AND Record_Type_Name__c ='Customer'";
    ordProfileFilter = " AND Record_Type_Name__c ='Order_Profile'";
    errorMsg;
		companyName;
    showUpdateAccInfo = false;
    isCreateNewAccount = false;
    newAccError;
    addressToInsert = { Customer__r: { Id: '', Name: '' }, Contact__r: { Id: '', Name: '' }, Is_Billing_Address__c: false, Is_Shipping_Address__c: false, Primary__c: false };
   // disableCreateAcc = true;
  //  spinner = false;
    isCreateNewContact = false;
    newConError;
    disableCreateCon = true;
    conToInsert = { Account: { Id: '', Name: '' } };
    ConAccFilter = "Account_Type__c ='Customer'";
    //disableCreateCon = true;

    newAddError;
    isCreateNewAddress = false;
    addressToInsert = { Customer__r: { Id: '', Name: '' }, Contact__r: { Id: '', Name: '' } };
    disableCreateAdd = true;
    AddConFilter = " AND AccountId ='" + this.accountid + "'";
    disableAddCon = true;

    depnedentFieldMap;
    listControllingValues;
    bDisabledDependentFld = true;
    listDependingValues;
    showCompanyEdit = false;
 @track accToInsert = {
        Name: '',
        Account_Profile__c: '',
        Account_Profile__r: { Id: '' },
        Order_Profile__c: '',
        Order_Profile__r: { Id: '' },
		 		Company__c: '',
        Company__r: { Id: '' },
        Phone: '',
        Fax: '',
        Website: ''
    };
    @track disableCreateAcc = true;
    @track newAccError;
    spinner = false;


    handleAccComp(event) {
        try {
            console.log('copyOrderForSave:', this.copyOrderForSave);
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Company__c = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }

    connectedCallback() {
        console.log('Component connected to the DOM');
        if (//this.order.Account.Company__r.name
            this.order &&
            this.order.Account &&
            this.order.Account.Company__c 
        ) {
						console.log(this.order.Account);
           // this.companyName = this.order.Account.Company__r.name;
        } else {
            // Handle undefined by setting a default name
            this.companyName = 'No Company';
        }
    }

    selectAccount(event) {
        this.accToInsert.Company__c = event.detail.Id;
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Company__c = event.detail.Id;
            this.copyOrderForSave.Account.Company__r.Id = event.detail.Id;
            this.copyOrderForSave.Account.Company__r.name = event.detail.name;
            this.accountSelected = this.order.Account.Company__c ? true : false;
            this.showUpdateAccInfo = true;
						
        } catch (e) { console.log('Error:', e); 
 }
    }
    handleRefreshComponent(event) {
        //this.order.Account.Company__c = event.detail.Id;
        this.showCompanyEdit = false;
    }

    handleAccURL(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Website = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }

    handleAccPhone(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Phone = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }

    }

    handleAccFax(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Fax = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }

    companyEdit(event) {
        this.showCompanyEdit = true;
    }


    removeAccProfile(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Account_Profile__c = undefined;
            this.showUpdateAccInfo = true;
            this.accProfileSelected = this.order.Account.Account_Profile__c ? true : false;
        } catch (e) { console.log('Error:', e); }
    }

    selectAccProfile(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.Account_Profile__c = event.detail.Id;
            this.copyOrderForSave.Account.Account_Profile__r.Id = event.detail.Id;
            this.copyOrderForSave.Account.Account_Profile__r.name = event.detail.name;
            this.accProfileSelected = this.order.Account.Account_Profile__c ? true : false;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }
    accProfileSelected = false;
    /*get accProfileSelected() {
        if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
        return this.copyOrderForSave.Account.Account_Profile__c ? true : false;
    }*/
    get accProfileUrl() {
        if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
        return '/' + this.copyOrderForSave.Account_Profile__c;
    }

    handleAccNo(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.AccountNumber = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }
    handleTaxReg(event) {
        try {
            if (!this.copyOrderForSave) this.copyOrderForSave = JSON.parse(JSON.stringify(this.order));
            this.copyOrderForSave.Account.VAT_registration_number__c = event.currentTarget.value;
            this.showUpdateAccInfo = true;
        } catch (e) { console.log('Error:', e); }
    }

    updateAccountInfo() {
        this.errorMsg = undefined;
        console.log('Account:', this.copyOrderForSave.Account);
        if(!this.copyOrderForSave.Account.Id) this.copyOrderForSave.Account.Id = this.order.Account.Id;
        if(!this.copyOrderForSave.Account.Name) this.copyOrderForSave.Account.Name = this.order.Account.Name;
        this.spinner = true;
        updateAccInfo({
            acc: JSON.stringify(this.copyOrderForSave.Account),
        })
            .then(result => {
                console.log('result:', result);
                if (result.includes('Account updated successfully')) {
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: result,
                    });
                    this.dispatchEvent(event);
                    this.spinner = false;
                    this.showUpdateAccInfo = false;
                    this.showCompanyEdit = false;
                } else {
                    this.errorMsg = result;
                    this.spinner = false;
                }
            })
            .catch(error => {
                console.log("Error:", error);
                this.spinner = false;
                this.errorMsg = error.body.message + '  Line:' + error.body.stackTrace;
            })
    }

    openCreateNewAccModal() {
        this.spinner = true;
        this.newAccError = undefined;
        this.accToInsert = { Account_Profile__r: { Id: '', Name: '' }, Order_Profile__r: { Id: '', Name: '' }, Company__r: { Id: '', Name: '' } };
        //this.accToInsert.Account_Profile__r = { Id: '', Name: '' }
        //this.accToInsert.Order_Profile__r = { Id: '', Name: '' }
        this.isCreateNewAccount = true;
        this.spinner = false;
    }

    closeCreateNewAccModal() {
        this.isCreateNewAccount = false;
    }

    handleNewAccName(event) {
        this.accToInsert.name = event.currentTarget.value;
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.id != ""? false : true;
    }

    handleNewAccNumber(event) {
        this.accToInsert.AccountNumber = event.currentTarget.value;
    }

    removeNewAccProfile(event) {
        this.accToInsert.Account_Profile__c = null;
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != "" ? false : true;
    }
    selectNewAccProfile(event) {
        this.accToInsert.Account_Profile__c = event.detail.Id;
				this.accToInsert.Account_Profile__r.Id = event.detail.Id;
        //this.accToInsert.Account_Profile__r = { Id: event.detail.Id, Name: event.detail.name };
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != "" ? false : true;
    }
    get NewAccProfileSelected() {
        return this.accToInsert.Account_Profile__c ? true : false;
    }
    get NewAccProfileUrl() {
        return '/' + this.accToInsert.Account_Profile__c;
    }

    removeNewOrdProfile() {
        this.accToInsert.Order_Profile__c = null;
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != ""? false : true;
    }
    selectNewOrdProfile(event) {
        this.accToInsert.Order_Profile__c = event.detail.Id;
				this.accToInsert.Order_Profile__r.Id = event.detail.Id;
        //this.accToInsert.Order_Profile__r = { Id: event.detail.Id, Name: event.detail.name };
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != ""? false : true;
    }
		removeNewCompany() {
        this.accToInsert.Company__c = null;
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != ""? false : true;
    }
    selectNewCompany(event) {
        this.accToInsert.Company__c = event.detail.Id;
				this.accToInsert.Company__r.Id = event.detail.Id;
        //this.accToInsert.Company__r = { Id: event.detail.Id, Name: event.detail.name };
        this.disableCreateAcc = this.accToInsert.name && this.accToInsert.name != '' && this.accToInsert.Account_Profile__c && this.accToInsert.Account_Profile__r.id != "" && this.accToInsert.Order_Profile__c && this.accToInsert.Order_Profile__r.Id != '' && this.accToInsert.Company__c && this.accToInsert.Company__r.Id != ""? false : true;
    }
    get NewAccOrdProfileSel() {
        return this.accToInsert.Order_Profile__c ? true : false;
    }
    get NewOrdProfileUrl() {
        return '/' + this.accToInsert.Order_Profile__c;
    }

    handleNewAccEmail(event) {
        this.accToInsert.Email__c = event.currentTarget.value;
        const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (!this.accToInsert.Email__c.match(emailRegex)) {
            this.newAccError = 'Enter a valid email address';
        } else {
            this.newAccError = undefined;
        }
    }

    handleNewAccPhone(event) {
        this.accToInsert.Phone = event.currentTarget.value;
    }

    handleNewAccFax(event) {
        this.accToInsert.Fax = event.currentTarget.value;
    }

    handleNewAccCompany(event) {
        this.accToInsert.Company__c = event.currentTarget.value;
    }

    handleNewAccWebsite(event) {
        this.accToInsert.Website = event.currentTarget.value;
    }

    handleNewAccVAT(event) {
        this.accToInsert.VAT_registration_number__c = event.currentTarget.value;
    }
    handleNewAccDes(event) {
        this.accToInsert.Description = event.currentTarget.value;
    }
    handleNewAccIsPer(event) {
        this.accToInsert.Is_Person_Account__c = event.detail.checked;
    }
 validateFields() {
        const phoneFaxRegex = /^[0-9]{10}$/; // Adjust as needed
        const websiteRegex = /^(https?:\/\/)?(www\.)?([\w-]+\.)+[\w-]{2,4}(\/.*)?$/;

        this.disableCreateAcc = !(
            this.accToInsert.name &&
            this.accToInsert.name !== '' &&
            this.accToInsert.Account_Profile__c &&
            this.accToInsert.Account_Profile__r.Id !== '' &&
            this.accToInsert.Order_Profile__c &&
            this.accToInsert.Order_Profile__r.Id !== '' &&
            phoneFaxRegex.test(this.accToInsert.Phone) &&
            phoneFaxRegex.test(this.accToInsert.Fax) &&
						websiteRegex.test(this.accToInsert.Website) &&
						this.order &&
						this.order.Account &&
						this.order.Account.Company__r &&
						this.order.Account.Company__r.name !== ''

        );
    }

    // Handle input changes and validate fields
    handleInputChange(event) {
        const field = event.target.name;
        this.accToInsert[field] = event.target.value;
        this.validateFields(); // Call validation on input change
    }

    newAccountSave() {
				 if (this.disableCreateAcc) {
            return; // Prevent saving if disableCreateAcc is true
        }

        try {
            this.newAccError = undefined;
            console.log('Account:', JSON.stringify(this.accToInsert));

            if (!this.accToInsert.name || this.accToInsert.name == "") {
                this.newAccError = 'Name Missing';
                return;
            }

            if (!this.accToInsert.Account_Profile__c || this.accToInsert.Account_Profile__r.Id == "") {
                this.newAccError = 'Account Profile Missing';
                return;
            }

            if (!this.accToInsert.Order_Profile__c || this.accToInsert.Order_Profile__r.Id == "") {
                this.newAccError = 'Order Profile Missing';
                return;
            }
					/*	if (!this.accToInsert.Company__c || this.accToInsert.Company__c.Id == "") {
                this.newAccError = 'company is missing';
                return;
            }*/


           /* if (this.accToInsert.Email__c != "") {
                const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if (!this.accToInsert.Email__c.match(emailRegex)) {
                    this.newAccError = 'Enter a valid email address';
                    return;
                }
            }
    
            if (this.accToInsert.Phone != "") {
                const phoneRegex = /^\+?[1-9]\d{0,14}$/;
                if (!this.accToInsert.Phone.match(phoneRegex)) {
                    this.newAccError = 'Please enter a valid Phone Number';
                    return;
                }
            }
    
            if (this.accToInsert.Website == "") {
                const WebUrlRegex = /https?:\/\/.+/;
                if (!this.accToInsert.Website.match(WebUrlRegex)) {
                    this.newAccError = 'Please enter a valid URL';
                    return;
                }
            }*/
            console.log('before insertNewAcc:');
            this.spinner = true;
            insertNewAcc({
                acc: JSON.stringify(this.accToInsert),
            })
                .then(result => {
                    console.log('result:', result);
                    if (!result.includes('Line No:')) {
                        this.accountid = result;
                        const event = new ShowToastEvent({
                            variant: 'success',
                            message: 'Account Created successfully',
                        });
                        this.dispatchEvent(event);
                        const accCreatedEvent = new CustomEvent('accountcreated', {
                            detail: { Id: result }
                        });
                        this.dispatchEvent(accCreatedEvent);
                        this.spinner = false;
                        this.isCreateNewAccount = false;
                        this.accountname = this.accToInsert.name;
                        this.accountid = result;
                    } else {
                        this.newAccError = result;
                        this.spinner = false;
                    }
                })
                .catch(error => {
                    console.log("Error:", error);
                    this.spinner = false;
                    this.newAccError = error.body.message + '  Line:' + error.body.stackTrace;
                })

        }
        catch (e) { console.log('new Account Save error:', e); }
    }

    openCreateNewConModal() {

        console.log('this.AccountId::~>', this.accountid);
        console.log('this.accountname Contact Create Model 1:', this.accountname);
        if (this.accountid == '' || this.accountid == null || this.accountid == undefined) {

            console.log("Account Id is not Exist::");
            this.newConError = 'Select Account to create a contact';
            const event = new ShowToastEvent({
                title: 'Warning!',
                variant: 'warning',
                message:
                    'Please select an Account to create a contact',
            });
            this.dispatchEvent(event);
        }
        else {
            this.spinner = true;
            this.newConError = undefined;
            this.conToInsert = { Account: { Id: '', Name: '' } };
            this.isCreateNewContact = true;
            this.spinner = false;
            this.conToInsert.AccountId = this.accountid;
            this.conToInsert.Account.Id = this.accountid;
            console.log('this.accountname Contact Create Model 2:', this.accountname);
            this.conToInsert.Account.Name = this.accountname;

        }

    }

    closeCreateNewConModal() {
        this.isCreateNewContact = false;
    }

    removeNewConAcc(event) {
        this.conToInsert.AccountId = null;
        this.conToInsert.Account.name = null;
        this.disableCreateCon = this.conToInsert.AccountId && this.conToInsert.LastName && this.conToInsert.LastName != "" ? false : true;
        console.log('Account removed: ', this.conToInsert.Account.name);
    }
    selectNewConAcc(event) {
        this.conToInsert.AccountId = event.detail.Id;
        this.conToInsert.Account.Id = event.detail.Id;
        this.conToInsert.Account.name = event.detail.name;
        this.disableCreateCon = this.conToInsert.AccountId && this.conToInsert.LastName && this.conToInsert.LastName != "" ? false : true;
        console.log('Account Selected: ', this.conToInsert.Account.name);

    }
    get NewConAccSelected() {
        return this.conToInsert.AccountId ? true : false;
    }
    get NewConAccUrl() {
        return '/' + this.conToInsert.AccountId;
    }
    handleNewConFName(event) {
        this.conToInsert.FirstName = event.currentTarget.value;
    }
    handleNewConLName(event) {
        this.conToInsert.LastName = event.currentTarget.value;
        this.disableCreateCon = this.conToInsert.AccountId && this.conToInsert.LastName && this.conToInsert.LastName != "" ? false : true;
    }
    handleNewConCompany(event) {
        this.conToInsert.Company__c = event.currentTarget.value;
    }
    handleNewConEmail(event) {
        this.conToInsert.Email = event.currentTarget.value;
        const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (this.conToInsert.Email && this.conToInsert.Email != '') {
            if (!this.conToInsert.Email.match(emailRegex)) {
                this.newConError = 'Enter a valid email address';
            } else {
                this.newConError = undefined;
            }
        } else {
            this.newConError = undefined;
        }

    }
    handleNewConPhone(event) {
        this.conToInsert.Phone = event.currentTarget.value;
    }
    handleNewConMobPhone(event) {
        this.conToInsert.MobilePhone = event.currentTarget.value;
    }
    handleNewConIsPrim(event) {
        this.conToInsert.Primary__c = event.detail.checked;
    }

    newContactSave() {
        console.log('inside newContactSave');
        console.log('this.conToInsert:', this.conToInsert);
        this.newConError = undefined;
        if (!this.conToInsert.AccountId || this.conToInsert.Account == "") {
            this.newConError = 'Account Missing';
            return;
        }

        if (!this.conToInsert.LastName || this.conToInsert.LastName == "") {
            this.newConError = 'Last Name Missing';
            return;
        }

        if (this.conToInsert.Email && this.conToInsert.Email != '') {
            const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (!this.conToInsert.Email.match(emailRegex)) {
                this.newConError = 'Enter a valid email address';
                return;
            }
        }

        this.spinner = true;
        insertContact({
            con: JSON.stringify(this.conToInsert),
        })
            .then(result => {
                console.log('result:', result);
                if (!result.includes('Line No:')) {
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: 'Contact Created successfully',
                    });
                    this.dispatchEvent(event);
                    const accCreatedEvent = new CustomEvent('contactcreated', {
                        detail: { Id: result, AccId: this.conToInsert.AccountId }
                    });
                    this.contactid = result;
										this.AddConFilter = " AND AccountId = '" + this.conToInsert.AccountId + "'";
										if(this.conToInsert.FirstName!=undefined) this.contactname = this.conToInsert.FirstName + '' + this.conToInsert.LastName;
										else this.contactname = this.conToInsert.LastName;
                    this.dispatchEvent(accCreatedEvent);
                    this.spinner = false;
                    this.isCreateNewContact = false;
                } else {
                    this.newConError = result;
                    this.spinner = false;
                }
            })
            .catch(error => {
                console.log("Error:", error);
                this.spinner = false;
                this.newConError = error.body.message + '  Line:' + error.body.stackTrace;
            })


    }

    openCreateNewAddModal() {
        this.newAddError = undefined;
        this.addressToInsert = { Customer__r: { Id: '', Name: '' }, Contact__r: { Id: '', Name: '' }, Is_Billing_Address__c: false, Is_Shipping_Address__c: false, Primary__c: false };
        this.spinner = true;
        getDependentMap({
            contrfieldApiName: 'Country__c',
            depfieldApiName: 'State__c',
        })
            .then(result => {
                console.log('result:', result);
                // once set #StoreResponse to depnedentFieldMap attribute 
                this.depnedentFieldMap = result;

                // create a empty array for store map keys(@@--->which is controller picklist values) 
                let listOfkeys = []; // for store all map keys (controller picklist values)
                let ControllerField = []; // for store controller picklist value to set on lightning:select. 

                // play a for loop on Return map 
                // and fill the all map key on listOfkeys variable.
                for (let singlekey in this.depnedentFieldMap) {
                    listOfkeys.push(singlekey);
                }

                //set the controller field value for lightning:select
                if (listOfkeys != undefined && listOfkeys.length > 0) {
                    ControllerField.push({ value: '', label: '--- None ---' });
                }

                for (var i = 0; i < listOfkeys.length; i++) {
                    ControllerField.push({ value: listOfkeys[i], label: listOfkeys[i] });
                }
                // set the ControllerField variable values to country(controller picklist field)
                this.listControllingValues = ControllerField;
                console.log('this.listControllingValues:', this.listControllingValues);
                this.spinner = false;
                this.isCreateNewAddress = true;
                console.log('Address this.accountid:', this.accountid);
                console.log('Address this.accountname:', this.accountname);
                console.log('Address this.contactid:', this.contactid);
                console.log('Address this.contactname:', this.contactname);
                this.addressToInsert.Customer__c = this.accountid;
                this.addressToInsert.Customer__r.Id = this.accountid;
                this.addressToInsert.Customer__r.Name = this.accountname;
                this.addressToInsert.Contact__c = this.contactid;
                this.addressToInsert.Contact__r.Name = this.contactname;
								this.AddConFilter = " AND AccountId = '" + this.accountid + "'";
            })
            .catch(error => {
                console.log("Error:", error);
                this.spinner = false;
                this.isCreateNewAddress = true;
                this.newAddError = error.body.message;
            })

    }
    closeCreateNewAddModal() {
        this.isCreateNewAddress = false;
    }

    removeNewAddAcc(event) {
        this.addressToInsert.Customer__c = null;
        this.AddConFilter = ''; // Clear the filter when no account is selected
        this.disableAddCon = true;
        this.addressToInsert.Contact__c = null;
        this.addressToInsert.Contact__r.Id = '';
        this.addressToInsert.Contact__r.name = '';
        this.disableCreateAdd = !(this.addressToInsert.Customer__c &&
            this.addressToInsert.Contact__c &&
            this.addressToInsert.Address_Line1__c &&
            this.addressToInsert.Address_Line1__c !== '' &&
            this.addressToInsert.City__c &&
            this.addressToInsert.City__c !== '' &&
            this.addressToInsert.Postal_Code__c &&
            this.addressToInsert.Postal_Code__c !== '' &&
            this.addressToInsert.Country__c &&
            this.addressToInsert.Country__c !== '') ? true : false;
    }


    selectNewAddAcc(event) {
        this.addressToInsert.Customer__c = event.detail.Id;
        this.addressToInsert.Customer__r.Id = event.detail.Id;
        this.addressToInsert.Customer__r.name = event.detail.name;
        // Filter contacts based on the selected Account ID
        this.AddConFilter = " AND AccountId = '" + this.addressToInsert.Customer__c + "'";
        console.log('this.AddConFilter::~>', this.AddConFilter);
        this.disableAddCon = false;
        // Optionally set the contact details
        this.addressToInsert.Contact__c = this.contactid || null;
        this.addressToInsert.Contact__r.Id = this.contactid || '';
        this.disableCreateAdd = !(this.addressToInsert.Customer__c &&
            this.addressToInsert.Contact__c &&
            this.addressToInsert.Address_Line1__c &&
            this.addressToInsert.Address_Line1__c !== '' &&
            this.addressToInsert.City__c &&
            this.addressToInsert.City__c !== '' &&
            this.addressToInsert.Postal_Code__c &&
            this.addressToInsert.Postal_Code__c !== '' &&
            this.addressToInsert.Country__c &&
            this.addressToInsert.Country__c !== '') ? true : false;
    }

    get NewAddAccSelected() {
        return this.addressToInsert.Customer__c ? true : false;
    }
    get NewAddAccUrl() {
        return '/' + this.addressToInsert.Customer__c;
    }
    removeNewAddCon() {
        this.addressToInsert.Contact__c = null;
        this.disableCreateAdd = !(this.addressToInsert.Customer__c &&
            this.addressToInsert.Contact__c &&
            this.addressToInsert.Address_Line1__c &&
            this.addressToInsert.Address_Line1__c !== '' &&
            this.addressToInsert.City__c &&
            this.addressToInsert.City__c !== '' &&
            this.addressToInsert.Postal_Code__c &&
            this.addressToInsert.Postal_Code__c !== '' &&
            this.addressToInsert.Country__c &&
            this.addressToInsert.Country__c !== '') ? true : false;
    }

    selectNewAddCon(event) {
        this.addressToInsert.Contact__c = event.detail.Id;
        this.addressToInsert.Contact__r.Id = event.detail.Id;
        this.addressToInsert.Contact__r.name = event.detail.name;
        this.disableCreateAdd = !(this.addressToInsert.Customer__c &&
            this.addressToInsert.Contact__c &&
            this.addressToInsert.Address_Line1__c &&
            this.addressToInsert.Address_Line1__c !== '' &&
            this.addressToInsert.City__c &&
            this.addressToInsert.City__c !== '' &&
            this.addressToInsert.Postal_Code__c &&
            this.addressToInsert.Postal_Code__c !== '' &&
            this.addressToInsert.Country__c &&
            this.addressToInsert.Country__c !== '') ? true : false;
    }

    get NewAddConSelected() {
        return this.addressToInsert.Contact__c ? true : false;
    }

    /*get AddConFilter(){
        return " AccountId =:'"+this.addressToInsert.Customer__c+"'";
    }*/
    get NewAddConUrl() {
        return '/' + this.addressToInsert.Contact__c;
    }

    handleNewAddLine1(event) {
        this.addressToInsert.Address_Line1__c = event.currentTarget.value;
        this.disableCreateAdd = this.addressToInsert.Customer__c && this.addressToInsert.Contact__c && this.addressToInsert.Address_Line1__c && this.addressToInsert.Address_Line1__c != '' && this.addressToInsert.City__c && this.addressToInsert.City__c != '' && this.addressToInsert.Postal_Code__c && this.addressToInsert.Postal_Code__c != '' && this.addressToInsert.Country__c && this.addressToInsert.Country__c != '' ? false : true;
    }
    handleNewAddLine2(event) {
        this.addressToInsert.Address_Line2__c = event.currentTarget.value;
    }
    handleNewAddLine3(event) {
        this.addressToInsert.Address_Line3__c = event.currentTarget.value;
    }
    handleNewAddCity(event) {
        this.addressToInsert.City__c = event.currentTarget.value;
        this.disableCreateAdd = this.addressToInsert.Customer__c && this.addressToInsert.Contact__c && this.addressToInsert.Address_Line1__c && this.addressToInsert.Address_Line1__c != '' && this.addressToInsert.City__c && this.addressToInsert.City__c != '' && this.addressToInsert.Postal_Code__c && this.addressToInsert.Postal_Code__c != '' && this.addressToInsert.Country__c && this.addressToInsert.Country__c != '' ? false : true;
    }
    handleNewAddPostal(event) {
        this.addressToInsert.Postal_Code__c = event.currentTarget.value;
        this.disableCreateAdd = this.addressToInsert.Customer__c && this.addressToInsert.Contact__c && this.addressToInsert.Address_Line1__c && this.addressToInsert.Address_Line1__c != '' && this.addressToInsert.City__c && this.addressToInsert.City__c != '' && this.addressToInsert.Postal_Code__c && this.addressToInsert.Postal_Code__c != '' && this.addressToInsert.Country__c && this.addressToInsert.Country__c != '' ? false : true;
    }
    handleNewAddCountry(event) {
        try {
            this.addressToInsert.Country__c = event.detail.value;

            var controllerValueKey = this.addressToInsert.Country__c; // get selected controller field value
            var depnedentFieldMap = this.depnedentFieldMap;

            if (controllerValueKey != '') {
                var ListOfDependentFields = depnedentFieldMap[controllerValueKey];

                if (ListOfDependentFields.length > 0) {
                    this.bDisabledDependentFld = false;
                    //helper.fetchDepValues(component, ListOfDependentFields);
                    var dependentFields = [];
                    dependentFields.push({ value: '', label: '--- None ---' });
                    for (var i = 0; i < ListOfDependentFields.length; i++) {
                        dependentFields.push({ value: ListOfDependentFields[i], label: ListOfDependentFields[i] });
                    }
                    // set the dependentFields variable values to store(dependent picklist field) on lightning:select
                    this.listDependingValues = dependentFields;
                } else {
                    this.bDisabledDependentFld = true;
                    this.listDependingValues = [{ value: '', label: '--- None ---' }];
                }

            } else {
                this.listDependingValues = [{ value: '', label: '--- None ---' }];
                this.bDisabledDependentFld = true;
            }

            this.disableCreateAdd = this.addressToInsert.Customer__c && this.addressToInsert.Contact__c && this.addressToInsert.Address_Line1__c && this.addressToInsert.Address_Line1__c != '' && this.addressToInsert.City__c && this.addressToInsert.City__c != '' && this.addressToInsert.Postal_Code__c && this.addressToInsert.Postal_Code__c != '' && this.addressToInsert.Country__c && this.addressToInsert.Country__c != '' ? false : true;
        } catch (e) { console.log('Error:', e); }
    }
    handleNewAddState(event) {
        this.addressToInsert.State__c = event.detail.value;
    }
    handleNewAddIsBill(event) {
        this.addressToInsert.Is_Billing_Address__c = event.detail.checked;
    }
    handleNewAddIsShip(event) {
        this.addressToInsert.Is_Shipping_Address__c = event.detail.checked;
    }
    handleNewAddIsPrimary(event) {
        this.addressToInsert.Primary__c = event.detail.checked;
    }
    newAddessSave() {
        try {
            console.log('this.addressToInsert:', this.addressToInsert);
            this.newAddError = undefined;

            if (!this.addressToInsert.Customer__c) {
                this.newAddError = 'Account Missing';
                return;
            }

            if (!this.addressToInsert.Contact__c) {
                this.newAddError = 'Contact Missing';
                return;
            }

            if (!this.addressToInsert.Address_Line1__c || this.addressToInsert.Address_Line1__c == '') {
                this.newAddError = 'Address Line1 Missing';
                return;
            }

            if (!this.addressToInsert.City__c || this.addressToInsert.City__c == '') {
                this.newAddError = 'City Missing';
                return;
            }

            if (!this.addressToInsert.Postal_Code__c || this.addressToInsert.Postal_Code__c == '') {
                this.newAddError = 'Postal Code Missing';
                return;
            }

            if (!this.addressToInsert.Country__c || this.addressToInsert.Country__c == '') {
                this.newAddError = 'Country Missing';
                return;
            }

            this.spinner = true;
            this.addressToInsert.name = this.addressToInsert.Address_Line1__c;
            this.addressToInsert.Organisation__c = this.order.Account.Organisation__c;
            this.addressToInsert.Active__c = true;
            createNewAddress({
                addrs: JSON.stringify(this.addressToInsert),
            })
                .then(result => {
                    console.log('result:', result);
                    if (!result.includes('Line No:')) {
                        this.isCreateNewAddress = false;
                        this.spinner = false;
                        const event = new ShowToastEvent({
                            variant: 'success',
                            message: 'Address Created successfully',
                        });
                        this.dispatchEvent(event);
                        const accCreatedEvent = new CustomEvent('addresscreated', {
                            detail: { Id: result, isBilling: this.addressToInsert.Is_Billing_Address__c, isShipping: this.addressToInsert.Is_Shipping_Address__c, accId: this.addressToInsert.Customer__c }
                        });
                        this.dispatchEvent(accCreatedEvent);
                    } else {
                        this.newAddError = result;
                    }
                    this.spinner = false;
                })
                .catch(error => {
                    console.log('Error:', error);
                    this.newAddError = error.body.message + '   ' + error.body.stackTrace;
                    this.spinner = false;
                })

        } catch (e) { console.log('Error:', e); }



    }








    renderedCallback() {
        try {
            console.log('renderedCallback eposAccount');


						this.accProfileSelected = this.order.Account.Account_Profile__c ? true : false;
						if (this.order && this.order.Account && this.order.Account.Company__c && this.order.Account.Company__r.Name) {
								console.log('here: '+ this.order.Account);
								this.companyName = this.order.Account.Company__r.Name;
						} else {
								console.log('else:');
								// Handle undefined by setting a default name
								this.companyName = 'No Company';
						}
            Promise.all([

            ])
                .then(() => {
                    console.log('Static Resource Loaded');
                })
                .catch(error => {
                    console.log('Static Resource Error', error);
                });
        } catch (e) {
            console.log('Error:', e);
        }
    }

validateFields() {
        // Regex patterns for validation
        const phoneFaxRegex = /^[0-9]{10}$/; // Basic example: 10-digit number
        const websiteRegex = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,4}\/?$/;

        const isPhoneValid = phoneFaxRegex.test(this.phone);
        const isFaxValid = phoneFaxRegex.test(this.fax);
        const isWebsiteValid = websiteRegex.test(this.website);

        this.disableCreateAcc = !(isPhoneValid && isFaxValid && isWebsiteValid);
    }

}
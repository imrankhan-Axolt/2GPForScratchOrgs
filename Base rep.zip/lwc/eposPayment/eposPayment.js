import { LightningElement, api, track, wire } from 'lwc';
import Invoice_Document from '@salesforce/label/c.Invoice_Document';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import BaseStaticResource from '@salesforce/resourceUrl/BaseStaticResource';
//Apex Methods
import { refreshApex } from '@salesforce/apex';
import getInitailCardDetails from "@salesforce/apex/Epos.fetchInitialCardDetails";
import cardPayment from '@salesforce/apex/Epos.createCardPayment';
import upsertInvoice from '@salesforce/apex/Epos.updateInvoice';
import getInitialBankDetails from '@salesforce/apex/Epos.fetchInitialBankDetails';
import bankOrCashPayment from '@salesforce/apex/Epos.createBankOrCashPayment';
import getInitailApplyCredit from '@salesforce/apex/Epos.applyCreditInitial';
import applyCreditInvoice from "@salesforce/apex/Epos.applyCreditToInvoice";
import fetchApplyLoyaltyInitial from "@salesforce/apex/Epos.applyLoyaltyInitial";
import applyLoyalty from '@salesforce/apex/Epos.applyLoyalty';

export default class EposPayment extends LightningElement {

    @api order = {};
    @api invoiceList = [];  
    @api isInvoiceList = false;
    @api paymentList = [];
    @api isPaymentList = false;
    @api orderCurrency;
    errorList;
    spinner = false;

    isCardPaymentModal = false;
    isBankPaymentModal = false;
    isCashModal = false;
    isLoyaltyModal = false;
    isApplyCreditsModal = false;
    paymentError;
    @track PaymentMethod = {};
    CVV;

    @track invoiceToPay = [];
    isinvoiceToPay = false;

    @track paymentToUpsert = { Total_Amount__c: 0 };
    @track paymentBillAdd = {};
    paymentGateway;
    selectedGateway = '';
    CountyList;
    CountryList;
    CardTypes;
    ExpiryMonth;
    ExpiryYear;
    //@api isMultiCurrency=false;

    accountTypes;
    COAFilter;//  "{! v.OrgId != ''?' AND Organisation__c =\''+ v.OrgId+'\''+ ' AND Payment_Account__c=true' : ' AND Payment_Account__c=true'}";

    @track availableCredits;
    isavailableCredits = false;
    appliedCreditAmount = 0;
    balanceAmount = 0;

    loyaltyValue = 0;
    redeemPoints;
    loyalityCards;
    showApplyLoyaltySave = true;

    get COASelected() {
        return this.paymentToUpsert.Payment_Account__c ? true : false;
    }
    get COAUrl() {
        return '/' + this.paymentToUpsert.Payment_Account__c;
    }


    /*@wire(getInitialData)
    InitailDetails({ error, data }) {
        if (data) {
            console.log('inside eposPaymentinitial result eposPaymnet:', data);
            
            console.log('order:', this.order);
        } else if (error) {
            console.log('inside eposPayment initial result eposPaymnet:', error);
        }
    }*/
    connectedCallback() {
        console.log('inside eposPayment connectedCallback');

    }
    renderedCallback() {
        console.log('inside eposPayment renderedCallback');

        Promise.all([
            loadStyle(this, BaseStaticResource + '/CMP_CSS/CSS/global-axolt.css'),
            loadStyle(this, BaseStaticResource + '/PickPackShipResource/assets/styles/erp_mark7_bootstrap.css'),
            loadStyle(this, BaseStaticResource + '/bootStrap/css/bootstrap-4.1.css'),
            loadStyle(this, BaseStaticResource + '/SLDS/assets/styles/salesforce-lightning-design-system-vf.css'),
            loadStyle(this, BaseStaticResource + '/ProjectWorkbench/css/main-style.css'),
            loadStyle(this, BaseStaticResource + '/fontawesome5/fontawesome5/css/all.css'),
            loadStyle(this, BaseStaticResource + '/eposcustom/assets/css/app.min.css'),
            loadStyle(this, BaseStaticResource + '/eposcustom/assets/css/bootstrap.min.css'),
            loadStyle(this, BaseStaticResource + '/eposcustom/assets/css/icons.min.css'),
        ])
            .then(() => {
                console.log('Static Resource Loaded epos Payment');
            })
            .catch(error => {
                console.log('inside eposPayment Static Resource Error', error);
            });
    }


    invoiceDocument(event) {
        let index = event.currentTarget.dataset.index;
        this.invoiceList[index].Id;
        var URL_INV = '';
        if (this.order.Contact__c) {
            URL_INV = Invoice_Document;
            URL_INV += 'custId=' + this.order.Contact__c + '&name=' + this.invoiceList[index].Name;
        }
        window.open(URL_INV, '_blank');
    }

    createInvoice() {
        window.open('/apex/CreateInvoiceRecord?soid=' + this.order.Id, '_self')
    }

    /*selectPaymentMode() {
        console.log('inside selectPaymentMode');
    }*/


    openCardPayModal() {
        try {
            console.log('inside openCardPayModal');
            this.spinner = true;
            //initial setup
            //this.checkAllInv = false;
            this.paymentError = undefined;
            this.PaymentMethod.Name_on_Card__c = '';
            this.PaymentMethod.Card_Number__c = '';
            this.CVV = '';
            this.paymentToUpsert.Reference_Cheque_No__c = '';
            this.paymentToUpsert.Total_Amount__c = 0;
            this.invoiceToPay = [];
            let invoiceToPayIndex = 0;
            this.selectedGateway = '';
            console.log('this.invoiceList:', this.invoiceList);

            for (let i in this.invoiceList) {
                if (this.invoiceList[i].Total_Due__c > 0) {
                    this.invoiceToPay.push(JSON.parse(JSON.stringify(this.invoiceList[i])));
                    this.invoiceToPay[invoiceToPayIndex].trKey = this.invoiceToPay[invoiceToPayIndex].Id + i;
                    this.invoiceToPay[invoiceToPayIndex].checked = false;
                    this.invoiceToPay[invoiceToPayIndex].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceList[i].Total_Due__c));
                    //this.paymentToUpsert.Total_Amount__c += parseFloat(this.invoiceToPay[invoiceToPayIndex].AmountToPaid);

                    if (this.invoiceList[i].Posted__c) {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    } else {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = true;
                        if (this.invoiceToPay[invoiceToPayIndex].RecordType.DeveloperName == 'Advance')
                            this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    }
                    invoiceToPayIndex++;
                }

            }
            console.log('this.invoiceToPay:', JSON.stringify(this.invoiceToPay));
            if (this.invoiceToPay.length > 0) this.isinvoiceToPay = true;
            else this.isinvoiceToPay = false;

            console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);
            getInitailCardDetails()
                .then(result => {
                    console.log('result of getInitailCardDetails:', result);
                    this.CountyList = result.CountyList;
                    this.CountryList = result.CountryList;
                    this.CardTypes = result.CardTypes;
                    this.PaymentMethod.CardType__c = result.CardTypes[0].value;
                    this.ExpiryMonth = result.ExpiryMonth;
                    this.PaymentMethod.Card_Expiration_Month__c = result.ExpiryMonth[0].value;
                    this.ExpiryYear = result.ExpiryYear;
                    this.PaymentMethod.Card_Expiration_Year__c = result.ExpiryYear[0].value;
                    this.paymentGateway = result.paymentGateways;
                    if (this.paymentGateway.length == 0) this.paymentError = 'Paymnet Credential Setup is not completed.';
                    if (this.paymentGateway.length == 1) this.selectedGateway = this.paymentGateway[0].value;

                    this.paymentBillAdd = this.order.Bill_To_Address__r;
                    this.isCardPaymentModal = true;
                    this.spinner = false;
                })
                .catch(error => {
                    this.spinner = false;
                    this.errorList = Object.assign([], this.errorList);
                    if (!this.errorList.includes(error.body.message)) this.errorList.push(error.body.message);
                    if (!this.errorList.includes(error.body.stackTrace) && error.body.stackTrace) this.errorList.push(error.body.stackTrace);
                })
        } catch (e) {
            this.spinner = false;
            console.log('Error:', e);
        }

    }
    closeCardPaymentModal() {
        this.isCardPaymentModal = false;
        const paymentEvent = new CustomEvent('payment', {});
        this.dispatchEvent(paymentEvent);
    }

    handlePaymentGateway(event) {
        this.selectedGateway = event.detail.value;
    }

    /*get orgSelected() {
        return this.order.Organisation__r.Id != '' ? true : false;
    }
    get selectOrgUrl() {
        return '/' + this.order.Organisation__r.Id;
    }

    selectOrg(event) {
        this.order.Organisation__c = event.detail.Id;
        this.order.Organisation__r = { Id: event.detail.Id, Name: event.detail.Name };
    }
    removeOrg() {
        this.order.Organisation__c = null;
        this.order.Organisation__r = { Id: '', Name: '' };
    }*/

    handlePayInvCheck(event) {
        console.log('event.detail.checked:', event.detail.checked);
        this.spinner = true;
        this.invoiceToPay[event.currentTarget.dataset.index].checked = event.detail.checked;
        console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);
        if (event.detail.checked)
            this.paymentToUpsert.Total_Amount__c = (parseFloat(this.paymentToUpsert.Total_Amount__c) + parseFloat(this.invoiceToPay[event.currentTarget.dataset.index].AmountToPaid)).toFixed(2);
        else
            this.paymentToUpsert.Total_Amount__c = (parseFloat(this.paymentToUpsert.Total_Amount__c) - parseFloat(this.invoiceToPay[event.currentTarget.dataset.index].AmountToPaid)).toFixed(2);

        //this.paymentToUpsert.Total_Amount__c=(this.paymentToUpsert.Total_Amount__c).toFixed(2);
        console.log('invoice:', JSON.stringify(this.invoiceToPay[event.currentTarget.dataset.index]));
        console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);
        try {
            if (this.isApplyCreditsModal) {
                this.balanceAmount = parseFloat(this.paymentToUpsert.Total_Amount__c) - parseFloat(this.appliedCreditAmount);
                console.log('this.balanceAmount:', this.balanceAmount);
                for (let i in this.invoiceToPay) {
                    if (event.detail.checked) {
                        if (i != event.currentTarget.dataset.index) {
                            if (this.invoiceToPay[i].Posted__c || this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') {
                                this.invoiceToPay[i].disableCheckbox = true;
                            }

                        }


                    } else {
                        if (this.invoiceToPay[i].Posted__c || this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') {
                            this.invoiceToPay[i].disableCheckbox = false;
                        }

                    }
                }
            }
            this.spinner = false;
        } catch (e) {
            this.spinner = false;
            console.log('e:', e);
        }

    }

    handleCardName(event) {
        this.PaymentMethod.Name_on_Card__c = event.currentTarget.value;
    }
    handleCardType(event) {
        this.PaymentMethod.CardType__c = event.detail.value;
    }
    handleCardNumber(event) {
        this.PaymentMethod.Card_Number__c = event.currentTarget.value;
    }
    handleCVV(event) {
        this.CVV = event.currentTarget.value;
    }
    handleCardExpMonth(event) {
        this.PaymentMethod.Card_Expiration_Month__c = event.detail.value;
    }
    handleCardExpYear(event) {
        this.PaymentMethod.Card_Expiration_Year__c = event.detail.value;
    }
    handleRefCheque(event) {
        this.paymentToUpsert.Reference_Cheque_No__c = event.currentTarget.value;
    }

    handleBillLine1(event) {
        this.paymentBillAdd.Address_Line1__c = event.currentTarget.value;
    }
    handleBillLine2(event) {
        this.paymentBillAdd.Address_Line2__c = event.currentTarget.value;
    }
    handleBillCountry(event) {
        this.paymentBillAdd.Country__c = event.currentTarget.value;
    }
    handleBillCity(event) {
        this.paymentBillAdd.City__c = event.detail.value;
    }
    handleBillState(event) {
        this.paymentBillAdd.State__c = event.currentTarget.value;
    }
    handleBillZip(event) {
        this.paymentBillAdd.Postal_Code__c = event.currentTarget.value;
    }

    /*checkAllInv = false;
    checkAllInvToPay(event) {
        //refreshApex(this.invoiceToPay);
        console.log('event.detail.value:', event.detail.checked);

        let checkboxes = this.template.querySelectorAll('[data-id="checkbox"]')
        for (let i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = event.detail.checked;
        }
        this.checkAllInv = event.detail.checked;

        this.paymentToUpsert.Total_Amount__c = 0;
        if (event.detail.checked == true) {
            for (let i in this.invoiceToPay) {
                this.invoiceToPay[i].checked = true;
                this.paymentToUpsert.Total_Amount__c += parseFloat(this.invoiceToPay[i].AmountToPaid);
            }
        } else if (event.detail.checked == false) {
            for (let i in this.invoiceToPay) {
                this.invoiceToPay[i].checked = false;
            }
        }
    }*/

    handleInvDue(event) {
        console.log('event.currentTarget.value:', event.currentTarget.value);
        this.paymentError = undefined;
        for (let i in this.invoiceList) {
            if (this.invoiceList[i].Id == this.invoiceToPay[event.currentTarget.dataset.index].Id && parseFloat(this.invoiceList[i].Total_Due__c) < parseFloat(event.currentTarget.value)) {
                this.paymentError = this.invoiceToPay[event.currentTarget.dataset.index].Name + ' : Amount Can not be greater than due amount';
            }
        }
        this.invoiceToPay[event.currentTarget.dataset.index].AmountToPaid = parseFloat(event.currentTarget.value);
        this.paymentToUpsert.Total_Amount__c = 0;
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked)
                this.paymentToUpsert.Total_Amount__c = (parseFloat(this.paymentToUpsert.Total_Amount__c) + parseFloat(this.invoiceToPay[i].AmountToPaid)).toFixed(2);
        }
        this.balanceAmount = (parseFloat(this.paymentToUpsert.Total_Amount__c) - parseFloat(this.appliedCreditAmount)).toFixed(2);
    }


    cardPaymentSave() {
        console.log('this.invoiceToPay:', this.invoiceToPay);
        this.paymentError = undefined;



        if (this.paymentGateway.length == 0) {
            this.paymentError = 'Paymnet Credential Setup is not completed.';
            return;
        }

        if (this.invoiceToPay.length == 0) {
            this.paymentError = 'Due Invoice not available to pay';
            return;
        }
        let count = 0;
        let ifSingleInv = '';
        //let invIdList = [];
        let invAndAmount = [];
        let invAndAmountIndex = 0;
        let salesInvCount = 0;
        let advInvCount = 0
        let isAdvance = false;
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked) {
                invAndAmount[invAndAmountIndex] = { Id: this.invoiceToPay[i].Id, Invoice_Amount__c: this.invoiceToPay[i].AmountToPaid };
                invAndAmountIndex++;
                //invAndAmountMap.set(this.invoiceToPay[i].Id,this.invoiceToPay[i].AmountToPaid);
                //invIdList.push(this.invoiceToPay[i].Id);
                ifSingleInv = this.invoiceToPay[i].Id;
                count++;
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') { advInvCount++; isAdvance = true; }
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Sale') salesInvCount++;
            }
        }
        if (salesInvCount > 0 && advInvCount > 0) {
            this.paymentError = 'Can not pay sale and advance invoices together.'
            return;
        }
        if (count == 1) this.paymentToUpsert.Invoice__c = ifSingleInv;
        if (count == 0) {
            this.paymentError = 'Please select invoice to pay';
            return;
        }
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked && parseFloat(this.invoiceToPay[i].AmountToPaid) <= 0) {
                this.paymentError = this.invoiceToPay[i].Name + ' : Amount To Paid can not be zero or negative';
                return;
            }
            for (let j in this.invoiceList) {
                if (this.invoiceList[j].Id == this.invoiceToPay[i].Id && parseFloat(this.invoiceList[j].Total_Due__c) < parseFloat(this.invoiceToPay[i].AmountToPaid)) {
                    this.paymentError = this.invoiceToPay[i].Name + ' : Amount Can not be greater than due amount';
                    return;
                }
            }

        }

        if (!this.PaymentMethod.Name_on_Card__c || this.PaymentMethod.Name_on_Card__c == '') {
            this.paymentError = 'Enter Card Holder Name';
            return;
        }
        if (!this.PaymentMethod.CardType__c || this.PaymentMethod.CardType__c == '') {
            this.paymentError = 'Select Card Type';
            return;
        }
        if (!this.PaymentMethod.Card_Number__c || this.PaymentMethod.Card_Number__c == '') {
            this.paymentError = 'Enter Card Number';
            return;
        }
        if (!this.CVV || this.CVV == '') {
            this.paymentError = 'Enter CVV';
            return;
        }
        if (!this.PaymentMethod.Card_Expiration_Month__c || this.PaymentMethod.Card_Expiration_Month__c == '') {
            this.paymentError = 'Select Expiry Month';
            return;
        }
        if (!this.PaymentMethod.Card_Expiration_Year__c || this.PaymentMethod.Card_Expiration_Year__c == '') {
            this.paymentError = 'Select Expiry Year';
            return;
        }
        if (!this.paymentToUpsert.Total_Amount__c || this.paymentToUpsert.Total_Amount__c <= 0) {
            this.paymentError = 'Payment Amount can not be zero or negative';
            return;
        }
        if (!this.paymentBillAdd.Country__c || this.paymentBillAdd.Country__c == '') {
            this.paymentError = 'Select Country';
            return;
        }
        if (!this.paymentBillAdd.State__c || this.paymentBillAdd.State__c == '') {
            this.paymentError = 'Select State/Province';
            return;
        }
        if (!this.selectedGateway || this.selectedGateway == '') {
            this.paymentError = 'Select Payment Gateway';
            return;
        }

        this.spinner = true;
        //if (!this.isMultiCurrency) delete this.order.CurrencyIsoCode;
        console.log('after multi');
        this.paymentToUpsert.Account_Holder_Name__c = this.PaymentMethod.Name_on_Card__c;
        if (isAdvance)
            this.paymentToUpsert.Transaction_Type__c = 'AdvancePayment';
        else
            this.paymentToUpsert.Transaction_Type__c = 'InvoicePayment';

        this.paymentToUpsert.Order__c = this.order.Id;
        this.paymentToUpsert.Accounts__c = this.order.AccountId;
        this.paymentToUpsert.Amount__c = this.paymentToUpsert.Total_Amount__c;

        if (this.order.Contact__r.FirstName) this.paymentToUpsert.First_Name__c = this.order.Contact__r.FirstName;
        if (this.order.Contact__r.LastName) this.paymentToUpsert.Last_Name__c = this.order.Contact__r.LastName;
        if (this.order.Contact__r.Email) this.paymentToUpsert.Email_Address__c = this.order.Contact__r.Email;
        if (this.paymentBillAdd.Address_Line1__c) this.paymentToUpsert.Address_Line1__c = this.paymentBillAdd.Address_Line1__c;
        if (this.paymentBillAdd.Address_Line2__c) this.paymentToUpsert.Address_Line2__c = this.paymentBillAdd.Address_Line2__c;
        if (this.paymentBillAdd.City__c) this.paymentToUpsert.City__c = this.paymentBillAdd.City__c;
        if (this.paymentBillAdd.State__c) this.paymentToUpsert.State__c = this.paymentBillAdd.State__c;
        if (this.paymentBillAdd.Country__c) this.paymentToUpsert.Country__c = this.paymentBillAdd.Country__c;
        if (this.paymentBillAdd.Postal_Code__c) this.paymentToUpsert.Zipcode__c = this.paymentBillAdd.Postal_Code__c;
        if (this.order.Company__c) this.paymentToUpsert.Company__c = this.order.Company__c;
        if (this.order.Organisation_Business_Unit__c) this.paymentToUpsert.Organisation_Business_Unit__c = this.order.Organisation_Business_Unit__c;
        //this.paymentToUpsert.this.paymentToUpsert_Gateway__c = 'PayPal';

        console.log('this.order:', this.order);
        console.log('this.this.paymentToUpsert:', this.paymentToUpsert);
        console.log('this.PaymentMethod:', this.PaymentMethod);
        console.log('this.CVV:', this.CVV);
        console.log('this.paymentBillAdd:', this.paymentBillAdd);
        console.log('this.Payment Gateway:', this.selectedGateway);
        console.log('this.orderCurrency:', this.orderCurrency);
        console.log('invAndAmount:', invAndAmount);

        cardPayment({
            //ord: JSON.stringify(this.order),
            payments: JSON.stringify(this.paymentToUpsert),
            paymentMethods: JSON.stringify(this.PaymentMethod),
            CVV: this.CVV,
            billAddress: JSON.stringify(this.paymentBillAdd),
            selectedGateway: this.selectedGateway,
            myCur: this.orderCurrency,
            //invList: JSON.stringify(invIdList),
            invAndAmount: JSON.stringify(invAndAmount),
            resCode: 1,
        })
            .then(result => {
                console.log('result of cardPayment:', result);

                if (result.includes('Payment Created Successfully')) {
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: result,
                    });
                    this.dispatchEvent(event);
                    const paymentEvent = new CustomEvent('payment', {});
                    this.dispatchEvent(paymentEvent);
                    this.isCardPaymentModal = false;
                    this.spinner = false;
                } else {
                    this.paymentError = result;
                    this.spinner = false;
                }
            })
            .catch(error => {
                this.paymentError = error;
                this.spinner = false;
                console.log('Error:', error);

            })

    }

    postInvoice(event) {
        console.log('inside postInvoice');
        this.spinner = true;
        this.paymentError = undefined;
        let index = event.currentTarget.dataset.index;
        let invId = this.invoiceToPay[index].Id;
        console.log('index:', invId);
        //Substract Invoice Amount from Total_Amount__c
        if (this.invoiceToPay[index].checked) {
            this.paymentToUpsert.Total_Amount__c -= parseFloat(this.invoiceToPay[index].AmountToPaid);
        }
        if (this.isApplyCreditsModal) {
            for (let i in this.invoiceToPay) {
                this.invoiceToPay[i].checked = false;
                if (this.invoiceToPay[i].Posted__c || this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') {
                    this.invoiceToPay[i].disableCheckbox = false;
                } else {
                    this.invoiceToPay[i].disableCheckbox = true;
                }
            }
            this.paymentToUpsert.Total_Amount__c = 0;
            this.balanceAmount = 0;
            this.appliedCreditAmount = 0;
            getInitailApplyCredit({
                accId: this.order.AccountId,
            })
                .then(result => {
                    console.log('result:', result);
                    this.availableCredits = JSON.parse(JSON.stringify(result));
                    for (let i in this.availableCredits) {
                        this.availableCredits[i].credNote.credNoteurl = '/' + this.availableCredits[i].credNote.Id;
                        this.availableCredits[i].credNote.amountDue = (parseFloat(this.availableCredits[i].credNote.Balance__c) - parseFloat(this.availableCredits[i].debitAmount)).toFixed(2);
                        this.availableCredits[i].credNote.maxValue = this.availableCredits[i].credNote.Balance__c;
                    }

                    this.isavailableCredits = this.availableCredits.length > 0 ? true : false;
                })
                .catch(error => {
                    console.log('Error:', error);
                    if (!this.errorList.includes(error.body.message)) this.errorList.push(error.body.message);
                    if (!this.errorList.includes(error.body.stackTrace) && error.body.stackTrace) this.errorList.push(error.body.stackTrace);
                })
            //this.balanceAmount=(parseFloat(this.paymentToUpsert.Total_Amount__c)-parseFloat(this.invoiceToPay[index].AmountToPaid)).toFixed(2);
        }

        let postedValue;
        if (this.invoiceToPay[index].postLable == 'Post') postedValue = true;
        if (this.invoiceToPay[index].postLable == 'Unpost') postedValue = false;

        upsertInvoice({
            invId: invId,
            postedValue: postedValue,
        })
            .then(result => {
                console.log('result :', result);
                this.invoiceToPay[index] = result;
                this.invoiceToPay[index].invoiceurl = '/' + this.invoiceToPay[index].Id;
                if (this.invoiceToPay[index].Posted__c) {
                    this.invoiceToPay[index].disableCheckbox = false;
                    this.invoiceToPay[index].isPosted = 'Yes';
                    this.invoiceToPay[index].postLable = 'Unpost';
                    this.invoiceToPay[index].isPostedClass = 'bgGreen';
                    this.invoiceToPay[index].trKey = this.invoiceToPay[index].Id + index;
                    this.invoiceToPay[index].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceToPay[index].Total_Due__c));
                    this.invoiceToPay[index].checked = false;

                }
                else {
                    this.invoiceToPay[index].disableCheckbox = true;
                    this.invoiceToPay[index].isPosted = 'No';
                    this.invoiceToPay[index].postLable = 'Post';
                    this.invoiceToPay[index].isPostedClass = 'bgRed';
                    this.invoiceToPay[index].trKey = this.invoiceToPay[index].Id + index;
                    this.invoiceToPay[index].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceToPay[index].Total_Due__c));
                    this.invoiceToPay[index].checked = false;

                }
                if (this.invoiceToPay[index].RecordType.DeveloperName == 'Advance')
                    this.invoiceToPay[index].isAdvance = true;
                else
                    this.invoiceToPay[index].isAdvance = false;


                /*//For Updating posted invoiceList
                //const paymentEvent = new CustomEvent('payment', { });
                //this.dispatchEvent(paymentEvent);
                for (let i in this.invoiceList) {
                    if (this.invoiceList[i].Id == invId) {                        
                        this.invoiceList[i] = this.invoiceToPay[index];
                    }
                }*/
                this.spinner = false;
            })
            .catch(error => {
                console.log('Error:', error);
                this.paymentError = error;
                this.spinner = false;
                if (!this.errorList.includes(error.body.message)) this.errorList.push(error.body.message);
                if (!this.errorList.includes(error.body.stackTrace) && error.body.stackTrace) this.errorList.push(error.body.stackTrace);
            })
    }

    openBankPaymentModal() {
        try {
            this.spinner = true;
            //initialize initails
            this.paymentError = undefined;
            this.paymentToUpsert.Bank__c = '';
            this.paymentToUpsert.Account_Holder_Name__c = '';
            this.paymentToUpsert.Payment_Account__c = null;
            this.paymentToUpsert.Account_Type__c = '';
            this.paymentToUpsert.Account_Number__c = '';
            this.paymentToUpsert.Bank_Code__c = '';
            this.paymentToUpsert.Reference_Cheque_No__c = '';
            this.paymentToUpsert.Total_Amount__c = 0;
            this.COAFilter = this.order.Organisation__c ? "Organisation__c ='" + this.order.Organisation__c + "'  AND Payment_Account__c=true" : ' Payment_Account__c=true';

            this.invoiceToPay = [];
            let invoiceToPayIndex = 0;
            console.log('this.invoiceList:', this.invoiceList);

            for (let i in this.invoiceList) {
                if (this.invoiceList[i].Total_Due__c > 0) {
                    this.invoiceToPay.push(JSON.parse(JSON.stringify(this.invoiceList[i])));
                    this.invoiceToPay[invoiceToPayIndex].trKey = this.invoiceToPay[invoiceToPayIndex].Id + i;
                    this.invoiceToPay[invoiceToPayIndex].checked = false;
                    this.invoiceToPay[invoiceToPayIndex].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceList[i].Total_Due__c));
                    //this.paymentToUpsert.Total_Amount__c += parseFloat(this.invoiceToPay[invoiceToPayIndex].AmountToPaid);

                    if (this.invoiceList[i].Posted__c) {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    } else {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = true;
                        if (this.invoiceToPay[invoiceToPayIndex].RecordType.DeveloperName == 'Advance')
                            this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    }
                    invoiceToPayIndex++;
                }
            }
            console.log('this.invoiceToPay:', JSON.stringify(this.invoiceToPay));

            if (this.invoiceToPay.length > 0) this.isinvoiceToPay = true;
            else this.isinvoiceToPay = false;

            console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);

            getInitialBankDetails()
                .then(result => {
                    this.accountTypes = result.accountsType;
                    this.paymentToUpsert.Account_Type__c = result.accountsType[0].value;
                    this.isBankPaymentModal = true;
                    this.spinner = false;
                })
                .catch(error => {
                    this.spinner = false;
                    this.paymentError = error;
                })
        } catch (e) {
            this.spinner = false;
            console.log('Error:', e);
        }

    }

    closeBankPaymentModal() {
        this.isBankPaymentModal = false;
        const paymentEvent = new CustomEvent('payment', {});
        this.dispatchEvent(paymentEvent);
    }

    handleBankName(event) {
        this.paymentToUpsert.Bank__c = event.currentTarget.value;
    }
    handleAHName(event) {
        this.paymentToUpsert.Account_Holder_Name__c = event.currentTarget.value;
    }
    removeCOA(event) {
        this.paymentToUpsert.Payment_Account__c = null;
    }
    selectCOA(event) {
        this.paymentToUpsert.Payment_Account__c = event.detail.Id;
        //this.COASelected=true;
    }
    handleACtype(event) {
        this.paymentToUpsert.Account_Type__c = event.detail.value;
    }
    handleACNumber(event) {
        this.paymentToUpsert.Account_Number__c = event.currentTarget.value;
    }
    handleBankCode(event) {
        this.paymentToUpsert.Bank_Code__c = event.currentTarget.value;
    }
    handleBankRefCheque(event) {
        this.paymentToUpsert.Reference_Cheque_No__c = event.currentTarget.value;
    }

    bankPaymentSave() {
        console.log('this.invoiceToPay:', this.invoiceToPay);

        this.paymentError = undefined;

        if (this.invoiceToPay.length == 0) {
            this.paymentError = 'Due Invoice not available to pay';
            return;
        }
        let count = 0;
        let ifSingleInv = '';
        let invAndAmount = [];
        let invAndAmountIndex = 0;
        let salesInvCount = 0;
        let advInvCount = 0;
        let isAdvance = false;
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked) {
                invAndAmount[invAndAmountIndex] = { Id: this.invoiceToPay[i].Id, Invoice_Amount__c: this.invoiceToPay[i].AmountToPaid };
                invAndAmountIndex++;
                ifSingleInv = this.invoiceToPay[i].Id;
                count++;
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') { advInvCount++; isAdvance = true; }
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Sale') salesInvCount++;
            }
        }
        console.log('salesInvCount:', salesInvCount);
        console.log('advInvCount:', advInvCount);
        if (salesInvCount > 0 && advInvCount > 0) {
            this.paymentError = 'Can not pay sales and advance invoices together.';
            console.log('this.invoiceToPay1:', this.invoiceToPay);
            return;
        }
        if (count == 1) this.paymentToUpsert.Invoice__c = ifSingleInv;
        if (count == 0) {
            this.paymentError = 'Please select invoice to pay';
            return;
        }
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked && parseFloat(this.invoiceToPay[i].AmountToPaid) <= 0) {
                this.paymentError = this.invoiceToPay[i].Name + ' : Amount To Paid can not be zero or negative';
                return;
            }
            for (let j in this.invoiceList) {
                if (this.invoiceList[j].Id == this.invoiceToPay[i].Id && parseFloat(this.invoiceList[j].Total_Due__c) < parseFloat(this.invoiceToPay[i].AmountToPaid)) {
                    this.paymentError = this.invoiceToPay[i].Name + ' : Amount Can not be greater than due amount';
                    return;
                }
            }

        }

        if (!this.paymentToUpsert.Reference_Cheque_No__c || this.paymentToUpsert.Reference_Cheque_No__c == '') {
            this.paymentError = 'Missing Reference/Cheque No';
            return;
        }

        if (!this.paymentToUpsert.Total_Amount__c || this.paymentToUpsert.Total_Amount__c <= 0) {
            this.paymentError = 'Payment Amount can not be zero or negative';
            return;
        }

        this.spinner = true;

        if (isAdvance)
            this.paymentToUpsert.Transaction_Type__c = 'AdvancePayment';
        else
            this.paymentToUpsert.Transaction_Type__c = 'InvoicePayment';

        this.paymentToUpsert.Order__c = this.order.Id;
        this.paymentToUpsert.Accounts__c = this.order.AccountId;
        this.paymentToUpsert.Amount__c = this.paymentToUpsert.Total_Amount__c;
        if (this.order.Contact__r.FirstName) this.paymentToUpsert.First_Name__c = this.order.Contact__r.FirstName;
        if (this.order.Contact__r.LastName) this.paymentToUpsert.Last_Name__c = this.order.Contact__r.LastName;
        if (this.order.Contact__r.Email) this.paymentToUpsert.Email_Address__c = this.order.Contact__r.Email;
        if (this.order.Bill_To_Address__r.Address_Line1__c) this.paymentToUpsert.Address_Line1__c = this.order.Bill_To_Address__r.Address_Line1__c;
        if (this.order.Bill_To_Address__r.Address_Line2__c) this.paymentToUpsert.Address_Line2__c = this.order.Bill_To_Address__r.Address_Line2__c;
        if (this.order.Bill_To_Address__r.City__c) this.paymentToUpsert.City__c = this.order.Bill_To_Address__r.City__c;
        if (this.order.Bill_To_Address__r.State__c) this.paymentToUpsert.State__c = this.order.Bill_To_Address__r.State__c;
        if (this.order.Bill_To_Address__r.Country__c) this.paymentToUpsert.Country__c = this.order.Bill_To_Address__r.Country__c;
        if (this.order.Bill_To_Address__r.Postal_Code__c) this.paymentToUpsert.Zipcode__c = this.order.Bill_To_Address__r.Postal_Code__c;
        if (this.order.Organisation__c) this.paymentToUpsert.Account__c = this.order.Organisation__c;
        if (this.order.Organisation_Business_Unit__c) this.paymentToUpsert.Organisation_Business_Unit__c = this.order.Organisation_Business_Unit__c;

        this.paymentToUpsert.Type__c = 'Debit';
        this.paymentToUpsert.Payment_Type__c = 'Bank';
        this.paymentToUpsert.Status__c = 'Paid';

        console.log('this.order:', this.order);
        console.log('this.this.paymentToUpsert:', this.paymentToUpsert);
        console.log('invAndAmount:', invAndAmount);

        if (this.paymentToUpsert.Account_Type__c || this.paymentToUpsert.Account_Type__c == '') delete this.paymentToUpsert.Account_Type__c;

        bankOrCashPayment({
            payments: JSON.stringify(this.paymentToUpsert),
            invAndAmount: JSON.stringify(invAndAmount),
            paymentType: 'Bank',
        })
            .then(result => {
                console.log('result:', result);
                if (result.includes('Payment Created Successfully')) {
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: result,
                    });
                    this.dispatchEvent(event);
                    const paymentEvent = new CustomEvent('payment', {});
                    this.dispatchEvent(paymentEvent);
                    this.spinner = false;
                    this.isBankPaymentModal = false;
                }
            })
            .catch(error => {
                console.log('error:', error);
                this.paymentError = error;
                this.spinner = false;
            })



    }

    closeCashModal(event) {
        this.isCashModal = false;
        const paymentEvent = new CustomEvent('payment', {});
        this.dispatchEvent(paymentEvent);
    }

    openCashPaymentModal() {
        this.spinner = true;
        this.paymentError = undefined;
        this.paymentToUpsert.Reference_Cheque_No__c = '';
        this.paymentToUpsert.Total_Amount__c = 0;

        this.invoiceToPay = [];
        let invoiceToPayIndex = 0;
        console.log('this.invoiceList:', this.invoiceList);

        for (let i in this.invoiceList) {
            if (this.invoiceList[i].Total_Due__c > 0) {
                this.invoiceToPay.push(JSON.parse(JSON.stringify(this.invoiceList[i])));
                //Here taking separate index because it will work with the second record as well.
                this.invoiceToPay[invoiceToPayIndex].trKey = this.invoiceToPay[invoiceToPayIndex].Id + i;
                this.invoiceToPay[invoiceToPayIndex].checked = false;
                this.invoiceToPay[invoiceToPayIndex].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceList[i].Total_Due__c));
                //this.paymentToUpsert.Total_Amount__c += parseFloat(this.invoiceToPay[i].AmountToPaid);

                if (this.invoiceList[i].Posted__c) {
                    this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                } else {
                    this.invoiceToPay[invoiceToPayIndex].disableCheckbox = true;
                    if (this.invoiceToPay[invoiceToPayIndex].RecordType.DeveloperName == 'Advance')
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                }
                invoiceToPayIndex++;
            }
        }
        console.log('this.invoiceToPay:', JSON.stringify(this.invoiceToPay));

        if (this.invoiceToPay.length > 0) this.isinvoiceToPay = true;
        else this.isinvoiceToPay = false;

        console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);
        this.spinner = false;
        this.isCashModal = true;

    }
    cashPaymentSave() {
        this.paymentError = undefined;

        if (this.invoiceToPay.length == 0) {
            this.paymentError = 'Due Invoice not available to pay';
            return;
        }
        let count = 0;
        let ifSingleInv = '';
        let invAndAmount = [];
        let invAndAmountIndex = 0;
        let salesInvCount = 0;
        let advInvCount = 0;
        let isAdvance = false;
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked) {
                invAndAmount[invAndAmountIndex] = { Id: this.invoiceToPay[i].Id, Invoice_Amount__c: this.invoiceToPay[i].AmountToPaid };
                invAndAmountIndex++;
                ifSingleInv = this.invoiceToPay[i].Id;
                count++;
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') { advInvCount++; isAdvance = true; }
                if (this.invoiceToPay[i].RecordType.DeveloperName == 'Sale') salesInvCount++;
            }
        }
        if (salesInvCount > 0 && advInvCount > 0) {
            this.paymentError = 'Can not pay sales and advance invoices together.';
            return;
        }
        if (count == 1) this.paymentToUpsert.Invoice__c = ifSingleInv;
        if (count == 0) {
            this.paymentError = 'Please select invoice to pay';
            return;
        }
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked && parseFloat(this.invoiceToPay[i].AmountToPaid) <= 0) {
                this.paymentError = this.invoiceToPay[i].Name + ' : Amount To Paid can not be zero or negative';
                return;
            }
            for (let j in this.invoiceList) {
                if (this.invoiceList[j].Id == this.invoiceToPay[i].Id && parseFloat(this.invoiceList[j].Total_Due__c) < parseFloat(this.invoiceToPay[i].AmountToPaid)) {
                    this.paymentError = this.invoiceToPay[i].Name + ' : Amount Can not be greater than due amount';
                    return;
                }
            }

        }

        if (!this.paymentToUpsert.Reference_Cheque_No__c || this.paymentToUpsert.Reference_Cheque_No__c == '') {
            this.paymentError = 'Missing Reference No';
            return;
        }

        if (!this.paymentToUpsert.Total_Amount__c || this.paymentToUpsert.Total_Amount__c <= 0) {
            this.paymentError = 'Payment Amount can not be zero or negative';
            return;
        }

        this.spinner = true;

        if (isAdvance)
            this.paymentToUpsert.Transaction_Type__c = 'AdvancePayment';
        else
            this.paymentToUpsert.Transaction_Type__c = 'InvoicePayment';

        this.paymentToUpsert.Order__c = this.order.Id;
        this.paymentToUpsert.Accounts__c = this.order.AccountId;
        this.paymentToUpsert.Amount__c = this.paymentToUpsert.Total_Amount__c;
        if (this.order.Contact__r.FirstName) this.paymentToUpsert.First_Name__c = this.order.Contact__r.FirstName; console.log('this.paymentToUpsert.First_Name__c', this.paymentToUpsert.First_Name__c);
        if (this.order.Contact__r.LastName) this.paymentToUpsert.Last_Name__c = this.order.Contact__r.LastName; console.log('this.paymentToUpsert.Last_Name__c', this.paymentToUpsert.Last_Name__c);
        if (this.order.Contact__r.Email) this.paymentToUpsert.Email_Address__c = this.order.Contact__r.Email;
        if (this.order.Bill_To_Address__r.Address_Line1__c) this.paymentToUpsert.Address_Line1__c = this.order.Bill_To_Address__r.Address_Line1__c;
        if (this.order.Bill_To_Address__r.Address_Line2__c) this.paymentToUpsert.Address_Line2__c = this.order.Bill_To_Address__r.Address_Line2__c; console.log('this.paymentToUpsert.Address_Line2__c', this.paymentToUpsert.Address_Line2__c);
        if (this.order.Bill_To_Address__r.City__c) this.paymentToUpsert.City__c = this.order.Bill_To_Address__r.City__c;
        if (this.order.Bill_To_Address__r.State__c) this.paymentToUpsert.State__c = this.order.Bill_To_Address__r.State__c;
        if (this.order.Bill_To_Address__r.Country__c) this.paymentToUpsert.Country__c = this.order.Bill_To_Address__r.Country__c;
        if (this.order.Bill_To_Address__r.Postal_Code__c) this.paymentToUpsert.Zipcode__c = this.order.Bill_To_Address__r.Postal_Code__c;
        if (this.order.Organisation__c) this.paymentToUpsert.Account__c = this.order.Organisation__c;
        if (this.order.Organisation_Business_Unit__c) this.paymentToUpsert.Organisation_Business_Unit__c = this.order.Organisation_Business_Unit__c; console.log('this.paymentToUpsert.Organisation_Business_Unit__c', this.paymentToUpsert.Organisation_Business_Unit__c);

        this.paymentToUpsert.Type__c = 'Debit';
        this.paymentToUpsert.Payment_Type__c = 'Cash';
        this.paymentToUpsert.Status__c = 'Paid';

        if (this.paymentToUpsert.Account_Type__c || this.paymentToUpsert.Account_Type__c == '') delete this.paymentToUpsert.Account_Type__c;

        console.log('Payment To Upsert loading in to apex::~>', JSON.stringify(this.paymentToUpsert));
        console.log('invAndAmount loading in to apex::~>', JSON.stringify(invAndAmount));

        bankOrCashPayment({
            payments: JSON.stringify(this.paymentToUpsert),
            invAndAmount: JSON.stringify(invAndAmount),
            paymentType: 'Cash',
        })
            .then(result => {
                console.log('result:', result);
                if (result.includes('Payment Created Successfully')) {
                    this.isCashModal = false;
                    this.spinner = false;
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: result,
                    });
                    this.dispatchEvent(event);
                    const paymentEvent = new CustomEvent('payment', {});
                    this.dispatchEvent(paymentEvent);
                }
            })
            .catch(error => {
                console.log('error:', error);
                this.paymentError = error;
                this.spinner = false;
            })

    }


    openApplyCreditModal() {
        try {
            this.spinner = true;
            this.paymentError = undefined;
            this.paymentToUpsert.Reference_Cheque_No__c = '';
            this.paymentToUpsert.Total_Amount__c = 0;

            this.invoiceToPay = [];
            let invoiceToPayIndex = 0;
            console.log('this.invoiceList:', JSON.stringify(this.invoiceList));

            for (let i in this.invoiceList) {
                if (this.invoiceList[i].Total_Due__c > 0) {
                    console.log('this.invoiceList[i]:', this.invoiceList[i]);
                    this.invoiceToPay.push(JSON.parse(JSON.stringify(this.invoiceList[i])));
                    this.invoiceToPay[invoiceToPayIndex].trKey = this.invoiceToPay[invoiceToPayIndex].Id + i;
                    this.invoiceToPay[invoiceToPayIndex].checked = false;
                    this.invoiceToPay[invoiceToPayIndex].AmountToPaid = JSON.parse(JSON.stringify(this.invoiceList[i].Total_Due__c));
                    //this.paymentToUpsert.Total_Amount__c += parseFloat(this.invoiceToPay[invoiceToPayIndex].AmountToPaid);

                    if (this.invoiceList[i].Posted__c) {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    } else {
                        this.invoiceToPay[invoiceToPayIndex].disableCheckbox = true;
                        if (this.invoiceToPay[invoiceToPayIndex].RecordType.DeveloperName == 'Advance')
                            this.invoiceToPay[invoiceToPayIndex].disableCheckbox = false;
                    }
                    invoiceToPayIndex++;
                }
            }
            console.log('this.invoiceToPay:', JSON.stringify(this.invoiceToPay));

            if (this.invoiceToPay.length > 0) this.isinvoiceToPay = true;
            else this.isinvoiceToPay = false;

            console.log('this.paymentToUpsert.Total_Amount__c:', this.paymentToUpsert.Total_Amount__c);

            getInitailApplyCredit({
                accId: this.order.AccountId,
            })
                .then(result => {
                    console.log('result:', result);
                    this.availableCredits = JSON.parse(JSON.stringify(result));
                    for (let i in this.availableCredits) {
                        this.availableCredits[i].credNote.credNoteurl = '/' + this.availableCredits[i].credNote.Id;
                        this.availableCredits[i].credNote.amountDue = (parseFloat(this.availableCredits[i].credNote.Balance__c) - parseFloat(this.availableCredits[i].debitAmount)).toFixed(2);
                        this.availableCredits[i].credNote.maxValue = this.availableCredits[i].credNote.Balance__c;
                    }

                    this.isavailableCredits = this.availableCredits.length > 0 ? true : false;
                    this.spinner = false;
                    this.isApplyCreditsModal = true;
                })
                .catch(error => {
                    this.spinner = false;
                    console.log('Error:', error);
                })
        } catch (e) {
            this.spinner = false;
            console.log('Error:', e);
        }

    }
    closeApplyCreditModal() {
        this.isApplyCreditsModal = false;
        const paymentEvent = new CustomEvent('payment', {});
        this.dispatchEvent(paymentEvent);
    }

    updateDebitAmount(event) {
        console.log('event.currentTarget.value:', event.currentTarget.value);
        if (event.currentTarget.value == '') {
            this.availableCredits[event.currentTarget.dataset.index].debitAmount = 0;
        } else {
            this.availableCredits[event.currentTarget.dataset.index].debitAmount = parseFloat(event.currentTarget.value).toFixed(2);
        }
        this.availableCredits[event.currentTarget.dataset.index].credNote.amountDue = (parseFloat(this.availableCredits[event.currentTarget.dataset.index].credNote.Balance__c) - parseFloat(this.availableCredits[event.currentTarget.dataset.index].debitAmount)).toFixed(2);
        console.log('this.availableCredits[event.currentTarget.dataset.index]:', this.availableCredits[event.currentTarget.dataset.index]);
        this.appliedCreditAmount = 0;
        this.balanceAmount = 0;
        for (let i in this.availableCredits) {
            this.appliedCreditAmount = (parseFloat(this.appliedCreditAmount) + parseFloat(this.availableCredits[i].debitAmount)).toFixed(2);
            this.balanceAmount = (parseFloat(this.paymentToUpsert.Total_Amount__c) - parseFloat(this.appliedCreditAmount)).toFixed(2);
        }

    }

    applyCreditSave() {
        this.paymentError = undefined;
        this.order.Due_Amount__c

        this.paymentError = undefined;

        if (this.invoiceToPay.length == 0) {
            this.paymentError = 'Due Invoice not available to pay';
            return;
        }
        let count = 0;
        //let ifSingleInv = '';
        //let invAndAmountIndex = 0;
        //let salesInvCount = 0;
        //let advInvCount = 0;
        //let isAdvance = false;
        for (let i in this.invoiceToPay) {
            if (count > 0)
                break
            if (this.invoiceToPay[i].checked) {
                count++;
                //invAndAmount[invAndAmountIndex] = { Id: this.invoiceToPay[i].Id, Invoice_Amount__c: this.invoiceToPay[i].AmountToPaid };
                //invAndAmountIndex++;
                //ifSingleInv = this.invoiceToPay[i].Id;

                //if (this.invoiceToPay[i].RecordType.DeveloperName == 'Advance') { advInvCount++; isAdvance = true; }
                //if (this.invoiceToPay[i].RecordType.DeveloperName == 'Sale') salesInvCount++;
            }
        }
        //if (salesInvCount > 0 && advInvCount > 0) {
        //this.paymentError = 'Can not redeem sales and advance invoices together.';
        //return;
        //}
        //if (count == 1) this.paymentToUpsert.Invoice__c = ifSingleInv;
        if (count == 0) {
            this.paymentError = 'Please select invoice to apply credit';
            return;
        }
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked && parseFloat(this.invoiceToPay[i].AmountToPaid) <= 0) {
                this.paymentError = this.invoiceToPay[i].Name + ' : Amount To Paid can not be zero or negative';
                return;
            }
            for (let j in this.invoiceList) {
                if (this.invoiceList[j].Id == this.invoiceToPay[i].Id && parseFloat(this.invoiceList[j].Total_Due__c) < parseFloat(this.invoiceToPay[i].AmountToPaid)) {
                    this.paymentError = this.invoiceToPay[i].Name + ' : Amount Can not be greater than due amount';
                    return;
                }
            }

        }

        if (!this.paymentToUpsert.Total_Amount__c || this.paymentToUpsert.Total_Amount__c <= 0) {
            this.paymentError = 'Invoice Amount can not be zero or negative';
            return;
        }

        /*if (this.appliedCreditAmount > this.paymentToUpsert.Total_Amount__c) {
            this.paymentError = 'Applied Credit can not be greater than Invoice Amount';
            return;
        }*/

        if (this.balanceAmount < 0) {
            this.paymentError = 'Balance Amount can not be negative';
            return;
        }

        if (this.appliedCreditAmount <= 0) {
            this.paymentError = 'Applied Credit can not be zero or negative.';
            return;
        }

        this.spinner = true;
        let invoice2Update = {};
        for (let i in this.invoiceToPay) {
            if (this.invoiceToPay[i].checked) {
                invoice2Update.Id = this.invoiceToPay[i].Id;
                invoice2Update.Order_S__c = this.invoiceToPay[i].Order_S__c;
                invoice2Update.Name = this.invoiceToPay[i].Name;
                invoice2Update.Account__c = this.invoiceToPay[i].Account__c;
                invoice2Update.Credit_Note_Issued__c = true;
                if (this.invoiceToPay[i].Credit_Note__c)
                    invoice2Update.Credit_Note__c = (parseFloat(this.invoiceToPay[i].Credit_Note__c) + parseFloat(this.appliedCreditAmount)).toFixed(2);
                else
                    invoice2Update.Credit_Note__c = parseFloat(this.appliedCreditAmount).toFixed(2);
            }
        }

        for (let i in this.availableCredits) {
            delete this.availableCredits[i].credNote.credNoteurl;
            delete this.availableCredits[i].credNote.amountDue;
            delete this.availableCredits[i].credNote.maxValue;
        }
        console.log('invoice2Update:', invoice2Update);
        applyCreditInvoice({
            inv: JSON.stringify(invoice2Update),
            creditNotes: JSON.stringify(this.availableCredits),
            totalDebitAmount: this.appliedCreditAmount,
        })
            .then(result => {
                console.log('result:', result);
                if (result.includes('Credit Applied Successfully')) {
                    const event = new ShowToastEvent({
                        variant: 'success',
                        message: result,
                    });
                    this.dispatchEvent(event);
                    this.isApplyCreditsModal = false;
                    this.spinner = false;
                    const paymentEvent = new CustomEvent('payment', {});
                    this.dispatchEvent(paymentEvent);
                }
            })
            .catch(error => {
                console.log('Error:', error);
                this.spinner = false;
            })


    }

    openApplyLoyalty() {
        console.log('accId:', this.order.AccountId);
        console.log(' org:', this.order.ECPQ__Organisation__c);
        fetchApplyLoyaltyInitial({
            accId: this.order.AccountId,
            org: this.order.Organisation__c,
        })
            .then(result => {
                console.log("result of fetchApplyLoyaltyInitial:", result);
                this.loyalityCards = result;
                if (this.loyalityCards.length == 0)
                    this.paymentError = 'Loyalty Card not found';
                this.loyaltyValue = 0;

                this.isLoyaltyModal = true;
            })
            .catch(error => {
                console.log('Error:', error);
            })
    }
    closeApplyLoyalty() {
        this.isLoyaltyModal = false;
        this.showApplyLoyaltySave = true;
    }
    handleRedeemPoint(event) {
        this.redeemPoints = event.currentTarget.value;
        if (this.redeemPoints == '')
            this.showApplyLoyaltySave = true;
        else
            this.showApplyLoyaltySave = false;
    }

    applyLoyaltySave() {
        try {
            if (!this.redeemPoints || this.redeemPoints == '') {
                this.paymentError = 'Enter Redeem Points';
                return;
            }
            if (this.loyalityCards.length == 0) {
                this.paymentError = 'Loyalty Card not found';
                return;
            }



            applyLoyalty({
                loyalityCards: JSON.stringify(this.loyalityCards),
                ordId: this.order.Id,
                loyaltyPoints: this.redeemPoints,
            })
                .then(result => {
                    console.log('result of applyLoyalty:', result);
                    if (result.includes('Loyalty Apply Successfully')) {
                        const event = new ShowToastEvent({
                            variant: 'success',
                            message: result,
                        });
                        this.dispatchEvent(event);
                        const paymentEvent = new CustomEvent('payment', {});
                        this.dispatchEvent(paymentEvent);
                        this.isLoyaltyModal = false;

                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                })
        } catch (e) {
            console.log('Error:', e);
        }


    }



}
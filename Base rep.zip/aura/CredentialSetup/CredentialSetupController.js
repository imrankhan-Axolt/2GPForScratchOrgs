({
    closeError: function (cmp, event) {
        cmp.set("v.errorMsg", '');
    },

    initial: function (cmp, event, helper) {
        cmp.set("v.Spinner", true);
        console.log('inside initial');
        var action = cmp.get("c.fetchCredential");
        console.log('inside initial 1');
        action.setCallback(this, function (response) {
            console.log('state:', response.getState());
            if (response.getState() == "SUCCESS") {
                var res = response.getReturnValue();
                console.log("response of fetchCredential :", res);
                cmp.set("v.errorMsg", res.errorMsg);
                cmp.set("v.allCredentials", res.allCredentials);

                cmp.set("v.Spinner", false);
            } else {
                cmp.set("v.Spinner", false);
                console.log('Error :', response.getError());
                var error = response.getError();
                cmp.set("v.errorMsg", error[0].message + ' ' + error[0].stackTrace);
            }
        });
        $A.enqueueAction(action);
    },

    delcloseModal: function (component, event, helper) {
        $A.util.removeClass(component.find("delModal"), "slds-fade-in-open");
        $A.util.removeClass(component.find("delModalBackdrop"), "slds-backdrop_open");
    },

    delOpenModal: function (cmp, event) {
        console.log('inside delOpenModal');
        var credToDel = event.getSource().get("v.title");
        console.log('credToDel:', credToDel);
        cmp.set("v.credToDel", credToDel);
        $A.util.addClass(cmp.find("delModal"), "slds-fade-in-open");
        $A.util.addClass(cmp.find("delModalBackdrop"), "slds-backdrop_open");
    },

    newCredential: function (cmp, event, helper) {
        cmp.set("v.currentStatus", 'New');
        cmp.set("v.flows", "upsertCredential");
    },

    changeTabToDocusign: function (cmp, event, helper) {
        cmp.set("v.currentTab", 'Docusign');
        cmp.set("v.creType", 'eSignature');
    },

    changeTabToPayment: function (cmp, event, helper) {
        cmp.set("v.currentTab", 'Payment');
        cmp.set("v.creType", 'Payment');
    },

    changeTabToShipment: function (cmp, event, helper) {
        cmp.set("v.currentTab", 'Shipment');
        cmp.set("v.creType", 'Shipment');
    },

    changeTabToEcom: function (cmp, event, helper) {
        cmp.set("v.currentTab", 'eCommerce');
        cmp.set("v.creType", 'eComm');
    },

    ShowTabs: function (cmp, event, helper) {
        cmp.set("v.flows", 'tabs');
        cmp.set("v.cred2Upsert", {});
        //console.log('cred2Upsert:',cmp.get("v.cred2Upsert"));
        //cmp.resetForm();
        cmp.LoadInit();
    },

    resetForm: function (cmp, event) {
        var cred2Upsert = cmp.get("v.cred2Upsert");
        //cred2Upsert.Id='';
        cred2Upsert.Name = '';
        cred2Upsert.Account_Id__c = '';
        cred2Upsert.Active__c = false;
        cred2Upsert.API_Version__c = '';
        cred2Upsert.Integration_Key__c = '';
        cred2Upsert.URL__c = '';
        cred2Upsert.Base_URL__c = '';
        cred2Upsert.Security_Key__c = '';
        cred2Upsert.Encrypted_Key__c = '';
        cred2Upsert.Redirect_URI__c = '';
        cred2Upsert.Signed_Redirect_URI__c = '';
        cred2Upsert.Username_Login__c = '';
        cred2Upsert.Priority__c = '';
        cred2Upsert.Password_Transkey__c = '';
        cred2Upsert.Signature__c = '';
        cred2Upsert.Channel_Id__c = '';
        cred2Upsert.Bank_COA_ID__c = '';
        cred2Upsert.Shipper_Name__c = '';
        cred2Upsert.Title__c = '';
        cred2Upsert.Shipper_Email__c = '';
        cred2Upsert.Shipper_Phone_Number__c = '';
        cred2Upsert.Shipper_Company_Name__c = '';
        cred2Upsert.Company_URL__c = '';
        cred2Upsert.Shipper_Street__c = '';
        cred2Upsert.Shipper_City__c = '';
        cred2Upsert.Shipper_Province__c = '';
        cred2Upsert.Shipper_Postal_Code__c = '';
        cred2Upsert.Shipper_Zip4__c = '';
        cred2Upsert.Shipper_Country__c = '';
        cred2Upsert.UPS_Account_Number__c = '';
        cred2Upsert.Key__c = '';
        cred2Upsert.Channel_Id__c = '';
        cred2Upsert.Meter_Number__c = '';
        cred2Upsert.Parent_Key__c = '';
        cred2Upsert.Parent_Password__c = '';
        cred2Upsert.Label_Height__c = '';
        cred2Upsert.Label_Width__c = '';
        cmp.set("v.cred2Upsert", cred2Upsert);
    },

    saveCredential1: function (cmp, event, helper) {
        console.log('inside saveCredential');
        cmp.set("v.Spinner", true);
        var cred2Upsert = cmp.get("v.cred2Upsert");
        cred2Upsert.Type__c = cmp.get("v.creType");
        if (cred2Upsert.Name == '') {
            helper.showToast(cmp, event, 'Error!', 'Name Missing', 'error');
            cmp.set("v.Spinner", false);
            return;
        }
        if (cred2Upsert.URL__c == '') {
            helper.showToast(cmp, event, 'Error!', 'Enter the URL', 'error');
            cmp.set("v.Spinner", false);
            return;
        }
        
        var urlPattern = /^(https?:\/\/)?([a-z0-9\-]+\.)+[a-z]{2,6}(\/[^\s]*)?$/i;
        if (!urlPattern.test(cred2Upsert.URL__c)) {
            helper.showToast(cmp, event, 'Error!', 'Please enter a valid URL', 'error');
            cmp.set("v.Spinner", false);
            return;
        }

        console.log('cred2Upsert:', JSON.stringify(cred2Upsert));

        var action = cmp.get("c.saveCredential");
        action.setParams({
            credential2Insert: JSON.stringify(cred2Upsert)
        });
        action.setCallback(this, function (response) {
            if (response.getState() == 'SUCCESS') {
                var res = response.getReturnValue();
                console.log('res of saveCredential:', res);
                cmp.set("v.errorMsg", res.errorMsg);
                if (res.errorMsg.includes('There is already an item in this list with the name'))
                    cmp.set("v.errorMsg", 'There is already an item exist with this name');
                if (res.errorMsg == '') {
                    cmp.set("v.flows", 'tabs');
                    cmp.set("v.cred2Upsert", {});
                    //cmp.resetForm();
                    cmp.LoadInit();
                }

                cmp.set("v.Spinner", false);

            } else {
                cmp.set("v.Spinner", false);
                console.log("Error of saveCredential:", response.getError());
                var error = response.getError();
                cmp.set("v.errorMsg", error[0].message + ' ' + error[0].stackTrace());
            }
        });
        $A.enqueueAction(action);
    },

    editCredential: function (cmp, event, helper) {
        console.log('inside editCredential');
        cmp.set("v.currentStatus", 'Edit');
        var credToEdit = event.getSource().get("v.title");
        console.log('credToEdit:', credToEdit);
        var allCredentials = cmp.get("v.allCredentials");
        for (var i in allCredentials) {
            if (allCredentials[i].Id == credToEdit) {
                cmp.set("v.cred2Upsert", allCredentials[i]);
            }
        }
        console.log('cred2Upsert:', cmp.get("v.cred2Upsert"));
        cmp.set("v.flows", 'upsertCredential');
    },

    editPayAndShipCred: function (cmp, event, helper) {
        try {
            console.log('inside editCredential');
            cmp.set("v.currentStatus", 'Edit');
            var credToEdit = event.getSource().get("v.title");
            console.log('credToEdit:', credToEdit);
            cmp.set("v.Spinner", true);
            var action = cmp.get("c.editCredEncrp");
            action.setParams({
                credentialId: credToEdit
            });
            action.setCallback(this, function (response) {
                if (response.getState() == 'SUCCESS') {
                    cmp.set("v.Spinner", false);
                    var res = response.getReturnValue();
                    console.log(res);
                    cmp.set("v.cred2Upsert", res.editCredentials);
                } else {
                    cmp.set("v.Spinner", false);
                    console.log("Error of saveCredential:", response.getError());
                    var error = response.getError();
                    cmp.set("v.errorMsg", error[0].message + ' ' + error[0].stackTrace());
                }
            });
            $A.enqueueAction(action);
            console.log('cred2Upsert:', cmp.get("v.cred2Upsert"));
            cmp.set("v.flows", 'upsertCredential');

        } catch (error) {
            console.log('error' + error);
        }
    },

    deleteDocusign: function (cmp, event, helper) {
        cmp.set("v.Spinner", true);
        console.log('inside deleteDocusign');
        var credToDel = cmp.get("v.credToDel");
        console.log('credToDel :', credToDel);
        var action = cmp.get("c.deleteCred");
        action.setParams({
            credId2Del: credToDel
        });
        action.setCallback(this, function (response) {
            if (response.getState() == 'SUCCESS') {
                var res = response.getReturnValue();
                console.log('res of deleteCred:', res);
                cmp.set("v.errorMsg", res.errorMsg);
                cmp.set("v.Spinner", false);
                if (res.errorMsg == '') {
                    cmp.set("v.credToDel", '');
                    cmp.LoadInit();
                    helper.showToast(cmp, event, "Success!", "Credential deleted successfully.", "success");
                    console.log('after toast');
                    $A.util.removeClass(cmp.find("delModal"), "slds-fade-in-open");
                    $A.util.removeClass(cmp.find("delModalBackdrop"), "slds-backdrop_open");

                }
            } else {
                cmp.set("v.Spinner", false);
                var error = res.getError();
                console.log('Erorr of deleteCred:', error);
                cmp.set("v.errorMsg", error[0].message + '	' + error[0].stackTrace());
            }
        });
        $A.enqueueAction(action);
    },







})
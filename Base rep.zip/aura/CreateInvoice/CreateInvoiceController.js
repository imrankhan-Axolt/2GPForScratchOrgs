({
    doInit : function(comp, event, helper) { 
        console.log('do init create inv');
        //helper.fetchCurrencyIso(comp);
        comp.set("v.showMmainSpin",true);
        helper.getInstancesAndRecordTypes(comp, event, helper); 
        helper.functionalityControl(comp, event, helper);
        //helper.getInstancesAndRecordTypes1(comp, event, helper); 
        console.log('SOId:',comp.get("v.SOId"));
        console.log('StdId:',comp.get("v.StdId"));
        if(!$A.util.isEmpty(comp.get("v.SOId")))
            helper.getFieldsSetApiNameHandler(comp,'Invoice__c','createinvoice');
        else if(!$A.util.isEmpty(comp.get("v.StdId")))
            helper.getFieldsSetApiNameHandler(comp,'Invoice__c','Create_Order_Invoice');
            else{
                helper.OrderProcess(comp, event, helper);   
            }
        //comp.set("v.showMmainSpin",false);
        //helper.checkMultipleCurrency(comp);
        
        //helper.getFieldsSetApiNameHandler(comp,'Invoice__c','createinvoice');
        
        var now =  new Date();
        comp.set('v.today',now.getFullYear()+'-'+(now.getMonth()+1)+'-'+now.getDate());
        if(!$A.util.isEmpty(comp.get("v.SOId")) && comp.get("v.selectedrecordTypeMap.DeveloperName")!='On_Account_Payment'){
            comp.set("v.defaultValues",{'Order__c':comp.get("v.SOId"),'Invoice_Date__c':now.getFullYear()+'-'+(now.getMonth()+1)+'-'+now.getDate()});
            
        }
        if(!$A.util.isEmpty(comp.get("v.StdId")) && comp.get("v.selectedrecordTypeMap.DeveloperName")!='On_Account_Payment'){
            comp.set("v.defaultValues",{'Order_S__c':comp.get("v.StdId"),'Invoice_Date__c':now.getFullYear()+'-'+(now.getMonth()+1)+'-'+now.getDate()});
            
        }
        
    },
    
    cancel : function(comp, event, helper) {
        
        if(comp.get("v.FromAR")){
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:AccountsReceivable",
                componentAttributes: {
                    "showTabs" : 'inv'
                }
            });
            evt.fire();
        }else if(comp.get("v.StdId") != ''){
            console.log('StdId:',comp.get("v.StdId"));
            try{
                
                /*var workspaceAPI = comp.find("workspace");
                workspaceAPI.getFocusedTabInfo().then(function(response) {
                    var focusedTabId = response.tabId;
                    workspaceAPI.closeTab({tabId: focusedTabId});
                })
                .catch(function(error) {
                    console.log(error);
                });*/
                /*window.setTimeout(
                    $A.getCallback(function() {
                        window.close();                        
                    }), 1000
                );*/
            }catch(e){console.log('Error:',e);}
            
            //let url='www.google.com';
            //location.replace("www.google.com");
            
            /**/
            //window.location.replace(url);
            //window.history.pushState('', '', 'www.google.com');
            //history.back();
            /*var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": comp.get("v.StdId"),
            });
            navEvt.fire(); */
            
        } else{
            history.back();
        } 
        
    },
    
    displayNext : function(c, e, h) {
        c.set("v.NDisplay",true);
    },
    
    next : function(c, e, h) {
        let valArr = c.find("invoiceRecordType").get("v.value").split('@');
        
        if(valArr.length>1){
            c.set("v.selectedrecordTypeMap",{'RecordTypeId':valArr[0],'DeveloperName':valArr[1]});
        }
        if(c.get("v.selectedrecordTypeMap.DeveloperName")==='On_Account_Payment'){
            var invilist = [];
            invilist.push({'Total_Price__c':0.00,'Sub_Total__c':0.00,'Description__c':'','VAT_Amount__c':0.00});
            console.log('invilist : ',invilist);
            c.set("v.INVLIList",invilist);
        }
        console.log('INVLIList : ',c.get("v.INVLIList"));
    },
    
    handleInvoiceSuccess: function(cmp, event, helper) {
        
        var payload = event.getParams().response;
        
        cmp.set("v.invrecordId",payload.id);
        if(payload.id)
            helper.CreateInvoiceAndLineItem(cmp,event,helper);
    },
    onchangeInvoiceField: function(cmp, event, helper) {
        
        var sourceField = event.getSource();
        
        switch(sourceField.get("v.fieldName")) {
            case 'Order__c':
                if(cmp.get("v.selectedrecordTypeMap.DeveloperName")!='On_Account_Payment'){
                    
                    cmp.set("v.SO_Id",sourceField.get("v.value"));
                    cmp.set("v.SOId",sourceField.get("v.value"));
                    console.log('getInvoiceLineItem 1:');
                    helper.getInvoiceLineItem(cmp);
                    helper.fetchOrderInfo(cmp);
                    helper.fetchScheduleInvoices(cmp);
                }
                break;
            case 'Order_S__c':
                if(cmp.get("v.selectedrecordTypeMap.DeveloperName")!='On_Account_Payment'){
                    
                    cmp.set("v.Std_Id",sourceField.get("v.value"));
                    cmp.set("v.StdId",sourceField.get("v.value"));
                    console.log('getInvoiceLineItem 2:');
                    helper.getInvoiceLineItem(cmp);
                    helper.fetchStnOrderInfo(cmp);
                    helper.fetchScheduleInvoices(cmp);
                }
                break;
            case 'Account__c':
                if(cmp.get("v.selectedrecordTypeMap.DeveloperName")==='On_Account_Payment'){
                    helper.getAccountInformation(cmp,sourceField.get("v.value"));
                    var invliList =  cmp.find("invli");
                    for(let x in invliList)
                        invliList[x].set("v.disabled",false);
                }
                // fetch Tax percentage from customer profile
                break;
            default:
                // code block
        }
    },
    setDefaultValues : function(component, event, helper) {
        console.log('inside setDefaultValues:');
        if($A.util.isUndefinedOrNull(component.get("v.invrecordId"))){
            helper.setDefaulthandler(component);
            
            if(!$A.util.isEmpty(component.get("v.SOId"))){  
                component.set("v.SO_Id",component.get("v.SOId"));
                helper.fetchTotalDownPayment(component);
                console.log('getInvoiceLineItem 3:');
                helper.getInvoiceLineItem(component);
                helper.fetchOrderInfo(component);
                helper.fetchScheduleInvoices(component);
            }
            if(!$A.util.isEmpty(component.get("v.StdId"))){  
                component.set("v.Std_Id",component.get("v.StdId"));
                helper.fetchTotalDownPayment(component);
                console.log('getInvoiceLineItem 4:');
                helper.getInvoiceLineItem(component);
                helper.fetchStnOrderInfo(component);
                helper.fetchScheduleInvoices(component);
            }
        }
    },
    handleSubmit: function(component, event, helper) {
        
        event.preventDefault();       // stop the form from submitting
        var fields = event.getParam('fields');
        fields.RecordTypeId = component.get("v.selectedrecordTypeMap").RecordTypeId ;
        component.find('invoiceEditForm').submit(fields);
    },
    calculateDownPaymentPercentage: function(component, event, helper) {
        
        var renderedFields = component.find("inv_input_field");
        for(var  x in renderedFields){ 
            if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                shippingPrice = renderedFields[x].get("v.value"); 
                break;
            }
        }
    },
    calculateDownPaymentAmt: function(component, event, helper) { 
        
        var val = event.getSource().get("v.value");
        if(val>=1 && val<=100){
            var renderedFields = component.find("inv_input_field");
            var downPaymentAmt = component.find("downPaymentAmt");
            for(var  x in renderedFields){ 
                if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c')
                    if(downPaymentAmt != undefined) downPaymentAmt.set("v.value",(renderedFields[x].get("v.value") * val)/100);
                if(renderedFields[x].get('v.fieldName')==='Total_Down_Payment_Amount__c'){
                    component.set("v.downPaymentAmount", downPaymentAmt.get("v.value"));
                    renderedFields[x].set('v.value',downPaymentAmt.get("v.value"));
                }
                    
                if(renderedFields[x].get('v.fieldName')==='Down_Payment__c'){
                    component.set("v.downPaymentPercentage",val);
                    renderedFields[x].set('v.value',val);
                }
                    
                
                
            }
        }  
    },
    updateTotalPrice : function(component, event, helper) {
        component.set("v.changeTD", true);
        if(component.get("v.TDPayment")=='' || component.get("v.TDPayment")==null || component.get("v.TDPayment")==undefined){
            component.set("v.TDPayment", 0);
        }
        var renderedFields = component.find("inv_input_field");
        //var downPaymentAmt = component.find("downPaymentAmt");
        for(var  x in renderedFields){ 
            if(renderedFields[x].get('v.fieldName')==='Total_Down_Payment_Amount__c')
                renderedFields[x].set('v.value',component.get("v.TDPayment"));
        }
        helper.updateTotalPrice_Handler(component);
    },
    addInvoiceLineItem:function(comp,event,helper){
        
        var ILIList=[];
        ILIList=comp.get("v.ILIList");
        var action = comp.get("c.getInvoiceAndLineItemInstance");    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (comp.isValid() && state === "SUCCESS") {  
                if(ILIList==null) ILIList=response.getReturnValue();
                else ILIList.push(response.getReturnValue());  
                comp.set("v.ILIList",ILIList);    
            }else{
                console.log('Error:',response.getError());
            }       
        });
        $A.enqueueAction(action);  
    },
    
    getDelete:function(comp,event,helper){
        
        var Index=event.getSource().get("v.value");//event.currentTarget.dataset.service;  
        var INVLIList=comp.get("v.INVLIList");   
        
        INVLIList.splice(Index,1);
        comp.set("v.INVLIList",INVLIList);
        helper.updateTotalPrice_Handler(comp);        
    }, 
    
    CreateInvoiceAndLineItem:function(comp,event,helper){
        try{
            console.log('CreateInvoiceAndLineItem');
            if(comp.get("v.selectedrecordTypeMap.DeveloperName")==='Schedule_Invoice'){
                var remainingAmount = (comp.get("v.advancePaymentPaidAmount") - comp.get("v.TotalPaidAmountApplied"));
                console.log('remainingAmount 556677: ',remainingAmount);
                console.log('PaidAmountApplied : ',comp.get("v.PaidAmountApplied"));
                if(comp.get("v.PaidAmountApplied") > remainingAmount.toFixed(2)){//Moin Added this .toFixed(2)
                    console.log('in');
                    comp.set("v.showToast",true);
                    comp.set("v.message","Paid amount applied is greater than advance payment");
                    window.setTimeout(
                        $A.getCallback(function() {
                            comp.set("v.showToast",false);               
                        }), 5000
                    );
                    return;
                }else{
                    console.log('inhere else');
                }
                
            }
            comp.set("v.showMmainSpin",true);
            
            if(comp.get("v.selectedrecordTypeMap.DeveloperName")==='On_Account_Payment'){
                var invli = comp.find("invli");
                var valid = true;
                for(var x in invli){
                    if(invli[x].get("v.required") && (!invli[x].checkValidity() || invli[x].get("v.value")== 0.00)){
                        invli[x].setCustomValidity('Value must be > 0.00');
                        valid = false;
                    }else
                        invli[x].setCustomValidity('');
                    invli[x].showHelpMessageIfInvalid();
                }
                if(valid){
                    comp.find("RecordTypeId").set("v.value",comp.get("v.selectedrecordTypeMap").RecordTypeId);
                    comp.find("invoiceEditForm").submit();
                } else{
                    comp.set("v.showToast",true);
                    comp.set("v.message","Review All Error Messages");
                    
                    setTimeout(
                        $A.getCallback(function() {
                            comp.set("v.showToast",false);
                        }), 3000
                    );
                    //helper.showToast('error','error','Review All Error Messages');
                }
            }
            else{
                var actualInvLIIndex=comp.get('v.actualInvLIIndex');
                
                console.log('v.subTotal~>'+comp.get('v.subTotal'));
                console.log('v.invTax~>'+comp.get('v.invTax'));
                console.log('v.schInvAmount~>'+comp.get('v.schInvAmount'));
                console.log('v.schInvCreditAmount~>'+comp.get('v.schInvCreditAmount'));
                
                var tatalamount = parseFloat(comp.get("v.subTotal"))+parseFloat(comp.get("v.invTax"))+parseFloat(comp.get("v.schInvAmount")) - parseFloat(comp.get("v.schInvCreditAmount"));//+ parseFloat(comp.get("v.AmountPaid"))
                tatalamount = tatalamount.toFixed(2);
                //alert(tatalamount);
                console.log('tatalamount : ',tatalamount);
                console.log('v.salesorder.Order_Amount__c~>'+comp.get('v.salesorder.Order_Amount__c'));
                console.log('v.orderAmount~>'+comp.get('v.orderAmount'));
                try{
                    if(comp.get("v.AmountPaid") == undefined || comp.get("v.AmountPaid") == null){
                        comp.set("v.AmountPaid",0);
                    } 
                    if(comp.get("v.AmountPaid") == '') comp.set("v.AmountPaid",0);
                    console.log('v.AmountPaid~>'+comp.get('v.AmountPaid'));
                    
                    if(actualInvLIIndex.length==0){
                        comp.set("v.showToast",true);
                        comp.set("v.message","Please select the invoice Line Item.");
                        
                        setTimeout(
                            $A.getCallback(function() {
                                comp.set("v.showToast",false);
                            }), 3000000
                        );
                        comp.set("v.showMmainSpin",false);
                        //helper.showToast('error','error','Please select the invoice Line Item');
                    }else if(comp.get("v.selectedrecordTypeMap.DeveloperName")==='Schedule_Invoice' && tatalamount > parseFloat(comp.get('v.orderAmount'))){
                        comp.set("v.showToast",true);
                        comp.set("v.message","Sum of scheduled amount is greater then order amount");
                        
                        setTimeout(
                            $A.getCallback(function() {
                                comp.set("v.showToast",false);
                            }), 3000
                        );
                        comp.set("v.showMmainSpin",false);
                    }else if(comp.get("v.selectedrecordTypeMap.DeveloperName")==='Advance' && (comp.get("v.downPaymentAmount")<=0 || $A.util.isEmpty(comp.get("v.downPaymentAmount")))){
                        comp.set("v.showToast",true);
                        comp.set("v.message","Please Enter the Down Payment Percentage or Amount");
                        
                        setTimeout(
                            $A.getCallback(function() {
                                comp.set("v.showToast",false);
                            }), 3000
                        );
                        comp.set("v.showMmainSpin",false);
                    }else if(comp.get("v.selectedrecordTypeMap.DeveloperName")==='Advance' && (comp.get("v.downPaymentPercentage")>100 || $A.util.isEmpty(comp.get("v.downPaymentPercentage")))){
                        comp.set("v.showToast",true);
                        comp.set("v.message","Down Payment Amount is more than 100%");
                        
                        setTimeout(
                            $A.getCallback(function() {
                                comp.set("v.showToast",false);
                            }), 3000
                        );
                        comp.set("v.showMmainSpin",false);
                    }else if(comp.get("v.AmountPaid") != undefined && comp.get("v.AmountPaid") != null && comp.get("v.AmountPaid") > 0 && comp.get("v.PaidAmountApplied")!=null && comp.get("v.PaidAmountApplied")!=undefined && comp.get("v.PaidAmountApplied") > 0 && comp.get("v.PaidAmountApplied")>comp.get("v.AmountPaid")){
                        console.log('in here Paid Amount Applied is greater then the Advance Payment');
                        comp.set("v.showToast",true);
                        comp.set("v.message","Paid Amount Applied is greater then the Advance Payment");
                        
                        setTimeout(
                            $A.getCallback(function() {
                                comp.set("v.showToast",false);
                            }), 3000
                        );
                        comp.set("v.showMmainSpin",false);
                    }else{
                        console.log('in here here');
                        var invli = comp.find("invli");
                        var valid = true;
                        if($A.util.isUndefined((invli.length))){
                            invli.checkValidation();
                            if(!invli.get("v.validate")) valid = false;
                        }else{
                            for(var x in invli){
                                invli[x].checkValidation();
                                if(!invli[x].get("v.validate"))
                                    valid = false;   
                            }
                        }
                        
                        if(valid){
                            comp.find("RecordTypeId").set("v.value",comp.get("v.selectedrecordTypeMap").RecordTypeId);
                            helper.showToast('success','success','Invoice Created Successfully');
                            setTimeout(
                                $A.getCallback(function() {
                                    comp.find("invoiceEditForm").submit();
                                }), 2000
                            );
                        }
                        else{
                            
                            comp.set("v.showToast",true);
                            comp.set("v.message","Review All Error Messages");
                            
                            setTimeout(
                                $A.getCallback(function() {
                                    comp.set("v.showToast",false);
                                }), 3000
                            );
                            //helper.showToast('error','error','Review All Error Messages');
                            comp.set("v.showMmainSpin",false);
                        }
                    }
                }catch(e){
                    console.log('arshad err1',e);
                }
            } 
            
        }catch(e){
            console.log('arshad err2',e);
        }
    },
    
    calculateAmount:function(comp,event,helper){
        
        var invli = comp.get("v.INVLIList");
        var fields = comp.find("invli");
        var tax = 0.00;
        var taxAmount =0.00;
        var totalAmount = 0.00;
        for(let x in fields)
            if(fields[x].get("v.name")==='tax'){
                tax=fields[x].get("v.value");
                break;
            }
        
        for(var x in invli){
            taxAmount = parseFloat(tax)*invli[x].Sub_Total__c;
            invli[x].VAT_Amount__c = taxAmount; 
            totalAmount =  parseFloat(invli[x].VAT_Amount__c) + parseFloat(invli[x].Sub_Total__c);
            invli[x].Total_Price__c = totalAmount;
            
        }
        console.log('invli : ',invli);
        comp.set("v.INVLIList",invli);
        var renderedFields = comp.find("inv_input_field");
        
        for(var  x in renderedFields){
            if( renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                renderedFields[x].set("v.value",taxAmount);
                component.set("v.invTax", taxAmount);
            }
            if( renderedFields[x].get('v.fieldName')==='Invoice_Amount__c')
                renderedFields[x].set("v.value",totalAmount);
            // if( renderedFields[x].get('v.fieldName')==='Invoice_Shipping_Amount__c')
            //   renderedFields[x].set("v.value",100);
        }
        
    },
    
    /*fetchInvoiceLineItems:function(comp,event,helper){
        
        var ILIList=[];//comp.get("v.ILIList");  
        console.log('getInvoiceLineItem 5:');
        var action = comp.get("c.getInvoiceLineItem");
        action.setParams({
            "SOId":comp.get("v.Invoice.Order__c") //InvoiceOrder.Id Invoice.Order__c.Id
        });  
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (comp.isValid() && state === "SUCCESS") {  
                
                for(var i in response.getReturnValue()) 
                    ILIList.push(response.getReturnValue()[i]);
                
                //comp.set("v.ILIList",ILIList);
                
            }else{
                console.log('Error:',response.getError());
            }         
        });
        $A.enqueueAction(action);  
        
    },*/
    
    cancelCreateInvoiceAndLineItem:function(comp,event,helper){ 
        
        if(comp.get("v.FromAR")){
            $A.createComponent(
                "c:AccountsReceivable", {  
                    "showTabs":comp.get("v.showTabs"),
                    "fetchRecordsBool":false,
                    "Organisation":comp.get("v.Organisation")
                },
                function(newComp) {
                    var content = comp.find("body");
                    content.set("v.body", newComp);
                }
            );
        }else {
            history.back(); 
            /*if(comp.get("v.SOId")==undefined || comp.get("v.SOId")=='' || comp.get("v.SOId")==null || comp.get("v.StdId")==undefined || comp.get("v.StdId")=='' || comp.get("v.StdId")==null){  
            $A.createComponent(
                "c:AccountsReceivable", {  
                    "showTabs":comp.get("v.showTabs"),
                    "fetchRecordsBool":false,
                    "Organisation":comp.get("v.Organisation")
                },
                function(newComp) {
                    var content = comp.find("body");
                    content.set("v.body", newComp);
                }
            );
        }else {
            history.back(); 
            }
            */
            
        } 
        
    },
    
    CancelCalled : function(comp, event, helper){
        
        if(comp.get("v.FromAR")){
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:AccountsReceivable",
                componentAttributes: {
                    "showTabs" : 'inv'
                }
            });
            evt.fire();
        }
        else{
            history.back();
        } 
    },
    
    getallinvoiceLI : function(cmp, event, helper){
        try{
            let checked = false;  
            if(event != undefined){ 
                checked = event.getSource().get("v.checked"); 
                console.log('checked : ',checked);
                var allbbox = cmp.find("boxPack");
                if(allbbox.length>0){
                    for(var x in allbbox) allbbox[x].set("v.value",checked);
                }else allbbox.set("v.value",checked);
                var actualInvLIIndex = [];//cmp.get('v.actualInvLIIndex');
                var actualInvLI = [];//cmp.get('v.actualInvLI');
                var invli=cmp.get("v.INVLIList");
                
                if(checked){
                    cmp.set("v.allChecked",true);
                    for(var ind in invli ){
                        actualInvLIIndex.push(ind); 
                        actualInvLI.push(invli[ind]);
                        cmp.set('v.actualInvLI',actualInvLI); 
                        cmp.set('v.actualInvLIIndex',actualInvLIIndex); 
                    }
                }
                else{
                    cmp.set("v.allChecked",false);
                    var INVLIList=cmp.get("v.INVLIList");
                    var actList=[];
                    var actINVList=[];
                    /*for(var j in INVLIList){
                actINVList.push(j);
            }*/
                    cmp.set('v.actualInvLI',actList);
                    cmp.set("v.actualInvLIIndex",actINVList);
                    
                }
            }
            helper.updateTotalPrice_Handler(cmp);
        }catch(err){
            console.log('err : ',err);
        }
    },
    
    getinvoiceLI : function(cmp, event, helper){
        
        var allbbox = cmp.find("select");
        allbbox.set("v.checked",false);
        var actualInvLIIndex = cmp.get('v.actualInvLIIndex');
        var actualInvLI = cmp.get('v.actualInvLI');
        
        var invli=cmp.get("v.INVLIList");
        
        if(event.getSource().get("v.checked")){
            
            for(var ind in invli ) {
                if(ind==event.getSource().get("v.name")){
                    actualInvLIIndex.push(ind); 
                    actualInvLI.push(invli[ind]);
                    cmp.set('v.actualInvLI',actualInvLI); 
                    cmp.set('v.actualInvLIIndex',actualInvLIIndex); 
                    
                }
                
            }
            
        }
        else{
            
            var INVLIList=cmp.get("v.actualInvLIIndex");
            var actList=[];
            var index=event.getSource().get("v.name");
            var act=cmp.get('v.actualInvLI');
            var actINVList=[];
            for(var j in INVLIList){
                if(INVLIList[j]!=index){
                    actList.push(act[j]);
                    actINVList.push(INVLIList[j]);
                }
            }
            cmp.set('v.actualInvLI',actList);
            cmp.set("v.actualInvLIIndex",actINVList);
            
        }
        helper.updateTotalPrice_Handler(cmp);
    },
    
    onCheck : function(c, e, h){
        
        var shipping_tax_ammount =0,old=0,shipping_amount = 0;
        
        
        if(c.get('v.enableShipping'))
        {shipping_tax_ammount=c.get('v.salesorder.Shipping_VAT__c');
         shipping_amount=c.get('v.salesorder.Total_Shipping_Amount__c');
         if(shipping_tax_ammount==null || shipping_tax_ammount=='')shipping_tax_ammount=0;
         if(shipping_amount==null || shipping_amount=='')shipping_amount=0;
         var renderedFields = c.find("inv_input_field");
         for(var  x in renderedFields){
             if(renderedFields[x].get('v.fieldName')==='Invoice_Shipping_Amount__c'){
                 old = renderedFields[x].get("v.value");
                 if(old==null || old=='')old=0;
                 renderedFields[x].set("v.value",parseFloat(old+shipping_amount)); 
             }   
             if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                 old = renderedFields[x].get("v.value");
                 if(old==null || old=='')old=0;
                 renderedFields[x].set("v.value",parseFloat(old+shipping_tax_ammount)); 
             }
             if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                 old = renderedFields[x].get("v.value");
                 if(old==null || old=='')old=0;
                 renderedFields[x].set("v.value",parseFloat(old+shipping_tax_ammount+shipping_amount));
             }
         }
        }
        else{
            shipping_tax_ammount=c.get('v.salesorder.Shipping_VAT__c');
            shipping_amount=c.get('v.salesorder.Total_Shipping_Amount__c');
            if(shipping_tax_ammount==null || shipping_tax_ammount=='')shipping_tax_ammount=0;
            if(shipping_amount==null || shipping_amount=='')shipping_amount=0;
            var renderedFields = c.find("inv_input_field");
            for(var  x in renderedFields){
                if(renderedFields[x].get('v.fieldName')==='Invoice_Shipping_Amount__c'){
                    old = renderedFields[x].get("v.value");
                    if(old==null || old=='')old=0;
                    renderedFields[x].set("v.value",parseFloat(old-shipping_amount)); 
                } 
                if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                    old = renderedFields[x].get("v.value");
                    if(old==null || old=='')old=0;
                    renderedFields[x].set("v.value",parseFloat(old-shipping_tax_ammount)); 
                }
                if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                    old = renderedFields[x].get("v.value");
                    if(old==null || old=='')old=0;
                    renderedFields[x].set("v.value",parseFloat(old-shipping_tax_ammount-shipping_amount));
                }
            }
        }
        
        
    },
    
    calculateDownPaymentPercentag: function(component, event, helper) {
        
        var val = event.getSource().get("v.value");
        var renderedFields = component.find("inv_input_field");
        //if(val>0 && val<=96){
        var renderedFields = component.find("inv_input_field");
        var downPayment = component.find("downPayment");
        for(var  x in renderedFields){ 
            if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                if(downPayment != undefined) downPayment.set("v.value",((val/renderedFields[x].get("v.value"))*100).toFixed(2));
            }
            
            if(renderedFields[x].get('v.fieldName')==='Down_Payment__c'){
                component.set("v.downPaymentPercentage",downPayment.get("v.value"));
                renderedFields[x].set('v.value',downPayment.get("v.value"));
            }
            if(renderedFields[x].get('v.fieldName')==='Total_Down_Payment_Amount__c'){
                renderedFields[x].set('v.value',val);
                component.set("v.downPaymentAmount", val);
            }
                
            
            
            // }
        }  
    },
    
    calculateInvoiceAmount : function(component, event, helper) {
        try{
            var val = event.getSource().get("v.value");
            var renderedFields = component.find("inv_input_field");
            //var renderedFields = component.find("inv_input_field");
            var downPaymentAmtSales = component.find("downPaymentAmtSales");
            if(val == null || val == undefined || val == '') val = 0;
            if(val!=null && val!=undefined && val!=''){
                var subTotal = 0.00;//component.get("v.")
                var invli = component.get("v.actualInvLI");
                for(var x in invli){
                    subTotal += parseFloat(invli[x].Sub_Total__c);
                }
                
                for(var  x in renderedFields){ 
                    if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                        renderedFields[x].set('v.value',((subTotal*val)/100).toFixed(2));
                        component.set("v.subTotal", ((subTotal*val)/100).toFixed(2));
                        //component.set("v.InvAmount",((subTotal*val)/100).toFixed(2));
                        console.log('inv amt set here '+((subTotal*val)/100).toFixed(2));
                    }
                    if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                        renderedFields[x].set('v.value',0.00);
                        component.set("v.invTax", 0.00);
                        console.log('inv tax set here 0');
                    }
                    if(renderedFields[x].get('v.fieldName')==='Paid_Amount_Applied__c'){
                        renderedFields[x].set('v.value',((component.get("v.AmountPaid")*val)/100).toFixed(2));
                        var paidAmountApplied = component.find("paidAmountApplied");
                        if(paidAmountApplied != undefined) paidAmountApplied.set("v.value",((component.get("v.AmountPaid")*val)/100).toFixed(2));
                        component.set("v.PaidAmountApplied", ((component.get("v.AmountPaid")*val)/100).toFixed(2));
                        console.log('PaidAmountApplied 2: ',component.get("v.PaidAmountApplied"));
                    }
                    if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Percentage__c'){
                        console.log('inhere1');
                        renderedFields[x].set('v.value',val);
                    }
                    if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Tax_Percentage__c'){
                        console.log('inhere2');
                        renderedFields[x].set('v.value',0.00); 
                    }
                }
                console.log('inhere3');
                var downPaymentAmtSales = component.find("downPaymentAmtSales");
                if(downPaymentAmtSales != undefined) downPaymentAmtSales.set("v.value",val);
                var downPaymentTax = component.find("downPaymentTax");
                
                console.log('inhere4');
                //alert(downPaymentTax);
                if(!component.get("v.disSchTax") && component.get("v.subTotal") > 0 && component.get("v.taxAmount")>0){ 
                    console.log('inhere5');
                    if(downPaymentTax!=undefined) downPaymentTax.set("v.value",parseFloat($A.get("$Label.c.Default_schedule_invoice_Tax")));
                    var val = parseFloat($A.get("$Label.c.Default_schedule_invoice_Tax"));
                    var renderedFields = component.find("inv_input_field");
                    var downPaymentAmtSales = component.find("downPaymentTax");
                    console.log('inhere6');
                    if(val!=null && val!=undefined && val!=''){
                        console.log('inhere7');
                        var invAmount = 0.00;
                        var TaxAmount = 0.00;
                        for(var  x in renderedFields){ 
                            if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                                TaxAmount = ((component.get("v.subTotal")*val)/100).toFixed(2);
                                renderedFields[x].set('v.value',TaxAmount);
                                component.set("v.invTax", TaxAmount);
                                console.log('inv tax set here 1~>'+TaxAmount);
                            }
                            if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Tax_Percentage__c'){
                                renderedFields[x].set('v.value',val);
                            }
                        }
                        
                        for(var  x in renderedFields){ 
                            if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                                var invoiceAmount = parseFloat(component.get("v.subTotal"))+parseFloat(TaxAmount);
                                renderedFields[x].set('v.value',invoiceAmount);
                                component.set("v.InvAmount",invoiceAmount);
                                console.log('inv amt set here 2~>'+invoiceAmount);
                            }
                        }
                        var downPaymentTax = component.find("downPaymentTax");
                        if(downPaymentTax != undefined) downPaymentTax.set("v.value",val);
                        console.log('inhere8');
                    }
                    console.log('inhere9');
                }else{
                    console.log('inhere10');
                    for(var  x in renderedFields){ 
                        if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                            var invoiceAmount = parseFloat(component.get("v.subTotal"));
                            renderedFields[x].set('v.value',invoiceAmount);
                            component.set("v.InvAmount",invoiceAmount);
                            console.log('inv amt set here 2~>'+invoiceAmount);
                        }
                    }
                    if(downPaymentTax != undefined) downPaymentTax.set("v.value",0.00);
                }
                console.log('inhere11');
            }else{
                console.log('inhere12');
                var downPaymentAmtSales = component.find("downPaymentTax");
                if(downPaymentAmtSales!=undefined) downPaymentAmtSales.set("v.value",0.00);
                component.set("v.subTotal", 0.00);
                console.log('inhere13');
                for(var  x in renderedFields){
                    if(renderedFields[x].get('v.fieldName')==='Paid_Amount_Applied__c'){
                        renderedFields[x].set('v.value',0);
                        var paidAmountApplied = component.find("paidAmountApplied");
                        if(paidAmountApplied != undefined) paidAmountApplied.set("v.value",0);
                        component.set("v.PaidAmountApplied", 0);
                        console.log('PaidAmountApplied 2: ',component.get("v.PaidAmountApplied"));
                    }
                    if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                        renderedFields[x].set('v.value',0);
                        component.set("v.subTotal", 0);
                        component.set("v.InvAmount",0);
                    }
                }
                $A.enqueueAction(component.get("c.getallinvoiceLI"));
            }
        }catch(e){
            console.log('err',e);
        }
    },
    
    updateInvoicePercentage : function(component, event, helper) {
        var amount = component.get("v.subTotal");
        if(amount>0){
            var downPaymentAmtSales = component.find("downPaymentAmtSales");
            var percentage= (amount/component.get("v.invLineSubTotal"))*100;
            if(downPaymentAmtSales != undefined) downPaymentAmtSales.set("v.value",percentage.toFixed(2));
            if(amount>0){
                //downPaymentTax.set("v.value",parseFloat($A.get("$Label.c.Default_schedule_invoice_Tax")));
                var val = parseFloat($A.get("$Label.c.Default_schedule_invoice_Tax"));
                var renderedFields = component.find("inv_input_field");
                var downPaymentAmtSales = component.find("downPaymentTax");
                if(val!=null && val!=undefined && val!=''){
                    var invAmount = 0.00;
                    var TaxAmount = 0.00;
                    for(var  x in renderedFields){ 
                        if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c' && component.get("v.taxAmount")>0){
                            TaxAmount = ((component.get("v.subTotal")*val)/100).toFixed(2);
                            renderedFields[x].set('v.value',TaxAmount);
                            component.set("v.invTax", TaxAmount);
                        }
                        if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                            var invoiceAmount = parseFloat(component.get("v.subTotal"))+parseFloat(TaxAmount);
                            renderedFields[x].set('v.value',invoiceAmount);
                        }
                        if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Tax_Percentage__c' && component.get("v.taxAmount")>0){
                            renderedFields[x].set('v.value',val);
                        }
                    }
                    var downPaymentTax = component.find("downPaymentTax");
                    if(component.get("v.taxAmount")>0 && downPaymentTax!=undefined) downPaymentTax.set("v.value",val);
                }
            }
        }else{
            var downPaymentAmtSales = component.find("downPaymentAmtSales");
            if(downPaymentAmtSales != undefined) downPaymentAmtSales.set("v.value",0.00);
            var renderedFields = component.find("inv_input_field");
            for(var  x in renderedFields){ 
                if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                    renderedFields[x].set('v.value',0.00);
                    component.set("v.invTax", 0.00);
                }
                if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                    renderedFields[x].set('v.value',0.00);
                }
                if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Tax_Percentage__c'){
                    renderedFields[x].set('v.value',0.00);
                }
            }
        }
    },
    
    calculateIvoiceTaxAmount : function(component, event, helper) {
        
        var val = event.getSource().get("v.value");
        var renderedFields = component.find("inv_input_field");
        //var renderedFields = component.find("inv_input_field");
        var downPaymentAmtSales = component.find("downPaymentTax");
        if(val!=null && val!=undefined && val!=''){
            var invAmount = 0.00;
            var TaxAmount = 0.00;
            /*for(var  x in renderedFields){ 
                if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                    invAmount = renderedFields[x].get('v.value');
                }
            }*/
            
            for(var  x in renderedFields){ 
                if(renderedFields[x].get('v.fieldName')==='Tax_Amount__c'){
                    TaxAmount = ((component.get("v.subTotal")*val)/100).toFixed(2);
                    renderedFields[x].set('v.value',TaxAmount);
                    component.set("v.invTax", TaxAmount);
                }
                if(renderedFields[x].get('v.fieldName')==='Invoice_Amount__c'){
                    //alert(component.get("v.subTotal"));
                    var invoiceAmount = parseFloat(component.get("v.subTotal"))+parseFloat(TaxAmount);
                    renderedFields[x].set('v.value',invoiceAmount);
                }
                if(renderedFields[x].get('v.fieldName')==='Sales_Invoice_Tax_Percentage__c'){
                    renderedFields[x].set('v.value',val);
                }
            }
            var downPaymentTax = component.find("downPaymentTax");
            if(downPaymentTax!=undefined) downPaymentTax.set("v.value",val);
        }
    },
    
    closePopup : function(cmp){
        cmp.set("v.showToast",false);
    }, 
    
    
    setAmountApplied : function(component, event, helper) {
        try{        
            var val = event.getSource().get("v.value");
            console.log('val : ',val);
            console.log('advancePaymentPaidAmount: ',component.get("v.advancePaymentPaidAmount"));
            console.log('TotalPaidAmountApplied: ',component.get("v.TotalPaidAmountApplied"));
            var remainingAmount = (component.get("v.advancePaymentPaidAmount") - component.get("v.TotalPaidAmountApplied"));
            console.log('remainingAmount 555555: ',remainingAmount);
            if(val > remainingAmount.toFixed(2)){//Moin added this .toFixed(2)
                console.log('in 4: ');
                component.set("v.showToast",true);
                component.set("v.message","Paid amount applied is greater than advance payment");
                component.set("v.PaidAmountApplied",remainingAmount.toFixed(2));
                var paidAmountApplied = component.find("paidAmountApplied");
                if(paidAmountApplied != undefined) paidAmountApplied.set("v.value",remainingAmount.toFixed(2));
                var renderedFields = component.find("inv_input_field");
                for(var  x in renderedFields){ 
                    if(renderedFields[x].get('v.fieldName')==='Paid_Amount_Applied__c'){
                        renderedFields[x].set('v.value',remainingAmount.toFixed(2));
                    }
                }
                console.log('PaidAmountApplied 4: ',component.get("v.PaidAmountApplied"));
                window.setTimeout(
                    $A.getCallback(function() {
                        component.set("v.showToast",false);               
                    }), 7000
                );
            }
            else{
                console.log('in 5: ');
                var paidAmountApplied = component.find("paidAmountApplied");
                if(paidAmountApplied != undefined) paidAmountApplied.set("v.value",val);
                component.set("v.PaidAmountApplied", val);
                console.log('PaidAmountApplied 3: ',component.get("v.PaidAmountApplied"));
                
                var renderedFields = component.find("inv_input_field");
                for(var  x in renderedFields){ 
                    if(renderedFields[x].get('v.fieldName')==='Paid_Amount_Applied__c'){
                        if(val!=null && val!=undefined && val!=''){
                            renderedFields[x].set('v.value',val);
                        }else renderedFields[x].set('v.value',0.00);
                    }
                }
            }
        }catch(e){
            console.log('err',e);
        }
    }
})
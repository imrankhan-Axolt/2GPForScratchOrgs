({
    doInit: function(component, event, helper) {
       
        component.set("v.totalTax",component.get("v.invoiceLineItem.Other_Tax__c")+component.get("v.invoiceLineItem.VAT_Amount__c"));
        var tax;
        tax=(component.get("v.invoiceLineItem.Other_Tax__c")+component.get("v.invoiceLineItem.VAT_Amount__c"))/component.get("v.invoiceLineItem.Quantity__c");
        component.set("v.taxPerQuantity",tax);//component.get("v.invoiceLineItem.Other_Tax__c"));
        component.set('v.subTotalPrice',component.get('v.invoiceLineItem.Sub_Total__c'));
        
        var vatTax=component.get("v.invoiceLineItem.VAT_Amount__c")/component.get("v.invoiceLineItem.Quantity__c");
        component.set('v.vatTax',vatTax);
        var otherTax=component.get("v.invoiceLineItem.Other_Tax__c")/component.get("v.invoiceLineItem.Quantity__c");
        component.set('v.otherTax',otherTax);
       // component.set("v.invoiceLineItem.VAT_Amount__c",component.get("v.invoiceLineItem.Other_Tax__c")+component.get("v.invoiceLineItem.VAT_Amount__c"));
        component.set("v.discount",component.get("v.invoiceLineItem.Discount_Amount__c")/component.get("v.invoiceLineItem.Quantity__c"));
        var Quantity;
        if(!$A.util.isEmpty(component.get("v.SOId")))
        	Quantity=component.get("v.invoiceLineItem.Sales_Order_Line_Item__r.Quantity__c")-component.get("v.invoiceLineItem.Sales_Order_Line_Item__r.Invoiced_Quantity__c");
        else if(!$A.util.isEmpty(component.get("v.StdId")))
            Quantity=component.get("v.invoiceLineItem.Order_Product__r.Quantity")-component.get("v.invoiceLineItem.Order_Product__r.Invoiced_Quantity__c");
                
        component.set("v.Qty",Quantity);
    },
    updateCalculations : function(component, event, helper) {
        if(!$A.util.isEmpty(component.get("v.SOId"))){
            if(component.get("v.invoiceLineItem.Quantity__c") <= component.get("v.invoiceLineItem.Sales_Order_Line_Item__r.Quantity__c")){
                if(component.get("v.invoiceLineItem.Quantity__c")>0) 
                    var discount=component.get("v.discount")*component.get("v.invoiceLineItem.Quantity__c");
                else 
                    component.set("v.invoiceLineItem.Discount_Amount__c",0);
                if(discount!=undefined) component.set("v.invoiceLineItem.Discount_Amount__c",discount);
                component.set("v.invoiceLineItem.Sub_Total__c",parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.invoiceLineItem.Unit_Price__c")));
                var totalVatTax=component.get('v.vatTax')*component.get("v.invoiceLineItem.Quantity__c");
                component.set("v.invoiceLineItem.VAT_Amount__c",totalVatTax);//parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                
                var totalOtherTax=component.get('v.otherTax')*component.get("v.invoiceLineItem.Quantity__c");
                component.set("v.invoiceLineItem.Other_Tax__c",totalOtherTax);//parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                var totalTax=totalOtherTax+totalVatTax;
                //component.set("v.totalTax",totalTax);
                //component.set("v.invoiceLineItem.Other_Tax__c",parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                component.set("v.invoiceLineItem.Total_Price__c",parseFloat(totalTax + component.get("v.invoiceLineItem.Sub_Total__c")));
                component.set("v.subTotalPrice",parseFloat(component.get("v.invoiceLineItem.Total_Price__c")));
                var callToupdatePrice=component.get('v.callToupdatePrice')+1;
                component.set('v.callToupdatePrice',callToupdatePrice);
            }
        }
        else if(!$A.util.isEmpty(component.get("v.StdId"))){
            if(component.get("v.invoiceLineItem.Quantity__c") <= component.get("v.invoiceLineItem.Order_Product__r.Quantity")){
                if(component.get("v.invoiceLineItem.Quantity__c")>0) 
                    var discount=component.get("v.discount")*component.get("v.invoiceLineItem.Quantity__c");
                else 
                    component.set("v.invoiceLineItem.Discount_Amount__c",0);
                if(discount!=undefined) component.set("v.invoiceLineItem.Discount_Amount__c",discount);
                component.set("v.invoiceLineItem.Sub_Total__c",parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.invoiceLineItem.Unit_Price__c")));
                var totalVatTax=component.get('v.vatTax')*component.get("v.invoiceLineItem.Quantity__c");
                component.set("v.invoiceLineItem.VAT_Amount__c",totalVatTax);//parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                
                var totalOtherTax=component.get('v.otherTax')*component.get("v.invoiceLineItem.Quantity__c");
                component.set("v.invoiceLineItem.Other_Tax__c",totalOtherTax);//parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                var totalTax=totalOtherTax+totalVatTax;
                //component.set("v.totalTax",totalTax);
                //component.set("v.invoiceLineItem.Other_Tax__c",parseFloat(component.get("v.invoiceLineItem.Quantity__c") * component.get("v.taxPerQuantity")));
                 component.set("v.invoiceLineItem.Total_Price__c",parseFloat(totalTax + component.get("v.invoiceLineItem.Sub_Total__c")));
                component.set("v.subTotalPrice",parseFloat(component.get("v.invoiceLineItem.Total_Price__c")));
                var callToupdatePrice=component.get('v.callToupdatePrice')+1;
                component.set('v.callToupdatePrice',callToupdatePrice);
            }
        }
        
    },
    validate: function(component, event, helper) {
        	var requiredFields = component.find("requiredField");
        
        if(component.get("v.validate")){
            requiredFields.checkValidity();
            component.set("v.validate",requiredFields.get("v.validity").valid);
       }
    },
    
})
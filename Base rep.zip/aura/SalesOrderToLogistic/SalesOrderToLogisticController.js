({
    doInit : function(component, event, helper) {
        console.log('doInit called');
        helper.getDependentPicklists(component, event, helper);
        helper.getReturnDependentPicklists(component, event, helper);
        helper.doini(component, event, helper);
        helper.getBillingOptionsPickList(component,event,helper);
        
        if(component.get('v.SOId') != '') 
            helper.fetchSoliList(component, event, helper);
        else if(component.get('v.orderId') != '')
            helper.fetchOrdItemList(component, event, helper);
            else if(component.get('v.POId') != '')
                helper.fetchPOItemList(component, event,helper);
                else if(component.get('v.LogId') != ''){
                    helper.fetchLogDetails(component, event,helper);
                }
    },
    
    fetchSoliList:function(component,event,helper){
        helper.fetchSoliList(component, event, helper);
    },
    
    fetchOrdItemList:function(component,event,helper){
        helper.fetchOrdItemList(component, event, helper);
    },
    
    fetchPOItemList : function(component,event,helper){
        helper.fetchPOItemList(component,event,helper);
    },
    
    fetchDistributionChannel:function(component,event,helper){
        console.log('fetchDistributionChannel called channel id~>'+component.get("v.channelId"));
        if(component.get("v.channelId") == undefined ||component.get("v.channelId") == '' || component.get("v.channelId") == null) component.set("v.DistributeChannelId",'');    
        else helper.fetchStoreAddress(component,event,helper,component.get("v.channelId")); 
    },
    
    fetchstocksDC:function(component,event,helper){
        try{
            console.log('fetchstocksDC called dc~>'+component.get("v.DistributeChannelId"));
            $A.util.removeClass(component.find('mainSpin'), "slds-hide");
            
            var OrderId;
            if(component.get('v.SOId') != '') 
                OrderId = component.get('v.SOId');
            else if(component.get('v.orderId') != '')
                OrderId = component.get('v.orderId');
                else if(component.get('v.POId') != '')
                    OrderId = component.get('v.POId');
            
            var action = component.get("c.getupdatedstocksDCs");
            action.setParams({
                "OrdId" : OrderId,
                "orditms": JSON.stringify(component.get("v.OrdItemList")),
                "chnId" : component.get("v.channelId"),
                "DCId": component.get("v.DistributeChannelId"),
                "LogItems" : JSON.stringify(component.get("v.LLIList")),
            });
            action.setCallback(this, function(response){
                if(response.getState() === "SUCCESS"){
                    console.log('response.getReturnValue() : ',response.getReturnValue())
                    if(response.getReturnValue() != null){
                        component.set("v.OrdItemList",response.getReturnValue().UpdatedOrdList);
                        component.set("v.BomItemList",response.getReturnValue().UpdatedBomList);
                        component.set("v.LLIList",response.getReturnValue().UpdatedlogList);
                    }
                    
                    component.set("v.allSOLIselected",false);
                    var elem = []; elem=component.find('schId');
                    if(elem){
                        if(elem.length){
                            for(var i in elem){
                                elem[i].set("v.checked",false);
                            }
                        }else elem.set("v.checked",false);
                    }
                    
                    component.set("v.SelectedSoliList",[]);
                    component.set("v.reRenderSOLItable",false);
                    component.set("v.reRenderSOLItable",true);
                    setTimeout($A.getCallback(function(){
                        $A.util.addClass(component.find('mainSpin'), "slds-hide");
                    }),3000);
                    
                    //New code added by Parveez 28/07/23
                    
                    let tempOrderitems = component.get("v.OrdItemList");
                    let tempbom = component.get("v.BomItemList");
                    console.log('tempOrderitems.length : ',tempOrderitems.length);
                    if(tempOrderitems.length > 0){
                        for(var k in tempOrderitems){
                            let totalkitbom = [];
                            let bomwithinventory = [];
                            if(tempOrderitems[k].Product2Id != undefined && tempOrderitems[k].Product2.Is_Kit__c){
                                
                                for(var i in tempbom){
                                    if(tempOrderitems[k].Product2Id == tempbom[i].Bom.BOM_Product__c){
                                        totalkitbom.push(tempbom[i].Name);
                                        if(tempbom[i].stock > 0){
                                            bomwithinventory.push(tempbom[i].Name);
                                        }  
                                    }
                                }
                                console.log('totalkitbom:',totalkitbom.length);
                                console.log('bomwithinventory:',bomwithinventory.length);
                                if(totalkitbom.length != bomwithinventory.length){
                                    tempOrderitems[k].AllowKit = 'Not-Allowed';
                                }
                                else if(totalkitbom.length == bomwithinventory.length){
                                    tempOrderitems[k].AllowKit = 'Allow';
                                }
                            }
                            
                        }
                        console.log('kitList :',JSON.stringify(tempOrderitems));
                    }
                    
                    //
                }else{
                    setTimeout($A.getCallback(function(){
                        $A.util.addClass(component.find('mainSpin'), "slds-hide");
                    }),3000);
                    var errors = response.getError();
                    console.log("server error in fetchstocksDC : ", errors);
                    component.set("v.exceptionError", errors[0].message);
                    setTimeout( function(){component.set("v.exceptionError", "");}, 5000);
                } 
            });
            if(!$A.util.isEmpty(component.get("v.channelId")) && !$A.util.isUndefinedOrNull(component.get("v.channelId")) && !$A.util.isEmpty(component.get("v.DistributeChannelId")) && !$A.util.isUndefinedOrNull(component.get("v.DistributeChannelId")) && (component.get("v.OrdItemList").length > 0 || component.get("v.LLIList").length > 0)){
                $A.enqueueAction(action);
            }else{
                console.log('not updating stocks');
                component.set("v.allSOLIselected",false);
                var elem = []; elem=component.find('schId');
                console.log('elem ~>'+elem);
                if(elem){
                    if(elem.length){
                        for(var i in elem){
                            elem[i].set("v.checked",false);
                        }
                    }else elem.set("v.checked",false);
                }
                
                component.set("v.SelectedSoliList",[]);
                component.set("v.reRenderSOLItable",false);
                component.set("v.reRenderSOLItable",true);
                setTimeout($A.getCallback(function(){
                    $A.util.addClass(component.find('mainSpin'), "slds-hide");
                }),3000);
                
            }
        }
        catch(e){console.log('Error:',e);}
    },
    
    reloadSoli:function(component,event,helper){
        location.reload();  
    },
    
    backToSoliTab:function(component,event,helper){
        try{
            component.set("v.selectedTab",'soli');
            let selectedItem = []; selectedItem = component.get("v.LLIList");
            console.log('selectedItem : ',selectedItem);
            var OrdItemList=[]; OrdItemList=component.get('v.OrdItemList');
            console.log('OrdItemList : ',OrdItemList);
            var selectedDum = [];
            if(selectedItem.length > 0 && OrdItemList.length > 0){
                console.log('2 here');
                for(var y in OrdItemList){
                    OrdItemList[y].checked = false;
                    for(var x in selectedItem){
                        if(OrdItemList[y].Id == selectedItem[x].Order_Product__c){
                            OrdItemList[y].checked = true;
                            selectedDum.push(OrdItemList[y]);
                            console.log('3 in here');
                            break;
                            
                        } 
                    }
                    
                } 
                component.set("v.OrdItemList",OrdItemList); 
                component.set("v.SelectedSoliList",selectedDum); 
            }
            component.set("v.LLIList",[]); 
            component.set("v.selectedTab",'soli');
        }
        catch(e){console.log(e);}
    },
    
    backToSoli:function(component,event,helper){
        //component.set("v.selectedTab",'soli');
        if(component.get('v.SOId') !=''){
            var RecUrl = "/lightning/r/Sales_Order__c/" + component.get('v.SOId') + "/view";
            window.open(RecUrl,'_parent');
        }else if(component.get('v.orderId') !=''){
            var RecUrl = "/lightning/r/Order/" + component.get('v.orderId') + "/view";
            window.open(RecUrl,'_parent');
        }else if(component.get('v.POId') !=''){
            var RecUrl = "/lightning/r/PO__c/" + component.get('v.POId') + "/view";
            window.open(RecUrl,'_parent');
        }
    },
    
    resetSelected : function(component,event,helper){
        console.log('resetSelected called');
        component.set('v.SelectedSoliList',[]);
        component.set('v.allSOLIselected',false);
    },
    
    selectSoli: function(component, event, helper) {     
        var isSelect = event.getSource().get("v.checked");
        var recordId = event.getSource().get("v.value");
        
        var SelectedSoliList=[]; SelectedSoliList=component.get('v.SelectedSoliList');
        var SoliList =[]; SoliList=component.get("v.SoliList");
        var OrdItemList=[]; OrdItemList=component.get('v.OrdItemList');
        var POItemList=[]; POItemList=component.get('v.POItemList');
        var BomItems = [];BomItems = component.get('v.BomItemList');
        $A.util.removeClass(component.find("cnvrtLogBtnId"),'a_disabled'); 
        
        try{ 
            
            if (isSelect) {
                
                if(SoliList.length > 0){
                    for(var x = 0; x<SoliList.length; x++){
                        if(SoliList[x].Id==recordId ) SelectedSoliList.push(SoliList[x]);
                    }
                }
                else if(OrdItemList.length > 0){
                    for(var y = 0; y<OrdItemList.length; y++){
                        if(OrdItemList[y].Id==recordId )SelectedSoliList.push(OrdItemList[y]);
                        /*if(OrdItemList[y].Id==recordId ) {
                            	
                            	if(OrdItemList[y].Product2.Is_Kit__c){   
                                    
                                    for(var k in BomItems) {
                                        if(OrdItemList[y].Product2Id == BomItems[k].Bom.BOM_Product__c ){
                                            SelectedSoliList.push(BomItems[k].Bom);
                                        }
                                    }
                            	}
                            	else SelectedSoliList.push(OrdItemList[y]);
                            console.log('SelectedSoliList:',JSON.stringify(SelectedSoliList));
                       } */ 
                    }
                }else if(POItemList.length > 0){
                    for(var z = 0; z<POItemList.length; z++){
                        if(POItemList[z].Id==recordId ) SelectedSoliList.push(POItemList[z]);
                    }
                }
                
            }else {
                var SelectedSoliListDum=[]; SelectedSoliListDum=SelectedSoliList;
                for(var x=0;x<SelectedSoliListDum.length;x++){          
                    if(SelectedSoliListDum[x].Id==recordId){
                        // delete SelectedSoliListDum[x];
                        SelectedSoliListDum.splice(x,1);
                        break;
                    }               
                }
                SelectedSoliList=SelectedSoliListDum;
            }   
            
        }catch(ex){ console.log('ex in checkbox'+ex);  }    
        component.set("v.SelectedSoliList",SelectedSoliList);
        
        /* if(isSelect) $A.util.removeClass(component.find("cnvrtLogBtnId"),'a_disabled'); //.getElement()
     else $A.util.addClass(component.find("cnvrtLogBtnId"),'a_disabled');  //.getElement()  */
    },
    
    selectAllSoli:function(component,event,helper){
        var isSelect = event.getSource().get("v.checked");
        console.log('isSelect : ',isSelect);
        var elem=[]; elem=component.find('schId');
        console.log('elem~>',elem);
        var SelectedSoliList=[];
        var SoliList =[]; SoliList=component.get("v.SoliList"); 
        var OrdItemList=[]; OrdItemList=component.get('v.OrdItemList');
        var POItemList=[]; POItemList=component.get('v.POItemList');
        
        var SelectedSoliListDum=[];
        
        if(SoliList.length > 0){
            for(var j=0; j<SoliList.length; j++){ 
                if(isSelect==true){  // && SoliList[j].Active__c==true
                    if(SoliList[j].Active__c==true){
                        if(elem){
                            if(elem.length){
                                elem[j].set("v.checked",true);        
                            }else elem.set("v.checked",true);        
                        }
                        
                        SelectedSoliListDum.push(SoliList[j]); 
                    }          
                }   
                else{
                    if(elem){
                        if(elem.length){
                            elem[j].set("v.checked",false);        
                        }else elem.set("v.checked",false);        
                    }
                    SelectedSoliListDum=[];
                }
            }
        }
        else if(OrdItemList.length > 0)  {
            for(var j=0; j<OrdItemList.length; j++){ 
                if(isSelect==true){  
                    if ((OrdItemList[j].Active__c === true && ((OrdItemList[j].Remaining_Quantity__c <= OrdItemList[j].Reserved_Quantity__c && OrdItemList[j].Remaining_Quantity__c > 0 &&  OrdItemList[j].Remaining_Quantity__c <= OrdItemList[j].Quantity) || (OrdItemList[j].Product2.Is_Kit__c && OrdItemList[j].AllowKit =='Allow')))){  // || OrdItemList[j].Product2.Is_Kit__c    //.Quantity     
                        console.log('here222');
                        if(elem){
                            console.log('here1:+ elem.length +',elem.length);
                            if(elem.length){
                                console.log('here2');
                                elem[j].set("v.checked",true);        
                            }else{
                                console.log('here3');
                                elem.set("v.checked",true);
                            }   
                        }         
                        console.log('here pushed');
                        SelectedSoliListDum.push(OrdItemList[j]); 
                    }else{
                        console.log('here notpushed');
                    }
                }   
                else{
                    if(elem){
                        if(elem.length){
                            elem[j].set("v.checked",false);        
                        }else elem.set("v.checked",false);        
                    }
                    SelectedSoliListDum=[];
                }
            }
        }
            else if(POItemList.length > 0){
                for(var j=0; j<POItemList.length; j++){ 
                    if(isSelect==true){ 
                        if(POItemList[j].Active__c==true){          
                            if(elem){
                                if(elem.length){
                                    elem[j].set("v.checked",true);        
                                }else elem.set("v.checked",true);        
                            }                                                     
                            SelectedSoliListDum.push(POItemList[j]); 
                        }          
                    }   
                    else{
                        if(elem){
                            if(elem.length){
                                elem[j].set("v.checked",false);        
                            }else elem.set("v.checked",false);        
                        }
                        SelectedSoliListDum=[];
                    }
                }
            }
        console.log('SelectedSoliListDum ~>'+SelectedSoliListDum.length);
        component.set("v.SelectedSoliList",SelectedSoliListDum); //SelectedSoliList
        
        if(isSelect && SelectedSoliListDum.length > 0) $A.util.removeClass(component.find("cnvrtLogBtnId"),'a_disabled');
        else $A.util.addClass(component.find("cnvrtLogBtnId"),'a_disabled');                               
    },
    
    convertToLogistic: function(component, event, helper) {
        try{
            console.log('convertToLogistic called');
            component.set('v.LLIList',[]);
            var SelectedSoliList=[]; SelectedSoliList=component.get('v.SelectedSoliList');  
            console.log('SelectedSoliList ~>'+SelectedSoliList.length);
            var SoliList =[]; SoliList=component.get("v.SoliList"); 
            var OrdItemList=[]; OrdItemList=component.get('v.OrdItemList');
            var POItemList=[]; POItemList=component.get('v.POItemList');
            if(SelectedSoliList.length>0){
                var LLIList=[]; LLIList=component.get("v.LLIList");
                var LLIListDum=[]; LLIListDum=LLIList; //=component.get("v.LLIList");
                for(let x=0;x<SelectedSoliList.length;x++){
                    var found = false;
                    for(let y=0;y<LLIList.length;y++){
                        
                        if(SoliList.length > 0){
                            /*if(LLIList[y].Product__c == SelectedSoliList[x].Product__c){ //SelectedSoliList[x].Product__c != undefined && 
                            found = true;
                            break;
                        }*/
                    }
                    else if(OrdItemList.length > 0){
                        /*if(LLIList[y].Product2Id == SelectedSoliList[x].Product2Id){ //SelectedSoliList[x].Product__c != undefined && 
                            found = true;
                            break;
                        }*/
                    }
                        else if(POItemList.length >0){
                            /*if(LLIList[y].Product__c == SelectedSoliList[x].Product__c){ //SelectedSoliList[x].Product__c != undefined && 
                            found = true;
                            break;
                        }*/
                        }
                    
                }
                if(!found){ 
                    if(SoliList.length > 0){
                        console.log('SoliList inhere');
                        //var AQuantity=SelectedSoliList[x].Quantity__c-SelectedSoliList[x].Logistic_Quantity__c; SelectedSoliList[x].Reserved_Quantity__c
                        var obj = { 
                            Name:SelectedSoliList[x].Name,
                            Product__c:SelectedSoliList[x].Product__c,
                            Quantity__c:SelectedSoliList[x].Quantity__c-SelectedSoliList[x].Logistic_Quantity__c,
                            Price_Product__c:SelectedSoliList[x].Base_Price__c,                  
                            Sales_Order_Line_Item__c:SelectedSoliList[x].Id,
                            Logistic__c:''
                        };
                        obj.Product__r={
                            'Id':SelectedSoliList[x].Product__c,
                            'Name':SelectedSoliList[x].Product__r.Name 
                        };
                        
                        LLIListDum.push(obj);
                    }
                    else if(OrdItemList.length > 0){
                        console.log('OrdItemList inhere');
                        //var AQuantity=SelectedSoliList[x].Quantity__c-SelectedSoliList[x].Logistic_Quantity__c; SelectedSoliList[x].Reserved_Quantity__c
                        var j = x+1;
                        var BomItemList=[];BomItemList =component.get("v.BomItemList");
                        if(SelectedSoliList[x].Product2.Is_Kit__c){
                            for(var j in BomItemList){
                                if(SelectedSoliList[x].Product2Id == BomItemList[j].Bom.BOM_Product__c && BomItemList[j].OrderProdId == SelectedSoliList[x].Id){
                                    var obj = { 
                                        Name: BomItemList[j].Bom.BOM_Component__r.Name+'-LogisticLine-'+j,
                                        Product__c:BomItemList[j].Bom.BOM_Component__c,
                                        Quantity__c:BomItemList[j].Bom.Quantity__c,
                                        Price_Product__c:BomItemList[j].pbe.UnitPrice,                  
                                        Order_Product__c:SelectedSoliList[x].Id,
                                        Logistic__c:''
                                    };
                                    obj.Product__r={
                                        'Id':BomItemList[j].Bom.BOM_Component__c,
                                        'Name':BomItemList[j].Bom.BOM_Component__r.Name 
                                    };
                                    LLIListDum.push(obj); 
                                }
                            }
                        }
                        else{
                            
                            var obj = { 
                                Name:SelectedSoliList[x].Product2.Name+'-LogisticLine-'+j,
                                Product__c:SelectedSoliList[x].Product2Id,
                                Quantity__c: SelectedSoliList[x].Remaining_Quantity__c, //SelectedSoliList[x].Quantity-SelectedSoliList[x].Logistic_Quantity__c,
                                Price_Product__c:SelectedSoliList[x].UnitPrice,                  
                                Order_Product__c:SelectedSoliList[x].Id,
                                Logistic__c:''
                            };
                            //Check it (is it working or not for Standard order)
                            obj.Product__r={
                                'Id':SelectedSoliList[x].Product2.Id,
                                'Name':SelectedSoliList[x].Product2.Name 
                            };
                            LLIListDum.push(obj);
                            
                        }
                        
                    }
                        else if(POItemList.length > 0){
                            console.log('POItemList inhere');
                            var obj = { 
                                Name:SelectedSoliList[x].Name,
                                Product__c:SelectedSoliList[x].Product__c,
                                Quantity__c:SelectedSoliList[x].Quantity__c-SelectedSoliList[x].Logistic_Quantity__c,
                                Price_Product__c:SelectedSoliList[x].Unit_Price__c,                  
                                Purchase_Line_Items__c:SelectedSoliList[x].Id,
                                Logistic__c:''
                            };
                            obj.Product__r={
                                'Id':SelectedSoliList[x].Product__c,
                                'Name':SelectedSoliList[x].Product__r.Name 
                            };
                            LLIListDum.push(obj);
                        }                    
                }
            }
            console.log('LLIListDum convertToLogistic json~>'+JSON.stringify(LLIListDum));
            component.set("v.LLIList",LLIListDum);
            if(component.get("v.LLIList").length > 0) component.set("v.selectedTab",'log');
        }
            else{
                sforce.one.showToast({
                    "title": $A.get('$Label.c.warning_UserAvailabilities'),
                    "message": $A.get('$Label.c.No_Item_Selected'),
                    "type": "warning"
                });
                //helper.showToast('dismissible','', 'Error', 'No Item Selected',component); 
            }  
            
            var lognum = parseInt(component.get("v.LogisticsExisting.length")+1);
            if(SoliList.length > 0){
                var logName = ''+SoliList[0].Sales_Order__r.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }else if(OrdItemList.length > 0){
                var logName = ''+OrdItemList[0].Order.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }else if(POItemList.length > 0){
                var logName = ''+POItemList[0].Purchase_Orders__r.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }
        }
        catch(ex){console.log(ex);} 
    },
    
    singleConvertToLogistic: function(component, event, helper) {  
        try{
            
            console.log('singleConvertToLogistic called');
            component.set('v.LLIList',[]);
            var index = event.currentTarget.dataset.service;
            var soliListForCom=[];soliListForCom=component.get("v.SoliList");
            var OrderListListForCom=[];OrderListListForCom=component.get("v.OrdItemList");
            var POListForCom=[];POListForCom=component.get("v.POItemList");
            var SoliList=[]; SoliList= component.get("v.SoliList"); 
            
            var BomItemList=[];BomItemList =component.get("v.BomItemList");
            var ordItemListDum= [];
            
            var ordItemList=[]; ordItemList = component.get("v.OrdItemList");
            
            var POItemList=[]; POItemList=component.get("v.POItemList");   
            
            /* for(var i in ordItemList){
                if(ordItemList[i].Product2.Is_Kit__c){
                    
                    for(var j in BomItemList){
                        if(ordItemList[i].Product2Id == BomItemList[j].Bom.BOM_Product__c ){
                            
                            ordItemListDum[j].Name = BomItemList[j].Bom.BOM_Component__c.Name;
                            ordItemListDum[j].Product2.Id = BomItemList[j].Bom.BOM_Component__r.Id;
                            ordItemListDum[j].Product2      = BomItemList[j].Bom.BOM_Component__c;
                            ordItemListDum[j].Remaining_Quantity__c = 1;
                            ordItemListDum[j].UnitPrice     = 0;
                            ordItemListDum[j].Id            = ordItemList[i].Id;
                        }
                    }
                }
            }*/
            
            
            
            var selectedSoli=[];//SoliList[index];
            if(SoliList.length > 0){
                selectedSoli=SoliList[index];	
            }else 
                if(ordItemList.length > 0){       
                    selectedSoli=ordItemList[index];
                }
                else if(POItemList.length > 0){
                    selectedSoli=POItemList[index];
                }
            
            var LLIList=component.get('v.LLIList'); //LLIList=[];
            var LLIListMore=[]; 
            console.log('selectedSoli json~>'+JSON.stringify(selectedSoli));
            if(soliListForCom.length > 0){
                console.log('soliListForCom inhere');
                var obj = { 
                    Name:selectedSoli.Name,
                    Product__c:selectedSoli.Product__c,
                    Quantity__c:selectedSoli.Quantity__c-selectedSoli.Logistic_Quantity__c,
                    Price_Product__c:selectedSoli.Base_Price__c,                                     
                    Sales_Order_Line_Item__c:selectedSoli.Id,   
                    Logistic__c:''    
                };
                obj.Product__r={
                    'Id':selectedSoli.Product__c,
                    'Name':selectedSoli.Product__r.Name 
                };
                LLIListMore.push(obj); //Quantity__c
            }
            else if(OrderListListForCom.length > 0){
                console.log('OrderListListForCom inhere');
                if(selectedSoli.Remaining_Quantity__c <= 0 || selectedSoli.Remaining_Quantity__c > selectedSoli.Quantity){
                    component.set("v.exceptionError", $A.get('$Label.c.REMAINING_QUANTITY') +' > 0 && <= '+$A.get('$Label.c.Acc_Pay_Total_Quantity'));
                    setTimeout( function(){component.set("v.exceptionError", "");}, 5000);
                    return;
                }
                if(selectedSoli.Product2.Is_Kit__c){
                    for(var j in BomItemList){
                        if(selectedSoli.Product2Id == BomItemList[j].Bom.BOM_Product__c && BomItemList[j].OrderProdId == selectedSoli.Id){
                            var obj = { 
                                Name: BomItemList[j].Bom.BOM_Component__r.Name+'-LogisticLine-1',
                                Product__c:BomItemList[j].Bom.BOM_Component__c,
                                Quantity__c:BomItemList[j].Bom.Quantity__c,
                                Price_Product__c:BomItemList[j].pbe.UnitPrice,                  
                                Order_Product__c:selectedSoli.Id,
                                Logistic__c:''
                            };
                            obj.Product__r={
                                'Id':BomItemList[j].Bom.BOM_Component__c,
                                'Name':BomItemList[j].Bom.BOM_Component__r.Name 
                            };
                            LLIListMore.push(obj); 
                        }
                    }
                }
                else{
                    var obj = { 
                        Name:selectedSoli.Product2.Name+'-LogisticLine-1',
                        Product__c:selectedSoli.Product2Id,
                        Quantity__c:selectedSoli.Remaining_Quantity__c, //selectedSoli.Quantity-selectedSoli.Logistic_Quantity__c,
                        Price_Product__c:selectedSoli.UnitPrice,                  
                        Order_Product__c:selectedSoli.Id,
                        Logistic__c:''
                    };
                    obj.Product__r={
                        'Id':selectedSoli.Product2.Id,
                        'Name':selectedSoli.Product2.Name 
                    };
                    LLIListMore.push(obj); 
                }
                //Quantity__c
                
                
                
            }
                else if(POListForCom.length > 0){
                    console.log('POListForCom inhere');
                    //var AQuantity=SelectedSoliList[x].Quantity__c-SelectedSoliList[x].Logistic_Quantity__c; SelectedSoliList[x].Reserved_Quantity__c
                    var obj = { 
                        Name:selectedSoli.Name,
                        Product__c:selectedSoli.Product__c,
                        Quantity__c:selectedSoli.Quantity__c-selectedSoli.Logistic_Quantity__c,
                        Price_Product__c:selectedSoli.Unit_Price__c,                  
                        Purchase_Line_Items__c:selectedSoli.Id,
                        Logistic__c:''
                    };
                    obj.Product__r={
                        'Id':selectedSoli.Product__c,
                        'Name':selectedSoli.Product__r.Name 
                    };
                    LLIListMore.push(obj); //Quantity__c
                }
            
            console.log('LLIListMore inhere pushing to LLIList');
            for(let x=0;x<LLIListMore.length;x++) LLIList.push(LLIListMore[x]); 
            
            console.log('LLIList singleConvertToLogistic json~>'+JSON.stringify(LLIList));
            component.set("v.LLIList",LLIList);
            if(component.get("v.LLIList").length > 0) component.set("v.selectedTab",'log');
            
            var lognum = parseInt(component.get("v.LogisticsExisting.length")+1);
            if(SoliList.length > 0){
                console.log('logName SoliList inhere');
                var logName = ''+SoliList[0].Sales_Order__r.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }else if(ordItemList.length > 0){
                console.log('logName ordItemList inhere');
                var logName = ''+ordItemList[0].Order.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }else if(POItemList.length > 0){
                console.log('logName POItemList inhere');
                var logName = ''+POItemList[0].Purchase_Orders__r.Name+'-Logistic-'+lognum;
                component.set("v.Logistic.Name",logName);
            }
        }
        catch(ex){
            console.log(ex);
        }
        
        
    },
    
    getLLIDelete:function(component,event,helper){ 
        var deleteconfirm = confirm($A.get('$Label.c.Do_you_want_to_Delete_Item'));
        if(deleteconfirm){
            var LLIList=component.get("v.LLIList");
            //delete LLIList[event.currentTarget.dataset.service];
            console.log('LLIList bfr: ',LLIList);
            var index=event.currentTarget.dataset.service;
            LLIList.splice(index,1);
            //  delete LLIList[index];
            
            component.set("v.LLIList",LLIList);
            console.log('LLIList after: ',LLIList);
            component.set("v.reRenderLogisticTable",false);
            component.set("v.reRenderLogisticTable",true);
            
            // if(LLIList.length==1 || LLIList.length==0)  helper.getLLIDeleteSingle(component, event, helper);  
            if(LLIList.length==0){   
                component.set("v.LLIList",[]); 
                helper.getLLIDeleteSingle(component, event, helper);  
            }   
            
            if(component.get("v.selectedTab")=='log'){     
                component.set("v.selectedTab",'soli');
                component.set("v.selectedTab",'log');
            }
            else if(component.get("v.selectedTab")=='soli'){
                component.set("v.selectedTab",'log');
                component.set("v.selectedTab",'soli');
            }
            
        }
      
    },
    
    addLLI: function(component, event, helper){
        var action = component.get("c.getLLIInstance");     
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {  
                var LLIList=[]; LLIList=component.get("v.LLIList");
                LLIList.push(response.getReturnValue());           
                component.set("v.LLIList",LLIList);
                
            }         
        });
        $A.enqueueAction(action);    
        
    },
    
    createLogistic:function(component,event,helper){
        helper.createLogistic(component,event,helper);
                        console.log('Logistic line item : ',JSON.stringify(component.get("v.LLIList")));

    },

    verifyQuantity:function(component,event,helper){
        
        component.set("v.QuantityErrorMsg",'');  
        
        var Index=event.getSource().get("v.name"); 
        var SoliList =[]; SoliList=component.get("v.SoliList");
        var OrdItemList =[]; OrdItemList=component.get("v.OrdItemList");
        var POItemList =[]; POItemList=component.get("v.POItemList");
        
        var LLIList =[]; LLIList=component.get("v.LLIList"); 
        var lliRecord=LLIList[Index]; 
        var soliRecord; 
        for(var i in SoliList){ 
            if(SoliList[i].Id==lliRecord.Sales_Order_Line_Item__c) soliRecord=SoliList[i];          
        }  
        
        var ordItRecord;
        for(var i in OrdItemList){
            if(OrdItemList[i].Id==lliRecord.Order_Product__c) ordItRecord=OrdItemList[i];
        }
        var POLIRecord;
        for(var i in POItemList){
            if(POItemList[i].Id==lliRecord.Purchase_Line_Items__c) POLIRecord=POItemList[i];
        }
        
        var elems=[]; elems=component.find('loliQuantityIds');
        var elem; if(elems.length>1) elem=elems[Index]; else elem=elems;
        
        var AQuantity;
        if(component.get('v.SOId') != ''){
            AQuantity=soliRecord.Quantity__c-soliRecord.Logistic_Quantity__c; //Reserved_Quantity__c 
        }  
        if(component.get('v.orderId') != ''){
            AQuantity = ordItRecord.Remaining_Quantity__c; //ordItRecord.Quantity-ordItRecord.Logistic_Quantity__c;
        }
        if(component.get('v.POId') != ''){
            AQuantity=POLIRecord.Quantity__c-POLIRecord.Logistic_Quantity__c;
        }
        
        if(lliRecord.Quantity__c>AQuantity){
            elem.set("v.class",'hasError');
            component.set("v.QuantityErrorMsg",$A.get('$Label.c.Given_quantity_is_not_available')); // on stock
            
            sforce.one.showToast({
                "title": $A.get('$Label.c.warning_UserAvailabilities'),
                "message": $A.get('$Label.c.Given_quantity_is_not_available'),
                "type": "warning"
            });
            
            
            //helper.showToast('dismissible','', 'Error', 'Given quantity is not available',component); //on stock  
        }      
        
        else if(lliRecord.Quantity__c<=0) {
            component.set("v.QuantityErrorMsg",$A.get('$Label.c.Invalid_Quantity')); 
            sforce.one.showToast({
                "title": $A.get('$Label.c.warning_UserAvailabilities'),
                "message": $A.get('$Label.c.Invalid_Quantity'),
                "type": "warning"
            });
            //helper.showToast('dismissible','', 'Error', 'Invalid Quantity',component);  
            elem.set("v.class",'hasError');  
        }else{ 
            elem.set("v.class",''); 
            component.set("v.QuantityErrorMsg",''); 
        }
        
    }, 
    
    showLogisticRecordDetailsPage:function(component,event,helper){ 
        var recordId = event.target.dataset.record;  
        component.set("v.nameUrl",'/'+recordId); 
    },
    
    parentFieldChange : function(component, event, helper) {
        var controllerValue =  component.get("v.Logistic.Shipment_type__c");//component.find("parentField").get("v.value");// We can also use event.getSource().get("v.value")
        var pickListMap = component.get("v.depnedentFieldMap");
        console.log('parentFieldChange controllerValue : '+controllerValue);
        if (controllerValue != '' && controllerValue != null && controllerValue != undefined) {
            //get child picklist value
            
            //component.set("v.Logistic.Shipment_type__c",controllerValue);
            var childValues = pickListMap[controllerValue];
            console.log('parentFieldChange childValues : ',JSON.stringify(childValues));
            var childValueList = [];
            //childValueList.push('');
            for (var i = 0; i < childValues.length; i++) {
                childValueList.push(childValues[i]);
            }
            // set the child list
            component.set("v.listDependingValues", childValueList);
            console.log('parentFieldChange listDependingValues : ',component.get("v.listDependingValues"));
            if(childValues.length > 0){
                component.set("v.bDisabledDependentFld" , false);  
            }else{
                component.set("v.bDisabledDependentFld" , true); 
            }
        } else {
            var list = [];
            component.set("v.listDependingValues", list);
            component.set("v.bDisabledDependentFld" , true);
            console.log('setting Shipment_type__c Shipping_Preferences__c empty here');
            component.set("v.Logistic.Shipment_type__c", '');
            component.set("v.Logistic.Shipping_Preferences__c",'');
        }
        if(component.get("v.listDependingValues").length > 0){
            var listdependingValues = component.get("v.listDependingValues");
            console.log('parentFieldChange listdependingValues~>'+listdependingValues[0]);
            component.set("v.Logistic.Shipping_Preferences__c",listdependingValues[0].value);
        }
        console.log('parentFieldChange v.Logistic.Shipping_Preferences__c~>'+component.get("v.Logistic.Shipping_Preferences__c"));
    },
    
    //Added by Arshad 26 Oct 23
   ReturnparentFieldChange : function(component, event, helper) {
        var controllerValue =  component.get("v.Logistic.Shipment_Type_Return__c");
        var pickListMap = component.get("v.RdepnedentFieldMap");
        console.log('ReturnparentFieldChange called controllerValue : '+controllerValue);
        if (controllerValue != '' && controllerValue != null && controllerValue != undefined) {
            //get child picklist value
            
            //component.set("v.Logistic.Shipment_type__c",controllerValue);
            var childValues = pickListMap[controllerValue];
            console.log('ReturnparentFieldChange childValues : ',JSON.stringify(childValues));
            var childValueList = [];
            //childValueList.push('');
            for (var i = 0; i < childValues.length; i++) {
                childValueList.push(childValues[i]);
            }
            // set the child list
            component.set("v.RlistDependingValues", childValueList);
            console.log('ReturnparentFieldChange RlistDependingValues here: ',component.get("v.RlistDependingValues"));
            if(childValues.length > 0){
                component.set("v.RbDisabledDependentFld" , false);  
            }else{
                component.set("v.RbDisabledDependentFld" , true); 
            }
        } 
        else {
            var list = [];
            component.set("v.RlistDependingValues", list);
            component.set("v.RbDisabledDependentFld" , true);
            console.log('setting Shipping_Preferences_Return__c empty here');
            //component.set("v.Logistic.Shipment_type_Return__c", '');
            component.set("v.Logistic.Shipping_Preferences_Return__c",'');
        }
        if(component.get("v.RlistDependingValues").length > 0){
            var RlistDependingValues = component.get("v.RlistDependingValues");
            console.log('ReturnparentFieldChange RlistDependingValues~>'+RlistDependingValues[0]);
            component.set("v.Logistic.Shipping_Preferences_Return__c",RlistDependingValues[0].value);
        }
        console.log('ReturnparentFieldChange v.Logistic.Shipping_Preferences_Return__c~>'+component.get("v.Logistic.Shipping_Preferences_Return__c"));
    },
    
    closeError :function(component,event,helper){
        component.set(exceptionError,'');
    },
    
    closeError :function(component,event,helper){
        component.set(exceptionError,'');
    },
    
    updateLogistic : function(component,event,helper){
        console.log('updateLogistic called');
         $A.util.removeClass(component.find('mainSpin'), "slds-hide");
        var err = false;
        var LLIList=[]; LLIList=component.get("v.LLIList");
        if(LLIList.length > 0){
            for(var x in LLIList){
                if(LLIList[x].Quantity__c > LLIList[x].Fulfilled_Quantity__c){
                    sforce.one.showToast({
                        "title": $A.get('$Label.c.Error_UsersShiftMatch'),
                        "message": 'Can_not_select_more_that_available_stock',
                        "type": "error"
                    });
                    err =true;
                     $A.util.addClass(component.find('mainSpin'), "slds-hide");
                } 
            }
        }
        if(!err){
            component.set("v.Logistic.Channel__c",component.get("v.channelId"));  
            component.set("v.Logistic.Distribution_Channel__c",component.get("v.DistributeChannelId"));
            var Logistic=component.get("v.Logistic");  
            console.log('Logistic : ',JSON.stringify(Logistic));
            var LogisticJSON=JSON.stringify(Logistic); 
            var LLIList=[]; LLIList=component.get("v.LLIList");
            var LLIListJSON=JSON.stringify(LLIList); 
            var action = component.get("c.getUpdateLogistic");
            action.setParams({
                "LogisticJSON":LogisticJSON,
                "LLIListJSON":LLIListJSON
            });  
            action.setCallback(this, function(response) {
                if (response.getState() === "SUCCESS") {  
                    console.log('getCreateLogistic resp~>',response.getReturnValue());
                    
                    if(response.getReturnValue() != null){
                        if(response.getReturnValue().includes('STRING_TOO_LONG')){
                            sforce.one.showToast({
                                "title": $A.get('$Label.c.Error_UsersShiftMatch'),
                                "message": $A.get('$Label.c.Logistic_name_should_not_exceed_80_characters'),
                                "type": "error"
                            });
                            $A.util.addClass(component.find('mainSpin'), "slds-hide");
                            return;
                        }
                    }                           
                    if(response.getReturnValue() == null){
                        sforce.one.showToast({
                            "title": $A.get('$Label.c.Success'),
                            "message": $A.get('$Label.c.Saved_Successfully'),
                            "type": "Success"
                        });
                        var RecUrl = "/lightning/r/Logistic__c/" + component.get('v.LogId') + "/view";
                        window.open(RecUrl,'_parent'); 
                    }else{
                        sforce.one.showToast({
                            "title": $A.get('$Label.c.Error_UsersShiftMatch'),
                            "message": response.getReturnValue(),
                            "type": "error"
                        });
                        $A.util.addClass(component.find('mainSpin'), "slds-hide");
                        return;
                    } 
                    $A.util.addClass(component.find('mainSpin'), "slds-hide");
                }else{
                    var error1=response.getError();
                    console.log('Error :',error1);
                    component.set('v.exceptionError',error1[0].message);
                    sforce.one.showToast({
                        "title": $A.get('$Label.c.Error_UsersShiftMatch'),
                        "message": error1[0].message,
                        "type": "error"
                    });
                    $A.util.addClass(component.find('mainSpin'), "slds-hide");
                }        
            });
            $A.enqueueAction(action);
        }
    },
    
    
})
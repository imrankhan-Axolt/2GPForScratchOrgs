({
    afterRender: function (component, helper) {
    this.superAfterRender();
   // helper.fetchSoliList(component, event, helper);
},
    
})
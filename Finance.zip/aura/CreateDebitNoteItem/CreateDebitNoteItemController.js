({
    doInit : function(component, event, helper){
        try{
            console.log('doInit called CreateBillItem');
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            console.log('doinit TotalAAPercentage~>'+TotalAAPercentage);
            component.set("v.TotalAAPercentage",TotalAAPercentage);
            
            let poStatus = component.get("c.getCategoryList");
            poStatus.setCallback(this,function(response){
                let resList = response.getReturnValue();
                let resListupdated = [];
                for(var i in resList){
                    if(i!=0) resListupdated.push(resList[i]);
                }
                component.set("v.PoliCategoryList",resListupdated);                
                $A.util.addClass(component.find('mainSpin'), "slds-hide");            
            });
            $A.enqueueAction(poStatus);
            
            component.set("v.Access",$A.get("$Label.c.Other_Tax_Display"));
            component.set("v.TDSAccess",$A.get("$Label.c.TDS_Display"));
            
            if(component.get("v.Item.Tax_Amount__c")!=undefined){
                var qty = (!$A.util.isEmpty(component.get("v.Item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Quantity__c"))) ? component.get("v.Item.Quantity__c") : 0;
                var amt = (!$A.util.isEmpty(component.get("v.Item.Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Amount__c"))) ? component.get("v.Item.Amount__c") : 0;
                var taxamt = (!$A.util.isEmpty(component.get("v.Item.Tax_Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Tax_Amount__c"))) ? component.get("v.Item.Tax_Amount__c") : 0;
                console.log('amt~>'+amt);
                console.log('taxamt~>'+taxamt);
                var amount = amt*qty;
                console.log('amount~>'+amount);
                //var tax_Percentage=cmp.get("v.Tax_Amount");
                //var Amount=component.get("v.Item.Amount__c");
                var percentage = parseFloat((taxamt/amount)*100);
                console.log('inhere4');
                if(percentage != undefined && percentage != null){
                    console.log('inhere5~>'+percentage);
                    if(percentage >= 0){
                        percentage = percentage.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                        console.log('inhere3~>'+percentage);
                        component.set("v.Item.Tax_Rate__c",percentage);
                    }
                }
                console.log('inhere1');
                component.UpdateTax();
            }
            console.log('inhere2');
            helper.helperTotalPrice(component, event);
            
            setTimeout(
                $A.getCallback(function() {
                    var TotalAAPercentage2 = 0;
                    if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                        if(component.get("v.Item.Accounts.length") > 0){
                            var itemAccs = component.get("v.Item.Accounts");
                            for(var i in itemAccs){
                                if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                                    if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage2 += parseFloat(itemAccs[i].Allocation_Percentage__c);
                                }
                            }
                        }
                    }
                    console.log('doinit TotalAAPercentage2~>'+TotalAAPercentage2);
                    component.set("v.TotalAAPercentage",TotalAAPercentage2);
                }), 5000
            );
        }catch(e){ console.log('doinit err '+e); }
        
    },
    
    deleteItem : function(component, event, helper) {
        component.set("v.deleteIndex",component.get("v.index"));
    },
    
    DeleteRecord : function(component, event, helper) { 
        //component.set("v.deleteIndex",component.get("v.index"));
        try {
            var e = $A.get("e.c:RequisitionToPurchaseOrderEvent");                                                  
            e.setParams({
                "Index": component.get("v.index")
            });
            e.fire();
        } catch (ex) {}
        component.set("v.TotalPrice",0);
        component.set("v.Tax",0);
        component.set("v.Tax_Amount",0);
        //$A.enqueueAction(component.get("c.updateTotalPrice"));
    },
    
    displayAccounts : function(component,event,helper){
        try{
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage);
            
            console.log('arshad TotalAAPercentage~>'+component.get("v.TotalAAPercentage")+' typeof~>'+typeof component.get("v.TotalAAPercentage"));
            var remainingTotalAAPercent = parseFloat(100 - component.get("v.TotalAAPercentage"));
            console.log('arshad remainingTotalAAPercent~>'+remainingTotalAAPercent+' typeof~>'+typeof remainingTotalAAPercent);
            
            component.set("v.displayAccount", true);
            var poliList = [];
            var polList = [];
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null) polList = component.get("v.Item.Accounts");
            console.log('polList before~>'+polList.length);
            
            var pol = [];
            pol = component.get("v.billItems");
            var indexed = pol.length;
            var poliIndex = parseInt(component.get("v.index") + 1);
            if(pol != null) poliList = pol[indexed-1].Accounts;
            if(component.get("v.AutoAccountAllocation")){
                var coaId = '';
                var projId = '';
                
                /*if(poliList[0] != undefined){
                    coaId = pol[indexed-1].Chart_Of_Account__c;
                    projId = poliList[0].Project__c;
                    component.set("v.Item.Chart_Of_Account__c", pol[indexed-1].Chart_Of_Account__c);
                    component.set("v.Item.Account_Category__c", pol[indexed-1].Account_Category__c);
                }else{
                    //coaId = 'a110600000YLX4kAAH';
                    //projId = 'a35240000004nA8AAI';
                }
                component.set("v.coaId", coaId);
                component.set("v.projId", projId);
                */
                
                if(pol.length > 0){
                    var length = pol.length;
                    console.log('Auto pol[0]~>'+JSON.stringify(pol[length-1]));
                    if(pol[length-1].Accounts != null && pol[length-1].Accounts != undefined){
                        if(pol[length-1].Accounts.length > 0){
                            if(pol[length-1].Accounts[0].Project__c != undefined && pol[length-1].Accounts[0].Project__c != null && pol[length-1].Accounts[0].Project__c != ''){
                                projId = pol[length-1].Accounts[0].Project__c;
                            }
                        }
                    }
                    console.log('projId~>'+projId);
                    if(pol[length-1].Chart_Of_Account__c != null && pol[length-1].Chart_Of_Account__c != undefined && pol[length-1].Chart_Of_Account__c != ''){
                        coaId = pol[length-1].Chart_Of_Account__c;
                    }
                    console.log('coaId~>'+coaId);
                    component.set("v.Item.Chart_Of_Account__c", coaId);
                    if(pol[length-1].Account_Category__c != null && pol[length-1].Account_Category__c != undefined && pol[length-1].Account_Category__c != ''){
                        component.set("v.Item.Account_Category__c", pol[length-1].Account_Category__c);
                    }
                }
                
                if(remainingTotalAAPercent > 0){
                    polList.push({sObjectType :'Dimension__c', Chart_of_Account__c : coaId, Project__c : projId, Sort_Order__c:parseInt(poliIndex), Allocation_Percentage__c :remainingTotalAAPercent, Allocation_Amount__c: (parseFloat(parseFloat(component.get("v.Item.Quantity__c")) * parseFloat(component.get("v.Item.Amount__c"))) * remainingTotalAAPercent)/100 });
                }else console.log('arshad new dimension not added because remainingTotalAAPercent~>'+remainingTotalAAPercent);         
            }else{
                if(remainingTotalAAPercent > 0){
                    polList.push({sObjectType :'Dimension__c', Chart_of_Account__c : null, Project__c : null, Sort_Order__c:parseInt(poliIndex), Allocation_Percentage__c :remainingTotalAAPercent, Allocation_Amount__c: (parseFloat(parseFloat(component.get("v.Item.Quantity__c")) * parseFloat(component.get("v.Item.Amount__c"))) * remainingTotalAAPercent)/100 });
                }else console.log('arshad new dimension not added because remainingTotalAAPercent~>'+remainingTotalAAPercent);    
            }
            
            component.set("v.Item.Accounts",polList);
            
            var TotalAAPercentage2 = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage2 += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage2);
        } catch (e) { console.log('displayAccounts err~>'+e); }
    },
    
    resetAA : function(component, event, helper) {
        try{
            console.log('inside resetAA');
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage);
            
            component.set("v.Item.Chart_Of_Account__c", null);
            var poliList =[]; 
            poliList=component.get("v.Item.Accounts");
            for(var x in poliList){
                poliList[x].Project__c = null;
            }
            component.set("v.Item.Accounts",poliList);
        } catch (e) { console.log('resetAA err~>'+e); }
    },
    
    deleteAnalyAcc :function(component, event, helper) {
        try{
            if(event.getSource().get('v.title') != undefined && event.getSource().get('v.title') != null){
                if(event.getSource().get('v.title') != ''){
                    var action=component.get("c.deleteDimensions");
                    action.setParams({'demId':event.getSource().get('v.title')});
                    action.setCallback(this,function(response){
                        //component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
                        //component.set("v.currencyList",response.getReturnValue().currencyList);
                    });
                    $A.enqueueAction(action);
                }
            }
            console.log('inside deleteAnalyAcc');
            var poliList =[]; 
            poliList = component.get("v.Item.Accounts");
            if(event.getSource().get('v.name') != undefined && event.getSource().get('v.name') != null){
                var index = event.getSource().get('v.name'); 
                console.log('index~>'+index);
                poliList.splice(index,1);  
            }
            
            component.set("v.Item.Accounts",poliList);
            
            if(poliList.length <= 0 && component.get("v.Item.Accounts.length") > 0){
                component.set("v.Item.Accounts",null);
            }
            console.log('here 1');
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage);
            console.log('here 2');
        } catch (e) { console.log('deleteAnalyAcc err~>'+e); }
    },
    
    updateACTaxAmount : function(component,event,helper){
        console.log('updateACTaxAmount called');
        try{
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage);
            
            console.log('Total_Amount__c~>'+component.get("v.Item.Total_Amount__c"));
            if(component.get("v.Item.Total_Amount__c") != '' && component.get("v.Item.Total_Amount__c") != null && component.get("v.Item.Total_Amount__c") != undefined){
                var aaacount = []; aaacount = component.get("v.Item.Accounts");
                if(aaacount != null && aaacount != undefined){
                    console.log('inhere');
                    if(aaacount.length > 0){
                        console.log('inhere2');
                        for(var a in aaacount){
                            if(aaacount[a].Allocation_Percentage__c != undefined && aaacount[a].Allocation_Percentage__c != null && aaacount[a].Allocation_Percentage__c != ''){
                                if(aaacount[a].Allocation_Percentage__c > 0){
                                    if(!$A.util.isEmpty(component.get("v.Item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Quantity__c")) && !$A.util.isEmpty(component.get("v.Item.Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Amount__c"))){
                                        aaacount[a].Allocation_Amount__c = parseFloat((parseFloat(component.get("v.Item.Quantity__c")) * parseFloat(component.get("v.Item.Amount__c"))) * aaacount[a].Allocation_Percentage__c)/100;
                                        aaacount[a].Allocation_Amount__c = aaacount[a].Allocation_Amount__c.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                                    }else aaacount[a].Allocation_Amount__c = 0;
                                }else aaacount[a].Allocation_Amount__c = 0;
                            }else aaacount[a].Allocation_Amount__c = 0;
                        }
                    }
                }
                component.set("v.Item.Accounts",aaacount); 
            }
        } catch (e) { console.log('updateACTaxAmount err~>'+e); }
    },
    
    updateACTaxPerentage : function(component,event,helper){
        try{
            if(component.get("v.Item.Total_Amount__c") != '' && component.get("v.Item.Total_Amount__c") != null && component.get("v.Item.Total_Amount__c") != undefined){
                var aaacount = [];
                aaacount = component.get("v.Item.Accounts");
                for(var a in aaacount){
                    if(aaacount[a].Allocation_Amount__c != undefined && aaacount[a].Allocation_Amount__c != null && aaacount[a].Allocation_Amount__c != ''){
                        if(aaacount[a].Allocation_Amount__c > 0){
                            var percent = 0;
                            if(!$A.util.isEmpty(component.get("v.Item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Quantity__c")) && !$A.util.isEmpty(component.get("v.Item.Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Amount__c"))){
                                percent = parseFloat(parseFloat(aaacount[a].Allocation_Amount__c) / parseFloat(parseFloat(component.get("v.Item.Quantity__c")) * parseFloat(component.get("v.Item.Amount__c"))))*100;
                                aaacount[a].Allocation_Percentage__c = percent.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                            }else aaacount[a].Allocation_Percentage__c = 0;
                        }else aaacount[a].Allocation_Percentage__c = 0;
                    }else aaacount[a].Allocation_Percentage__c = 0;
                }
                component.set("v.Item.Accounts",aaacount); 
            }
            
            var TotalAAPercentage = 0;
            if(component.get("v.Item.Accounts") != undefined && component.get("v.Item.Accounts") != null){
                if(component.get("v.Item.Accounts.length") > 0){
                    var itemAccs = component.get("v.Item.Accounts");
                    for(var i in itemAccs){
                        if(itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != ''){
                            if(itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage",TotalAAPercentage);
        } catch (e) { console.log('updateACTaxPerentage err~>'+e); }
    },
    
    updateTotalPrice : function(component, event, helper) {
        helper.helperTotalPrice(component, event);
        helper.UpdateTDSOnChange(component, event, helper);
    },
    
    validate : function(component,event,helper){
        component.NoErrors = true;
        var cmpqty = component.find("qty");
        if(!$A.util.isUndefined(cmpqty))
            helper.checkValidationField(component,cmpqty);
        var price = component.find("amount");
        if(!$A.util.isUndefined(price))
            helper.checkValidationField(component,price);
        var productField = component.find("product");
        if(!$A.util.isUndefined(productField))
            helper.checkvalidationLookup(component,productField);
        if(!component.NoErrors){
            var chartOfAccountField = component.find("chartOfAccount");
            if(!$A.util.isUndefined(chartOfAccountField))
                helper.checkvalidationLookup(component,chartOfAccountField);
            if(component.NoErrors)
                productField.set("v.inputStyleclass","");
        }else{
            var chartOfAccountField = component.find("chartOfAccount");
            chartOfAccountField.set("v.inputStyleclass","");
        }
        return component.NoErrors;
    },
    
    UpdateDiscount : function(component,event,helper){
        var item = component.get("v.Item");
        if(!$A.util.isUndefined(item)){
            
            var discountAMt = component.get("v.Discount");
            component.set("v.Discount",item.Discount__c);
            if(item.Discount__c=='') component.set("v.Item.Discount__c",0); 
            helper.helperTotalPrice(component, event);
        }
    },
    
    UpdateTax : function(component,event,helper){
        try{
            console.log('UpdateTax called');
            var qty = (!$A.util.isEmpty(component.get("v.Item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Quantity__c"))) ? component.get("v.Item.Quantity__c") : 0;
            var amt = (!$A.util.isEmpty(component.get("v.Item.Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Amount__c"))) ? component.get("v.Item.Amount__c") : 0;
            var othertaxrate = (!$A.util.isEmpty(component.get("v.Item.Other_Tax_Rate__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Other_Tax_Rate__c"))) ? component.get("v.Item.Other_Tax_Rate__c") : 0;
            var taxamt = 0; var othertaxamt = 0;
            var taxrate = (!$A.util.isEmpty(component.get("v.Item.Tax_Rate__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Tax_Rate__c"))) ? component.get("v.Item.Tax_Rate__c") : 0;
            var discount = (!$A.util.isEmpty(component.get("v.Item.Discount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Discount__c"))) ? component.get("v.Item.Discount__c") : 0;
            
            if(taxrate > 0) taxamt = parseFloat(parseFloat(((amt*qty)-discount)/100) * taxrate);
            if(othertaxrate > 0) othertaxamt = parseFloat((amt/100) * othertaxrate);
            if(othertaxamt > 0) othertaxamt = othertaxamt*qty;
            var totalTax = taxamt + othertaxamt;
            component.set("v.Item.Tax_Amount__c",taxamt.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            component.set("v.Item.Other_Tax__c",othertaxamt.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            component.set("v.Tax",totalTax.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            
            var Other_Tax_Amount = parseFloat(((amt*othertaxrate) / 100));
            component.set("v.Other_Tax_Amount",Other_Tax_Amount);
            
            var amount = parseFloat(amt*qty);
            var tax = component.get("v.Item.Tax_Amount__c");
            
            component.set("v.Item.Total_Amount__c",parseFloat(amount-discount).toFixed($A.get("$Label.c.DecimalPlacestoFixed"))); //+tax
            var totalAmount = component.get("v.Item.Total_Amount__c");
            component.set("v.Tax_Amount",((totalAmount*taxrate)/100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            
            /*
            var item = component.get("v.Item");
            //alert('q=>'+item.Quantity__c);
            if(item.Tax_Rate__c==undefined)item.Tax_Rate__c=0;
            if(item.Other_Tax_Rate__c==undefined)item.Other_Tax_Rate__c=0;
            if(item.Quantity__c==undefined)item.Quantity__c=0;
            var tax=0;
            if(item.Tax_Rate__c!=0)tax=(((item.Amount__c*item.Quantity__c)-item.Discount__c)/100)*item.Tax_Rate__c;
            tax=tax;
            var OTtax=0;
            if(item.Other_Tax_Rate__c!=0)OTtax=(item.Amount__c/100)*item.Other_Tax_Rate__c;
            OTtax=OTtax*item.Quantity__c;
            var totalTax=tax+OTtax;
            item.Tax_Amount__c=tax;
            item.Other_Tax__c=OTtax;
            //item.Total_Amount__c = item.Amount__c + item.Tax_Amount__c;
            component.set("v.Item",item);
            component.set("v.Tax",totalTax);
            
            var rate=component.get("v.Item.Tax_Rate__c");
            var Amount=component.get("v.Item.Amount__c");
            var discount=component.get("v.Item.Discount__c");
            
            var rate2=component.get("v.Item.Other_Tax_Rate__c");
            component.set("v.Other_Tax_Amount",(Amount*rate2)/100);
            //var value=component.get("v.Tax_Amount");
            //var value2=component.get("v.Other_Tax_Amount");
            //component.set("v.Tax",value+value2);
            var amount=component.get("v.Item.Amount__c")*component.get("v.Item.Quantity__c");
            var tax=component.get("v.Item.Tax_Amount__c");
            component.set("v.Item.Total_Amount__c",amount-discount);//+tax
            var totalAmount = component.get("v.Item.Total_Amount__c");
            component.set("v.Tax_Amount",((totalAmount*rate)/100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            */
            //$A.enqueueAction(component.get("c.updateACTaxAmount"));
        }catch(e){ console.log('UpdateTax err',e); }
        
    },
    
    UpdateTaxPercentage: function(cmp, event, helper){
        var tax_Percentage=cmp.get("v.Update_TDS_Amount");
        var Amount=cmp.get("v.Item.Amount__c");
        var percentage=(tax_Percentage/Amount)*100;
        cmp.set("v.Item.TDS_Rate__c",percentage);
        cmp.UpdateTDS();
    },
    
    UpdateTaxPercentage1: function(cmp, event, helper){
        var tax_Percentage=cmp.get("v.Other_Tax_Amount");
        var Amount=cmp.get("v.Item.Amount__c");
        var percentage=((tax_Percentage/Amount)*100).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
        cmp.set("v.Item.Other_Tax_Rate__c",percentage); 
        cmp.UpdateTax();
    },
    
    UpdateTaxPercentage2: function(component, event, helper){ 
        try{
            console.log('UpdateTaxPercentage2 called');
            var qty = (!$A.util.isEmpty(component.get("v.Item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Quantity__c"))) ? component.get("v.Item.Quantity__c") : 0;
            var amt = (!$A.util.isEmpty(component.get("v.Item.Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Amount__c"))) ? component.get("v.Item.Amount__c") : 0;
            var taxamt = (!$A.util.isEmpty(component.get("v.Item.Tax_Amount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Tax_Amount__c"))) ? component.get("v.Item.Tax_Amount__c") : 0;
            var discount = (!$A.util.isEmpty(component.get("v.Item.Discount__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Discount__c"))) ? component.get("v.Item.Discount__c") : 0;
            
            var amount = parseFloat(parseFloat(amt*qty) - discount);
            var percentage = parseFloat(((taxamt/amount)*100)).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            component.set("v.Item.Tax_Rate__c",percentage);
            
            var taxrate = (!$A.util.isEmpty(component.get("v.Item.Tax_Rate__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Tax_Rate__c"))) ? component.get("v.Item.Tax_Rate__c") : 0;
            var othertaxrate = (!$A.util.isEmpty(component.get("v.Item.Other_Tax_Rate__c")) && !$A.util.isUndefinedOrNull(component.get("v.Item.Other_Tax_Rate__c"))) ? component.get("v.Item.Other_Tax_Rate__c") : 0;
            var taxamt = 0; var othertaxamt = 0;
            if(taxrate > 0) taxamt = parseFloat(parseFloat(((amt*qty)-discount)/100) * taxrate);
            if(othertaxrate > 0) othertaxamt = parseFloat((amt/100) * othertaxrate);
            if(othertaxamt > 0) othertaxamt = othertaxamt*qty;
            var totalTax = taxamt + othertaxamt;
            //component.set("v.Item.Tax_Amount__c",taxamt.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            //component.set("v.Item.Other_Tax__c",othertaxamt.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            component.set("v.Tax",totalTax.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            
            //var Other_Tax_Amount = parseFloat(((amt*othertaxrate) / 100));
            //component.set("v.Other_Tax_Amount",Other_Tax_Amount);
            
            var amount = parseFloat(amt*qty); 
            var tax = component.get("v.Item.Tax_Amount__c");
            
            component.set("v.Item.Total_Amount__c",parseFloat(amount-discount).toFixed($A.get("$Label.c.DecimalPlacestoFixed"))); //+tax
            var totalAmount = component.get("v.Item.Total_Amount__c");
            component.set("v.Tax_Amount",((totalAmount*taxrate)/100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            
            /*
        var amount=cmp.get("v.Item.Amount__c")*cmp.get("v.Item.Quantity__c")-cmp.get("v.Item.Discount__c");
        var tax=cmp.get("v.Item.Tax_Amount__c");
        
        //var tax_Percentage=cmp.get("v.Tax_Amount");
        //var Amount=cmp.get("v.Item.Amount__c");
        var percentage=((tax/amount)*100).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
        cmp.set("v.Item.Tax_Rate__c",percentage);
        var item = cmp.get("v.Item");
        //alert('q=>'+item.Quantity__c);
        if(item.Tax_Rate__c==undefined)item.Tax_Rate__c=0;
        if(item.Other_Tax_Rate__c==undefined)item.Other_Tax_Rate__c=0;
        if(item.Quantity__c==undefined)item.Quantity__c=0;
        var tax=0;
        if(item.Tax_Rate__c!=0)tax=(((item.Amount__c*item.Quantity__c)-item.Discount__c)/100)*item.Tax_Rate__c;
        tax=tax;
        var OTtax=0;
        if(item.Other_Tax_Rate__c!=0)OTtax=(item.Amount__c/100)*item.Other_Tax_Rate__c;
        OTtax=OTtax*item.Quantity__c;
        var totalTax=tax+OTtax;
        item.Tax_Amount__c=tax;
        item.Other_Tax__c=OTtax;
        //cmp.set("v.Item",item);
        cmp.set("v.Tax",totalTax);
        var rate=cmp.get("v.Item.Tax_Rate__c");
        var Amount=cmp.get("v.Item.Amount__c");
        var discount = cmp.get("v.Item.Discount__c");
        
        cmp.set("v.Item.Total_Amount__c",amount-discount);//+tax
        var totalAmount = cmp.get("v.Item.Total_Amount__c");
        cmp.set("v.Tax_Amount",((totalAmount*rate)/100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
        //cmp.UpdateTax();
        */
        }catch(e){ console.log('UpdateTaxPercentage2 err',e); }
    },
    
    UpdateTDS : function(cmp, event, helper){
        helper.UpdateTDSOnChange(cmp, event, helper);
    },
})
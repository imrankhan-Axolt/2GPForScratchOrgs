({
	doInit : function(component, event, helper) {
        component.set('v.IsApprovedShow',$A.get("$Label.c.IsApprovedShow"));
        component.set('v.isTotalAmtShow',$A.get("$Label.c.isTotalAmtShow"));
         var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        var dayDigit = today.getDate();
        if(dayDigit <= 9){
            dayDigit = '0' + dayDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + dayDigit);
    },
    
    NavigateToManageBill: function(component,event,helper){
        var item = component.get("v.item");
        var url = '/apex/ManageBill?BId='+item.Id;
        window.open(url,"_self");
    },
    
    getSelectedBill : function(cmp,event,h){
        var SelectedId = event.getSource().get("v.name");
        var selBills = cmp.get('v.SelectedBillIds'); 
        if(selBills=='')selBills.pop();
        if(event.getSource().get("v.value")){
            selBills.push(SelectedId);
         }else{
            for(var x =0;x < selBills.length;x++){
                if(selBills[x] === SelectedId){
                    selBills.splice(x,1);
                    break;
                } 
                
            }
        }
        cmp.set('v.SelectedBillIds', selBills);       
    },
    updateBill : function(component,event,helper){
        var recId = event.target.dataset.record;
        var item = component.get("v.item");
        var postvalue = item.Posted__c;
        item.Posted__c = !(postvalue);
        var updateAction = component.get("c.updateBillById");
        updateAction.setParams({"recordId":recId,"fieldValue":item.Posted__c});
        updateAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                component.set("v.item",item);
                let msg = (item.Posted__c)?'Post Bill #'+item.Name+' Successfully':'UnPost Bill #'+item.Name+' Successfully'
                helper.showToast('Success!','success',msg); 
            }
            
        });
       $A.enqueueAction(updateAction); 
    },
   /*updateBillToApprove : function(component, event, helper){
       
        var recId = event.target.dataset.record;
        var item = component.get("v.item");
        //component.set("v.item.Approved__c",true); 
       
       if((component.get("v.item.Matched__c")&&component.get("v.item.RecordType.DeveloperName")=='PO_Bill')||component.get("v.item.RecordType.DeveloperName")=='Expense_Bill'){
           component.set("v.item.Approved__c",true); 
           var approve = item.Approved__c;
        item.Approved__c = true;
        var updateAction = component.get("c.update_Bill");
        updateAction.setParams({"obj":JSON.stringify(item)});
        updateAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
            }
            
        });
       $A.enqueueAction(updateAction);
       }else{
           
               helper.showToast('Error!','error','Please Match the Bill Before Approve'); 
                            // component.set("v.SaveErrorMsg","Please Match the Bill Before Approve");
                        
          
       }
   },*/
    
    
    
    updateBillToApprove : function(component, event, helper){
        
        var recId = event.target.dataset.record;
        var item = component.get("v.item");
        //component.set("v.item.Approved__c",true); 
        //(component.get("v.item.Matched__c")&&component.get("v.item.RecordType.DeveloperName")=='PO_Bill')||
        if((component.get("v.item.RecordType.DeveloperName")=='Expense_Bill') || (component.get("v.item.RecordType.DeveloperName")=='Advance_to_vendor')){
            component.set("v.item.Posted__c",true); 
            var approve = item.Posted__c;
            item.Posted__c = true;
            var updateAction = component.get("c.update_Bill");
            updateAction.setParams({"obj":JSON.stringify(item)});
            updateAction.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){
                }
                
            });
            $A.enqueueAction(updateAction);
        }else if((component.get("v.item.Matched__c")&&component.get("v.item.RecordType.DeveloperName")=='PO_Bill')){
            //alert('called');
            component.set("v.item.Posted__c",true); 
            var approve = item.Posted__c;
            item.Posted__c = true;
            item.Approved__c = true;
            var updateAction = component.get("c.update_Bill");
            updateAction.setParams({"obj":JSON.stringify(item)});
            updateAction.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){
                }
                
            });
            $A.enqueueAction(updateAction);
        }else{
            var action1 = component.get("c.checkBillDetails");
            action1.setParams({BillId:component.get("v.item.Id")});
            action1.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    if(response.getReturnValue()){
                        helper.HelperSaveRecord(component, event, helper);
                    }else{
                        helper.showToast('Error!','error','Please Match the Bill Before Approve'); 
                    }
                }
                else{
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            helper.showToast('Error!','error',errors[0].message); 
                        }
                    }
                }
            });
            $A.enqueueAction(action1);
        }
    },
    
    onClick:function(component, event, helper) {
        component.set("v.SaveErrorMsg",'');
    },
    hideModal : function(component,event,helper){
        component.set("v.showModal",false);
    },
    CreateVoucher : function(component,event,helper){
        var item = component.get("v.item");
        var items=JSON.stringify(item);
        
        var saveAction = component.get("c.checkVoucherApex");
        saveAction.setParams({"record":items});
        saveAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                if(response.getReturnValue().isValid){
                    var vou = component.get("v.voucher");
                    vou.Vendor__c = item.Vendor__c;
                    vou.Vendor_invoice_Bill__c = item.Id;
                    if(item.Purchase_Order__c!=null) vou.Purchase_Orders__c = item.Purchase_Order__c;
                    if(item.TDS_Amount__c!=null && item.TDS_Amount__c > 0)vou.Amount__c = item.Amount_Due__c-item.TDS_Amount__c;
                    else vou.Amount__c = response.getReturnValue().Amount;
                    component.set("v.vList",response.getReturnValue().vouchers);
                    vou.Name = item.Name;
                    component.set("v.voucher",vou);
                    component.set("v.showModal",true);
                }
                else{
                    helper.showToast('Warning!','warning','Voucher Has Already Been Created'); 
                }
            }  
        });
        $A.enqueueAction(saveAction);
    },
    save_Voucher : function(component,event,helper){
        component.noErrors = true;
        helper.checkvalidation(component,event);
        if(component.noErrors){
        var saveAction = component.get("c.saveVoucher");
            var vou = component.get("v.voucher");
            /*if(!$A.util.isUndefined(component.get("v.org.Id")))
                vou.Organisation__c = component.get("v.org.Id");*/
            vou.Company__c=component.get("v.item.Company__c");
            var voucher = JSON.stringify(vou);
            
        saveAction.setParams({"voucherRecord":voucher});
        saveAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                component.set("v.item",response.getReturnValue());
                component.set("v.showModal",false);
                helper.showToast('Success!','success','Voucher Created Successfully'); 
            }  
        });
        $A.enqueueAction(saveAction);
       }else
           helper.showToast('Error!','error','Review All Errors'); 
    },
    
     updateBillToPost : function(component,event,helper){
         $A.enqueueAction(component.get("c.updateBillToApprove"));
       var paymentAction =  component.get("c.save_Bill");
        let recId = component.get('v.item');//event.target.dataset.record;
        component.set('v.item.Posted__c',true);
        
        paymentAction.setParams({"record":JSON.stringify(recId)}); 
        paymentAction.setCallback(this,function(response){
            var state=response.getState();
            if(response.getState() === 'SUCCESS'){
               // component.set("v.Payments",Payments);
                //let msg = (item.Posted__c)?'Post Payment #'+item.Name+' Successfully':'UnPost Payment #'+item.Name+' Successfully'
                //helper.showToast('Success!','success',msg);
            }
        });
        $A.enqueueAction(paymentAction);
                                 
    },
    
    navToCreateBill : function(component,event,helper){
        //var BLIId = event.currentTarget.getAttribute('data-BLIId');  
        var item=component.get('v.item');
        var pId=item.Id;
         var evt = $A.get("e.force:navigateToComponent");
         evt.setParams({
             componentDef : "c:ManageBill",
             componentAttributes: {
                 "Bill":item,
                 "pId": pId,
                 "fromAP":true,
                 "navigateToRecord":false
             }
         });
         evt.fire();
        
        /*$A.createComponent("c:CreateBill",{
            "aura:id": "mBill",
             "Bill": item,
            "navigateToRecord":false
        },function(newCmp, status, errorMessage){
            if (status === "SUCCESS") {
            var body = component.find("body");
            body.set("v.body", newCmp);
        }
        });*/
    },
    
    navigatetoPO : function(component, event, helper) {
        var POId = event.currentTarget.getAttribute('data-POId');  
         var evt = $A.get("e.force:navigateToComponent");
         
    },
   
})
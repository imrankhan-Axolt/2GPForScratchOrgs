({
    PoDOInit: function(component, event, helper) {
        
        var action = component.get("c.populateRMAPO");
        action.setParams({
            POIds:component.get("v.poIdsList")
        });
        action.setCallback(this, function(a) {
                
        });
        $A.enqueueAction(action);
    },
    
    OrdItmsDOInit : function(component,event){
        console.log('inside OrdItmsDOInit');
        component.set("v.showSpinner",true);
        var SelectedPosList=component.get('v.SelectedPos');
        
        var action=component.get('c.populateOrderItems');
        action.setParams({
            "poIds":SelectedPosList
        });
        action.setCallback(this,function(response){
            if(response.getState() == "SUCCESS"){
                var poliList = [];
                console.log('Response-->'+JSON.stringify(response.getReturnValue()));
                poliList = response.getReturnValue();
                component.set("v.poli",poliList);
                component.set("v.showSpinner",false);
            }else{
                var error1=response.getError();
                component.set('v.exceptionError',error1[0].message);
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchAddressDetails : function(component, event, helper) {
        
    },
    
    showToast : function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent != undefined){
            toastEvent.setParams({
                "mode":"dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }else{
            sforce.one.showToast({
                "title": title,
                "message": message,
                "type": type
            });
        }
        
    },
    
    fetchEmployeeRequester : function(component, event, helper){
        var action = component.get('c.fetchEmployeeRequester');
        action.setParams({});
        action.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var res = response.getReturnValue();
                if(res != null){
                    component.set("v.Order.Employee__c",res.Id);
                }
                
                
            }else{
                console.log('Error fetchEmployeeRequester:',response.getError());
                component.set("v.exceptionError",response.getError());
            }
        });
        $A.enqueueAction(action); 
    },
    
})
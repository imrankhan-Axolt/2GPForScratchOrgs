({
	fetchUpdatedDataHelper : function(component, event, helper){
        //alert(component.get('v.stopRepeat'));
        //if(component.get('v.stopRepeat')){
        component.set('v.showSpinner' ,true);
        var selectedCurrency=component.get('v.Instance.SelectedCurrency');//event.currentTarget.dataset.record
        var action = component.get('c.ComputeUpdatedData');
        action.setParams({Ins : JSON.stringify(component.get('v.Instance'))});
        action.setCallback(this, function(response){
            var state = response.getState();
            if( state === "SUCCESS" ){
               
                component.set('v.stopRepeat',false);
                var myMap = new Map();
                
                
                var custs = [];
                var conts = response.getReturnValue().incomeMap;
                for(var key in conts){
                    custs.push({value:conts[key], key:key});
                }
               
                component.set("v.IncomeCOAData", custs);
                
                var custs = [];
                var conts = response.getReturnValue().ExpenseMap;
                for(var key in conts){
                    custs.push({value:conts[key], key:key});
                }
               
                component.set("v.ExpenseCOAData", custs);
                
                var custs = [];
                var conts = response.getReturnValue().incomeSubMap;
                for(var key in conts){
                    custs.push({value:conts[key], key:key});
                }
               
                component.set("v.subCOAData", custs);
                
                
                var custs = [];
                var conts = response.getReturnValue().expenseSubMap;
                for(var key in conts){
                    custs.push({value:conts[key], key:key});
                }
               
                component.set("v.subCOADataExp", custs);
                var totalin= response.getReturnValue().totalIncome;
                var totalexp= response.getReturnValue().totalExpense;
                component.set("v.TotalIncome", totalin.toFixed(2));
                component.set("v.TotalExpense", totalexp.toFixed(2));
                var netProfit = totalin.toFixed(2)-totalexp.toFixed(2);
                component.set("v.netProfit", netProfit.toFixed(2));
                //var map=component.get("v.IncomeCOAData");
                //alert(JSON.stringify(map['Sales']));
                if(response.getReturnValue()!=null){
                     //component.set("v.IncomeCOAData", response.getReturnValue().incomeMap);
                     //component.set("v.ExpenseCOAData", response.getReturnValue().ExpenseMap);
                     //component.set("v.IncomeCOADataList", response.getReturnValue().incomeList);
                }
                //component.set('v.Instance', response.getReturnValue());
                //component.set('v.Instance.SelectedCurrency',component.get('v.Instance.userIsoCode'));
                //component.set('v.SelectedCurrency',component.get('v.Instance.userIsoCode'));
                
                //component.set('v.Instance.multiCurrencyEnabled', true);
                component.set('v.showSpinner' ,false);
                component.set('v.stopRepeat',true);
                component.set('v.InitLoad', true);

                //component.set('v.Org',component.get('v.Instance.Select_Organisation.Company__c'));
                //component.set('v.SD',component.get('v.Instance.transSdate'));
                //component.set('v.ED',component.get('v.Instance.transEdate'));
            }else{
                component.set('v.showSpinner' ,false);
            }
        });
        $A.enqueueAction(action);
            var currencies = component.get("c.getCurrencies");
                currencies.setCallback(this,function(response){
                //component.find("stStatus").set("v.options", response.getReturnValue());     
                component.set("v.stStatusOptions", response.getReturnValue());    
           });
           $A.enqueueAction(currencies);
        //} 
    }
})
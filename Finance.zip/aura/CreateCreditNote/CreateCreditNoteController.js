({
    
    doInit : function(component, event, helper){
        console.log('CreateCreditNote cmp doinit');
        component.set("v.CreditNote.Restock_Tax__c", parseFloat(0));
        component.set("v.CreditNote.Shipping_Amount__c", parseFloat(0));
        component.set("v.CreditNote.Shipping_Tax__c", parseFloat(0));
        component.set("v.CreditNote.Fees__c", parseFloat(0));
        var vBillDate = new Date();
        component.set("v.CreditNote.Date__c", vBillDate.getFullYear() + "-" + (vBillDate.getMonth() + 1) + "-" + vBillDate.getDate());
        var isAttRequired=$A.get("$Label.c.isCreateBillAttRequired");
        if(isAttRequired ==='true'){                    
            component.set("v.isAttRequired",true);
        }else{
            component.set("v.isAttRequired",false);
        }
        if(component.get('v.invId')!=undefined && component.get('v.invId')!=null && component.get('v.invId')!=''){
            
            var invId=component.get('v.invId');
            component.set("v.CreditNote.Invoice__c", component.get("v.invId"));
            component.set('v.setRT','PO Bill');
            $A.enqueueAction(component.get("c.fetchinvli"));
        }
        
        if(component.get('v.credId')!=undefined && component.get('v.credId')!=null && component.get('v.credId')!=''){
            $A.enqueueAction(component.get("c.fetchcredList"));
        }
        
        helper.OrderProcess(component, event, helper);  
    },
    
    
    fetchcredList : function(component, event, helper) {
        var fetchpoliAction = component.get("c.fetch_credlis");
        fetchpoliAction.setParams({"Id":component.get("v.credId")});
        fetchpoliAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var resultList = response.getReturnValue();
                if(resultList.length > 0){
                    var po = JSON.parse(resultList[0]);
                    component.set("v.CreditNote", po);
                    var poliList = JSON.parse(resultList[1]);
                    component.set("v.lineItems",poliList);
                    /*if(!$A.util.isEmpty(poliList)){
                        var billList = [];
                        for(var x in poliList){
                            if(poliList[x].Product__r.Track_Inventory__c){
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c,Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }else if(poliList[x].Product__r.Is_Asset__c){
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c, Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }else{
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c, Discount__c:0.00, Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }
                        } 
                        component.set("v.lineItems",billList);
                     }else{
                        helper.showToast('!Warning','warning','Bill Has Already Been Created');
                        setTimeout(
                            $A.getCallback(function() {
                                $A.enqueueAction(component.get("c.cancelclick"));
                            }), 3000
                        );
                        
                    }*/
                }
            }  
        });
        $A.enqueueAction(fetchpoliAction);
    },
    
    
	fetchinvli : function(component, event, helper) {
        component.set("v.disabledEdit", false);
        //alert(component.get("v.CreditNote.Invoice__c"));
        if(!component.get("v.isUpdate")){
        if(component.get("v.CreditNote.Return_Merchandise_Authorisation__c")==null || component.get("v.CreditNote.Return_Merchandise_Authorisation__c")==undefined){
        var fetchpoliAction = component.get("c.fetch_invlis");
        fetchpoliAction.setParams({"Id":component.get("v.CreditNote.Invoice__c")});
            fetchpoliAction.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){
                    var resultList = response.getReturnValue();
                    if(resultList.length > 0 && resultList[2]!='True'){
                        
                        var po = JSON.parse(resultList[0]);
                        component.set("v.CreditNote.Account__c", po.Account__r.Id);
                        component.set("v.CreditNote.Sales_Order__c", po.Order__c);
                        component.set("v.CreditNote.Organisation__c", po.Organisation__c);
                        component.set("v.invRT", po.Record_Type_Name__c);
                        component.set("v.invoice", po);
                        component.set("v.CreditNote.Additional_Cost__c", 0);
                        component.set("v.SchInvoiceAmount", parseFloat(po.Invoice_Amount__c) - parseFloat(po.Tax_Amount__c));
                        component.set("v.CreditNote.Amount__c", 0);//parseFloat(po.Invoice_Amount__c) - parseFloat(po.Tax_Amount__c)
                        component.set("v.CreditNote.Tax_Amount__c", parseFloat(po.Tax_Amount__c));
                        if(component.get("v.invoice.Down_Payment__c")>0 || po.Record_Type_Name__c == 'Schedule_Invoice'){
                            component.set("v.disabledEdit", false);
                            if(component.get("v.invoice.Down_Payment__c")!=null && component.get("v.invoice.Down_Payment__c")!='' && component.get("v.invoice.Down_Payment__c")!=undefined && component.get("v.invoice.Down_Payment__c")>0){
                                component.set("v.SchInvoiceAmount", parseFloat(po.Total_Down_Payment_Amount__c));
                                component.set("v.CreditNote.Amount__c", parseFloat(po.Total_Down_Payment_Amount__c));
                                component.set("v.CreditNote.Tax_Amount__c", 0.00);
                            }
                        }
                        if(po.Order_S__c!=null){
                            component.set("v.CreditNote.Order__c", po.Order_S__c);
                        }
                        if(po.Paid_Amount_Applied__c!=undefined){
                            component.set("v.CreditNote.Advance_Amount_Applied__c", parseFloat(po.Paid_Amount_Applied__c));
                            component.set("v.AdvanceAmount", parseFloat(po.Paid_Amount_Applied__c));
                        }else{
                            component.set("v.CreditNote.Advance_Amount_Applied__c", 0);
                            component.set("v.AdvanceAmount", 0);
                        }
                        if(component.get("v.invRT")!='Sales'){
                            var TotalAmount = 0.00;
                            TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
                            component.set("v.totalSchAmount", TotalAmount.toFixed(2));
                        }
                        var poliList = JSON.parse(resultList[1]);
                        if(!$A.util.isEmpty(poliList)){
                            var billList = [];
                            for(var x in poliList){
                                if(poliList[x].Product__r.Track_Inventory__c){
                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity__c,Amount__c:poliList[x].Unit_Price__c,Description__c:poliList[x].Description__c,Discount__c:0.00,Tax_Amount__c:poliList[x].Total_Tax__c
                                               ,Other_Tax__c:0.00
                                              };
                                    billList.push(obj);
                                }else if(poliList[x].Product__r.Is_Asset__c){
                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity__c,Amount__c:poliList[x].Unit_Price__c,Description__c:poliList[x].Description__c, Discount__c:0.00,Tax_Amount__c:poliList[x].Total_Tax__c
                                               ,Other_Tax__c:0.00
                                              };
                                    billList.push(obj);
                                }else{
                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity__c,Amount__c:poliList[x].Unit_Price__c,Description__c:poliList[x].Description__c, Discount__c:0.00,Tax_Amount__c:poliList[x].Total_Tax__c
                                               ,Other_Tax__c:0.00
                                              };
                                    billList.push(obj);
                                }
                            } 
                            component.set("v.lineItems",billList);
                        }else{
                            helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_CredNotes_Bill_Has_Already_Been_Created'));
                            setTimeout(
                                $A.getCallback(function() {
                                    $A.enqueueAction(component.get("c.cancelclick"));
                                }), 3000
                            );
                            
                        }
                    }else{
                        helper.showToast($A.get('$Label.c.PH_Warning'),'warning','Their is already Credit Note against this Invoice');
                    }
                }  
            });
        $A.enqueueAction(fetchpoliAction);
        }
        }
    },
    
    
    fetchrmali : function(component, event, helper) {
        if(!component.get("v.isUpdate")){
        var fetchpoliAction = component.get("c.fetch_rmalis");
        fetchpoliAction.setParams({"Id":component.get("v.CreditNote.Return_Merchandise_Authorisation__c")});
        fetchpoliAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var resultList = response.getReturnValue();
                if(resultList.length > 0){
                    var po = JSON.parse(resultList[0]);
                    component.set("v.CreditNote.Invoice__c", po.Invoice__c);
                    component.set("v.CreditNote.Account__c", po.Account__r.Id);
                    component.set("v.CreditNote.Sales_Order__c", po.SO__c);
                    component.set("v.CreditNote.Organisation__c", po.Organisation__c);
                    component.set("v.disabledEdit",false);
                    if(po.Invoice__c!=null) component.set("v.invRT", po.Invoice__r.Record_Type_Name__c);
                    else component.set("v.invRT", 'Sales');
                    if(po.Restock_Fee__c != null) component.set("v.CreditNote.Fees__c", po.Restock_Fee__c);
                    else component.set("v.CreditNote.Fees__c", 0);
                    if(po.ReStock_Tax__c != null) component.set("v.CreditNote.Restock_Tax__c", po.ReStock_Tax__c);
                    else component.set("v.CreditNote.Restock_Tax__c", 0);
                    //if(po.Shipping_Amount__c != null) component.set("v.CreditNote.Shipping_Amount__c", po.Shipping_Amount__c);
                    //else 
                        component.set("v.CreditNote.Shipping_Amount__c", 0);
                    if(po.Shipping_Tax__c != null) component.set("v.CreditNote.Shipping_Tax__c", po.Shipping_Tax__c);
                    else component.set("v.CreditNote.Shipping_Tax__c", 0);
                    var poliList = JSON.parse(resultList[1]);
                    if(!$A.util.isEmpty(poliList)){
                        var billList = [];
                        for(var x in poliList){
                            if(poliList[x].Product__r.Track_Inventory__c){
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c,Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }else if(poliList[x].Product__r.Is_Asset__c){
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c, Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }else{
                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:poliList[x].Quantity_Return__c,Amount__c:poliList[x].Sale_Price__c,Item_Description__c:poliList[x].Product__r.Description__c, Discount__c:0.00, Tax_Amount__c:poliList[x].Tax__c*poliList[x].Quantity_Return__c
                                           ,Other_Tax__c:0.00
                                          };
                                billList.push(obj);
                            }
                        } 
                        component.set("v.lineItems",billList);
                     }else{
                        helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_CredNotes_Bill_Has_Already_Been_Created'));
                        setTimeout(
                            $A.getCallback(function() {
                                $A.enqueueAction(component.get("c.cancelclick"));
                            }), 3000
                        );
                        
                    }
                }
            }  
        });
        $A.enqueueAction(fetchpoliAction);
        }
    },
    
    
    updateTotalTax : function(c, e, h){
        var items=c.get('v.lineItems');
        if(items.Tax_Rate__c==undefined)items.Tax_Rate__c=0;
        if(items.Other_Tax_Rate__c==undefined)items.Other_Tax_Rate__c=0;
        if(items.Quantity__c==undefined)items.Quantity__c=0;
        if(items.Amount__c==undefined)items.Amount__c=0;
         for(var x in items){
                   if(items[x].Amount__c==undefined)items[x].Amount__c=0;
                   if(items[x].Other_Tax_Rate__c==undefined)items[x].Other_Tax_Rate__c=0;
                   if(items[x].Tax_Rate__c==undefined)items[x].Tax_Rate__c=0;
                   if(items[x].Quantity__c==undefined)items[x].Quantity__c=0;
         }
        if($A.util.isUndefined(items.length)){
            var tax=((items.Total_Amount__c)/100)*items.Tax_Rate__c;
            var OTtax=(items.Amount__c/100)*items.Other_Tax_Rate__c;
            var totalTax=(tax+OTtax)*items.Quantity__c;
             if(c.get("v.invRT")=='Sales') c.set("v.CreditNote.Tax_Amount__c",totalTax);
        }else{
               var totaltax=0;
               var tax = 0;
               var OTtax = 0;
               for(var x in items){
                   tax = items[x].Tax_Amount__c;
                   OTtax =(items[x].Amount__c/100)*items[x].Other_Tax_Rate__c;
                   totaltax+=tax+OTtax;
               }
            if(c.get("v.invRT")=='Sales')c.set("v.CreditNote.Tax_Amount__c",totaltax);
           }
     },
    updateTotalPrice: function(c, e, h) {
       var items=c.get('v.lineItems');
        if($A.util.isUndefined(items.length)){
            var amt=items.Quantity__c * items.Amount__c;
            if(c.get("v.invRT")=='Sales')c.set("v.CreditNote.Amount__c",amt);
        }else{
               var amt=0;
               for(var x in items){
                  amt+=items[x].Quantity__c * items[x].Amount__c 
               }
            if(c.get("v.invRT")=='Sales')c.set("v.CreditNote.Amount__c",amt);
        }
        
       },
    

    UpdateTDS : function(c, e, h){
        
    },
    
    
    goBack : function(component, event, helper) {
        history.back();
    },
    
    
    addNew : function(component, event, helper) {
        var billList = component.get("v.lineItems");
        billList.unshift({sObjectType :'RMA_Line_Item__c'});
        component.set("v.lineItems",billList);
    },
    
    
    saveBill : function(component, event, helper) {
        component.set("v.showMmainSpin", true);
        var billList = component.get("v.lineItems");
        var Billobj = component.get("v.CreditNote");
		        
        //alert('Bill=>'+JSON.stringify(component.get("v.Bill")));
        Billobj.Invoice__r  = null;
        //Billobj.Vendor_Address__r = null;
        //Billobj.Account__r = null;
        //Billobj.Posted__c = component.get('v.setBillPost');
        
        var totalAmount=parseFloat(Billobj.Amount__c);
        
        
       component.NOerrors =  true;
        //helper.validation_Check(component,event);
        
        if(component.NOerrors){
            var showError=false;
            if((component.get("v.CreditNote.Invoice__c")==undefined || component.get("v.CreditNote.Invoice__c")==null)){
                showError = true;
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_CredNotes_Please_select_the_Invoice'));
            }
            if((component.get("v.CreditNote.Reference_Number__c")=='' || component.get("v.CreditNote.Reference_Number__c")==undefined || component.get("v.CreditNote.Reference_Number__c")==null)&& !(showError)){
                showError = true;
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH3_please_Enter_the_reference_number'));
            }
            if((component.get("v.CreditNote.Account__c")==undefined || component.get("v.CreditNote.Account__c")==null)&& !(showError)){
                showError = true;
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_CredNotes_Please_select_the_Customer'));
            }
            
            /*if(billList.length>0 && !(showError)){
                for(var a in billList ){
                    if(billList[a].Chart_Of_Account__c=='' || billList[a].Chart_Of_Account__c==null
                       || billList[a].Chart_Of_Account__c==undefined){
                        showError=true;
                        var po=component.get('v.DebitNote.Purchase_Orders__c');
                        if(po!=null && po!='' && po!=undefined)helper.showToast('Error!','error','Please Select the account for all line items');
                        else helper.showToast('Error!','error','Please Select the expense account for all line items');
                    }
                }
            }*/
            
            var fillList11=component.get("v.fillList");
            /*if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && !(showError)){
                helper.showToast('Error!','error','Credit Note Attachment is missing.');
                return;
            }*/
            component.set("v.showMmainSpin", false);
            if(billList.length>0 && !(showError)){
                component.set("v.showMmainSpin",true);
                var saveAction = component.get("c.saveCreditNote");
                let jsonBill  = JSON.stringify(Billobj);
                let jsonBillItems = JSON.stringify(billList);
                var RTName;
                saveAction.setParams({"creditNote": jsonBill, "credItems" :jsonBillItems});
                saveAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){ 
                        try{
                            var result = response.getReturnValue();
                            //if(!$A.util.isUndefined(result)){
                            var bilobj = result['bill']; 
                            component.set("v.BillId",bilobj.Id);
                            if(component.get('v.setRT')=='PO Bill' || component.get('v.setRT')=='Expense Bill' || component.get('v.setRT')=='Advance to vendor'){
                                if(component.find("fileId").get("v.files")!=null){
                                    
                                    if (component.find("fileId").get("v.files").length > 0 && fillList11.length > 0) {                                
                                        var fileInput = component.get("v.FileList");
                                        for(var i=0;i<fileInput.length;i++)
                                            helper.saveAtt(component,event,fileInput[i],bilobj.Id);
                                    }
                                }
                                if(component.get("v.Attach")!=null){
                                    var Billobj = component.get("v.BillId");
                                    var action=component.get("c.save_attachment2");
                                    action.setParams({"parentId": Billobj,"Pid":component.get("v.Bill.Purchase_Order__c"), 
                                                     });
                                    action.setCallback(this,function(response){
                                        if(response.getState() === 'SUCCESS'){
                                        }
                                    });
                                    $A.enqueueAction(action);
                                }
                                
                            }
                            if(!$A.util.isUndefinedOrNull(result['error'])) {
                                helper.showToast('Error!','error',result['error']);
                                component.set("v.showMmainSpin",false);
                                return ;
                            }
                            if(component.get("v.isUpdate")) helper.showToast($A.get('$Label.c.Success'),'success', $A.get('$Label.c.PH_CredNotes_Credit_Note_Updated_Successfully'));
                            else helper.showToast($A.get('$Label.c.Success'),'success', $A.get('$Label.c.PH_CredNotes_Credit_Note_Created_Successfully'));
                            
                            if(component.get("v.navigateToRecord")){
                                var navEvt = $A.get("e.force:navigateToSObject");
                                if(navEvt != undefined){
                                    /*navEvt.setParams({
                                    "isredirect": true,
                                    "recordId": result['bill'].Id,
                                    "slideDevName": "detail"
                                }); 
                                navEvt.fire();*/
                                    var url = '/'+result['bill'].Id;
                                    window.location.replace(url);
                                }else {
                                    var selectedBillList=[];
                                    selectedBillList.push(result['bill'].Id);
                                    var url = '/'+result['bill'].Id;
                                    window.location.replace(url);
                                }
                            }else{
                                var selectedBillList=[];
                                var result = response.getReturnValue(); 
                                /*var bilobj = result['bill2'];
                            var evt = $A.get("e.force:navigateToComponent");
                                evt.setParams({
                                    componentDef : "c:Accounts_Payable",
                                    componentAttributes: {
                                        "selectedTab" : 'Bills',
                                        "setSearch" : bilobj.Name,
                                    }
                                });
                                evt.fire(); */
                                var url = '/'+result['bill'].Id;
                                window.location.replace(url);
                            }
                            component.set("v.showMmainSpin",false);
                        }catch(e){
                            component.set("v.showMmainSpin",false);
                            console.log('exception in trycatch~>'+e);
                        }
                    }else{
                        component.set("v.showMmainSpin",false);
                        var errors = response.getError();
                        console.log("server error : ", errors);
                        helper.showToast('Error!','error',errors[0].message);
                    }
                });
                $A.enqueueAction(saveAction);
            }else{
                if(!showError)helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item'));
            } 
        }else{
            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Review_All_Errors'));
            component.set("v.showMmainSpin", false);
        }
    },
    
     handleFilesChange: function(component, event, helper) {
        component.set("v.showDelete",true);
        var fileName = 'No File Selected..';
        //var files = component.get("v.FileList");  
        
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            var fileItem = [];
            for(var i=0;i<event.getSource().get("v.files").length;i++){
                fileItem.push(event.getSource().get("v.files")[i]['name']);
            }
        }
        //alert(fileItem);
        component.set("v.fillList",fileItem);
        component.set("v.fileName", fileName);
    },
    
     removeAttachment : function(component, event, helper) {
        component.set("v.showDelete",false);
        var fileName = 'No File Selected..';
        component.set("v.fileName", fileName);
        //component.set('v.fillList',null);
        
        var fillList=component.get("v.fillList");
        fillList.splice(0, fillList.length); 
        component.set("v.fillList",fillList);
        /*for(var i in fillList){
            fillList[i].po
        }*/
    },
    
    
     deleteLineItem : function(component, event, helper) {
       var billList = component.get("v.lineItems");
        billList.splice(event.getParam("Index"),1);
        component.set("v.lineItems",billList);
    },
    
    
    checkAdvance : function(component, event, helper) {
        if(!$A.util.isEmpty(component.get("v.CreditNote.Advance_Amount_Applied__c"))){
            if(component.get("v.CreditNote.Advance_Amount_Applied__c")>component.get("v.AdvanceAmount")){
                helper.showToast('!Warning','warning','Advance Amount Applied is more than Invoice Advance Applied Amount');
                component.set("v.CreditNote.Advance_Amount_Applied__c", component.get("v.AdvanceAmount"));
            }
        }else{
            component.set("v.CreditNote.Advance_Amount_Applied__c", 0);
        }
        var TotalAmount = 0.00;
        TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
        component.set("v.totalSchAmount", TotalAmount.toFixed(2));
    },
    
    checkEmpty : function(component, event, helper) {
        if($A.util.isEmpty(component.get("v.CreditNote.Amount__c"))){
            component.set("v.CreditNote.Amount__c", 0)
        }
        if($A.util.isEmpty(component.get("v.CreditNote.Tax_Amount__c"))){
            component.set("v.CreditNote.Tax_Amount__c", 0)
        }
        if($A.util.isEmpty(component.get("v.CreditNote.Additional_Cost__c"))){
            component.set("v.CreditNote.Additional_Cost__c", 0)
        }
        var TotalAmount = 0.00;
        TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
        component.set("v.totalSchAmount", TotalAmount.toFixed(2));
        
    },
    
    
    checkCreditAmount : function(component, event, helper) {
        if(!$A.util.isEmpty(component.get("v.CreditNote.Amount__c"))){
            if(component.get("v.CreditNote.Amount__c")>component.get("v.SchInvoiceAmount")){
                helper.showToast('!Warning','warning','Credit Applied is more than the Invoice Amount');
                component.set("v.CreditNote.Amount__c", component.get("v.SchInvoiceAmount"));
            }
        }else{
            component.set("v.CreditNote.Amount__c", 0);
        }
        var TotalAmount = 0.00;
        TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
        component.set("v.totalSchAmount", TotalAmount.toFixed(2));
    },
    
    checkCreditTax : function(component, event, helper) {
        if(!$A.util.isEmpty(component.get("v.CreditNote.Amount__c"))){
            if(component.get("v.CreditNote.Tax_Amount__c")>component.get("v.invoice.Tax_Amount__c")){
                helper.showToast('!Warning','warning','Credit Tax Applied is more than the schedule invoice Tax Amount');
                component.set("v.CreditNote.Tax_Amount__c", component.get("v.invoice.Tax_Amount__c"));
            }
        }else{
            component.set("v.CreditNote.Tax_Amount__c", 0);
        }
        var TotalAmount = 0.00;
        TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
        component.set("v.totalSchAmount", TotalAmount.toFixed(2));
    },
    
    
    checkCreditAdvAmount : function(component, event, helper) {
        if(!$A.util.isEmpty(component.get("v.CreditNote.Amount__c"))){
            if(component.get("v.CreditNote.Amount__c")>component.get("v.SchInvoiceAmount")){
                helper.showToast('!Warning','warning','Credit Applied is more than the Advance Amount');
                component.set("v.CreditNote.Amount__c", component.get("v.SchInvoiceAmount"));
            }
        }else{
            component.set("v.CreditNote.Amount__c", 0);
        }
        var TotalAmount = 0.00;
        TotalAmount = parseFloat(component.get("v.CreditNote.Amount__c")) + parseFloat(component.get("v.CreditNote.Tax_Amount__c")) +  parseFloat(component.get("v.CreditNote.Additional_Cost__c")) - parseFloat(component.get("v.CreditNote.Advance_Amount_Applied__c"));
        component.set("v.totalSchAmount", TotalAmount.toFixed(2));
    },
})
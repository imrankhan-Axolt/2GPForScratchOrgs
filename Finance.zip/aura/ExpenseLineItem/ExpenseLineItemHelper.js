({
    showToast : function(title, type, message) {
        
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent != undefined){
            toastEvent.setParams({
                "mode":"dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }
    },
    
	setExpenseCategory : function(component, event) {
		var action = component.get("c.getCategorypickval");
        var inputsel = component.find("ExpenseCategory");
        var opts = [];
        action.setCallback(this, function(a) {
            for (var i = 0; i < a.getReturnValue().length; i++) {
                opts.push({
                    "class": "optionClass",
                    label: a.getReturnValue()[i],
                    value: a.getReturnValue()[i]
                });
            }
            //inputsel.set("v.options", opts);
            component.set("v.ExpenseCategoryOptions",opts);
        });
        $A.enqueueAction(action);
        component.set("v.isSetCategory",true);
	},
    
    setExpenseType : function(component, event) {
		var action = component.get("c.getTypepickval");
        var inputsel = component.find("ExpenseType");
        var opts = [];
        action.setCallback(this, function(response) {
            for (var i = 0; i < response.getReturnValue().length; i++) {
                opts.push({
                    "class": "optionClass",
                    label: response.getReturnValue()[i],
                    value: response.getReturnValue()[i]
                });
            }
            //inputsel.set("v.options", opts);
            component.set("v.ExpenseTypeOptions",opts);
        });
        $A.enqueueAction(action);
        component.set("v.isSetCategory",true);
	},
    
    deleteCurExpli : function(component, event, xpensLI) {
        $A.util.removeClass(component.find('mainSpin'), "slds-hide");
        var delAction = component.get("c.delCurExpli");
        var curExpLI = JSON.stringify(xpensLI);
        delAction.setParams({
            delExpli : curExpLI
        });
        delAction.setCallback(this, function(response) {
            var state = delAction.getState();
            if(state === "SUCCESS") {
                console.log('resp ',response.getReturnValue());
                var e = $A.get("e.c:IndexingEvent");
                e.setParams({
                    "Index" : component.get("v.index")
                })
                e.fire();
        		$A.util.addClass(component.find('mainSpin'), "slds-hide");
            }
        });
        $A.enqueueAction(delAction);
    },
    
    
    deleteSplitExpli : function(component, event, xpensLI) {
        var delAction = component.get("c.delCurExpli");
        var curExpLI = JSON.stringify(xpensLI);
        delAction.setParams({
            delExpli : curExpLI
        });
        delAction.setCallback(this, function(response) {
            var state = delAction.getState();
            if(state === "SUCCESS") {
                this.fetchExistingExpense(component, event);
                var Expline = [];
                Expline = component.get("v.splittedExpLine");
                Expline.pop(xpensLI);
                component.set("v.splittedExpLine", Expline);
            }
        });
        $A.enqueueAction(delAction);
    },
    
  
    
    fetchExistingExpense : function(component, event) {
        var action=component.get("c.fetchExpRecords");
        action.setParams({'ExpId':component.get("v.splitExpense.Id")})
        action.setCallback(this,function(response){
            if(response.getState() === "SUCCESS"){
                if(response.getReturnValue()!=null){
                    var explist = response.getReturnValue();
                    var expLine = [];
                    if(component.get("v.splitExpense.VAT_Amount__c") != null && component.get("v.splitExpense.VAT_Amount__c") != undefined && component.get("v.splitExpense.VAT_Amount__c")>0 && explist.length<= 0){
                        this.fetchTaxCOA(component, event);
                    }else{
                        for(var i=0; i<explist.length;i++){
                            expLine[i] = explist[i].expline;
                            expLine[i].Chart_Of_Account__c = explist[i].COAId;
                        }
                    }
                    component.set("v.splittedExpLine", expLine);
                }
            }
            else{
                var errors = response.getError();
                console.log("err -> ", errors);
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchTaxCOA : function(component, event){
        var action=component.get("c.fetchDefaultTaxCOA");
        action.setParams({'Amount':component.get("v.splitExpense.VAT_Amount__c")});
        action.setCallback(this,function(response){
            if(response.getState() === "SUCCESS"){
                if(response.getReturnValue()!=null){
                    var ExpList = [];
                    ExpList = response.getReturnValue().expLine;
                    for(var i= 0; i<ExpList.length;i++){
                        ExpList[i].Chart_Of_Account__c = response.getReturnValue().COAId;
                    }
                    if(response.getReturnValue()!=null) component.set("v.splittedExpLine", ExpList);
                    
                }
            }
            else{
                var errors = response.getError();
                console.log("err -> ", errors);
            }
        });
        $A.enqueueAction(action);
    }
    
})
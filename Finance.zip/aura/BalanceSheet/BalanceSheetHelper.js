({
    updateData : function (component, event, helper){ 
        component.set('v.showSpinner', true);
        var action = component.get('c.fecthDetails');
        action.setParams({
            Ins : JSON.stringify(component.get('v.Instance')),  
            selectedIso : component.get('v.Instance.SelectedCurrency')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                component.set('v.stopRepeat', false);
                component.set('v.Instance', response.getReturnValue());
                if(component.get('v.Instance.multiCurrencyEnabled')!=null)
                component.set('v.Instance.SelectedCurrency',component.get('v.Instance.userIsoCode'));
                //component.set('v.Instance.multiCurrencyEnabled', true);
                component.set('v.Org', component.get('v.Instance.Select_Organisation.Company__c'));
                component.set('v.SD',  component.get('v.Instance.sDate'));
                component.set('v.ED',  component.get('v.Instance.eDate'));
                component.set('v.showPage', true);  
                component.set('v.showAsset', response.getReturnValue().balanceSheetAccounts['Assets']);
                component.set('v.showLiability', response.getReturnValue().balanceSheetAccounts['Liability']);
                component.set('v.showEquity', response.getReturnValue().balanceSheetAccounts['Equity']);
                if(component.get('v.setPick')=='set') component.set("v.FYOptions",response.getReturnValue().getPickList); //component.find("FY").set("v.options", response.getReturnValue().getPickList);
                component.set('v.setPick','Not set');
                component.set('v.picklists',response.getReturnValue().getPickList);
                component.set('v.showSpinner', false);
                var label = 'Revenue In '+component.get('v.Instance.CurrencyISO');
                component.set('v.chartyLabel', label);
                component.set('v.stopRepeat',true);
                
               
                
                
               }else{
                   component.set('v.showSpinner', false);
               
            }
        });
        $A.enqueueAction(action);
        var stockTakeStatus = component.get("c.getCurrencies");
        stockTakeStatus.setCallback(this,function(response){
            //component.find("stStatus").set("v.options", response.getReturnValue());     
            component.set("v.stStatusOptions", response.getReturnValue());
        });
        $A.enqueueAction(stockTakeStatus);
          
       },
    
    fetchData : function (component, event, helper){ 
        component.set('v.showSpinner', true);
        var action = component.get('c.fecthDetails');
        action.setParams({
            Ins : JSON.stringify(component.get('v.Instance')),  
            selectedIso : component.get('v.Instance.SelectedCurrency')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                component.set('v.stopRepeat', false);
                component.set('v.Instance', response.getReturnValue());
                component.set('v.Instance.SelectedCurrency',component.get('v.Instance.userIsoCode'));
                //component.set('v.Instance.multiCurrencyEnabled', true);
                component.set('v.Org', component.get('v.Instance.Select_Organisation.Company__c'));
                component.set('v.SD',  component.get('v.Instance.sDate'));
                component.set('v.ED',  component.get('v.Instance.eDate'));
                component.set('v.showPage', true);  
                component.set('v.showAsset', response.getReturnValue().balanceSheetAccounts['Assets']);
                component.set('v.showLiability', response.getReturnValue().balanceSheetAccounts['Liability']);
                component.set('v.showEquity', response.getReturnValue().balanceSheetAccounts['Equity']);
                if(component.get('v.setPick')=='set') component.set("v.FYOptions",response.getReturnValue().getPickList); //component.find("FY").set("v.options", response.getReturnValue().getPickList);
                component.set('v.setPick','Not set');
                component.set('v.picklists',response.getReturnValue().getPickList);
                component.set('v.showSpinner', false);
                var label = 'Revenue In '+component.get('v.Instance.CurrencyISO');
                component.set('v.chartyLabel', label);
                component.set('v.stopRepeat',true);
                
               
                
                
               }else{
                component.set('v.showSpinner', false);
            }
        });
        $A.enqueueAction(action);
        
       },
    getGraphData : function(component, event, helper){
      var action = component.get('c.getGraphValues');
        action.setParams({
            B:JSON.stringify(component.get('v.Instance'))
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if( state === "SUCCESS"){
                component.set('v.Instance', response.getReturnValue()); 
                var k =[]; var v = [];var data = component.get('v.Instance.datalist');
                for(var a in data ){
                    //if(data[a].data1 > 0 || data[a].data1 <0){
                        if(data[a].name!=undefined && data[a].name!=null && data[a].name!=''){
                            k.push(data[a].name); 
                            v.push(data[a].data1);
                        }
                    //}
                }
                component.set('v.setKeys', k);
                component.set('v.setValues', v);
                component.set('v.showSpinner', false);
                component.set('v.Tab','Tab2');
                //component.find('FY1').set('v.options', component.get('v.picklists'));
                component.set("v.FY1Options",component.get('v.picklists'));
                component.set('v.callGraph',false);
                component.set('v.stopRepeat', true);
              
            }else{
                component.set('v.showSpinner', false);
            }
        });
        $A.enqueueAction(action);
    },
})
({
	doinit : function(component, event, helper) {
        if(component.get('v.stopRepeat')){
            helper.updateData(component, event, helper);
        }
    },
  
    fetchDetailscontroller : function(component, event, helper){
         if(component.get('v.stopRepeat')){
            helper.fetchData(component, event, helper);
        }
    },
    
    
    onOrgChange : function(component, event, helper) {
        var org = component.get('v.Instance.Select_Organisation.Company__c');
        if(component.get('v.stopRepeat') &&  org != null && org != undefined && org != ''){
             helper.updateData(component, event, helper);
         }
    },
    
    FYChange : function(component, event, helper){
        var FY = component.get('v.Instance.SelectedFy_BS');
         if( component.get('v.stopRepeat') &&  FY != null && FY != undefined && FY != ''){
           helper.updateData(component, event, helper);           
         }
    },
    
    SDChange : function(component, event, helper){
        if( component.get('v.stopRepeat')){
            helper.updateData(component, event, helper); 
        } 
    },
    
    EDChange : function(component, event, helper){
        if( component.get('v.stopRepeat')){
            helper.updateData(component, event, helper); 
        } 
    },
    
    
    changeTab1 : function(component, event, helper){
        component.set('v.Tab', 'Tab1');
        component.set('v.Instance.SelectedCurrency',component.get('v.Instance.userIsoCode'));
        //component.find('FY').set('v.options', component.get('v.picklists'));
        component.set("v.FYOptions",component.get('v.picklists')); 
        var stockTakeStatus = component.get("c.getCurrencies");
        stockTakeStatus.setCallback(this,function(response){
            //component.find("stStatus").set("v.options", response.getReturnValue()); 
            component.set("v.stStatusOptions", response.getReturnValue());
        });
        $A.enqueueAction(stockTakeStatus);
                
    },
    changeTab2 : function(component, event, helper){
        component.set('v.stopRepeat', false);
        component.set('v.showSpinner', true);
        component.set('v.callGraph',true);
        if(component.get('v.callGraph')){
        var action = component.get('c.ComputeData');
        action.setParams({
            B:JSON.stringify(component.get('v.Instance'))
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if( state === "SUCCESS"){
                component.set('v.Instance', response.getReturnValue());                
                
                helper.getGraphData(component, event, helper);
                component.set('v.callGraph',true);
               }else{
                component.set('v.showSpinner', false);   
            }
        });
        $A.enqueueAction(action);
        }else{
            component.set('v.Tab','Tab2');
            //component.find('FY1').set('v.options', component.get('v.picklists'));
            component.set("v.FY1Options",component.get('v.picklists'));
            component.set('v.showSpinner', false); 
            component.set('v.stopRepeat', true);
        }
      }, 
    
    changeData : function(component, event, helper){
        component.set('v.stopRepeat', false);
        component.set('v.showSpinner', true);
        var selType= event.currentTarget.getAttribute("name");
         switch(selType) {
            case 'Fyear'    :component.set('v.setView', 'Annually');
                             break;
            case 'FQuarter' : component.set('v.setView', 'Quaterly');
                             break;
            case 'FMonthly' :component.set('v.setView', 'Monthly');
                             break;
        }
        component.set('v.Instance.YearorQuarter', selType); 
        var action = component.get('c.ComputeData');
        action.setParams({
            B:JSON.stringify(component.get('v.Instance'))
        });
        action.setCallback(this, function(response){
            var state = response.getState();    
            if( state === "SUCCESS"){
                 component.set('v.Instance', response.getReturnValue());
                 component.set('v.showSpinner', false);
                 component.set('v.stopRepeat', true);
            }else{
                component.set('v.showSpinner', false);
            }
        });
        $A.enqueueAction(action);
    }, 
})
({
    showToast : function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent != undefined){
            toastEvent.setParams({
                "mode":"dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }else{
            sforce.one.showToast({
                "title": title,
                "message": message,
                "type": type
            });
        }
        
    },
    
    /*getAttachment : function (component, event) {
        var action=component.get("c.uploadFile");
        action.setParams({
            "pid" : component.get("v.Bill.Purchase_Order__c")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            alert('state'+state);
            if( state === "SUCCESS" ){
                 component.set("v.Attach",response.getReturnValue());
               
            }
        });
        $A.enqueueAction(action);
    },*/
    
    /*FieldAccess:function (component, event) {
       var action=component.get("c.FieldAccessibility");
       action.setCallback(this,function(response){
        component.set('v.FieldAccess',response.getReturnValue());
        });
        $A.enqueueAction(action);
    },*/
    
    FieldAccess:function (component, event) {
        $A.util.removeClass(component.find('mainSpin'), "slds-hide");
        var action=component.get("c.CreateBillCheckFLS");
        action.setCallback(this,function(response){
            if(response.getState() === "SUCCESS"){
                console.log('CreateBillFLSCheck~>'+response.getReturnValue());
                component.set('v.CreateBillFLSCheck',response.getReturnValue());
            }
            else{
                var errors = response.getError();
                console.log("errors -> ", errors);
            }
            $A.util.addClass(component.find('mainSpin'), "slds-hide");
        });
        $A.enqueueAction(action);
    },
    
    getPOLIDimeListhelper : function (component, event, helper) {
        try{
            component.set("v.showMmainSpin",true);
            console.log('getPOLIDimeListhelper called');
            var action = component.get("c.getPOLIDimeList");
            action.setParams({
                "POId": component.get("v.Bill.Purchase_Order__c"),
            });
            action.setCallback(this, function(response){
                if(response.getState() === "SUCCESS"){
                    component.set("v.showMmainSpin",false);
                    console.log("getPOLIDimeListhelper resp: ", JSON.stringify(response.getReturnValue()));
                    var dimeList = response.getReturnValue();
                    var pli = component.get("v.billItems");
                    console.log('getPOLIDimeListhelper pli~>'+JSON.stringify(pli));
                    
                    var poliAcc = []; var poliAccCat = ''; var poliAccCOA = '';
                    try{
                        for(var x in pli){
                            poliAcc = []; poliAccCat = ''; poliAccCOA = '';
                            if(dimeList != undefined && dimeList != null && dimeList.length > 0){
                                for(var y in dimeList){
                                    console.log('inhere dimeList loop');
                                    if(pli[x].Purchase_Order_Line_Items__c != undefined && pli[x].Purchase_Order_Line_Items__c != null && pli[x].Purchase_Order_Line_Items__c != ''){
                                        if(pli[x].Purchase_Order_Line_Items__c == dimeList[y].Purchase_Line_Items__c){
                                            console.log('value matched');
                                            poliAcc.push(dimeList[y]);
                                            //Changed Shaguftha 24/10/23 from dimeList[y].Purchase_Line_Items__r.Account_Category__c && dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c to dimeList[y].Account_Category__c and dimeList[y].Chart_of_Account__c respectively
                                            if(dimeList[y].Account_Category__c != undefined && dimeList[y].Account_Category__c != null && dimeList[y].Account_Category__c != ''){
                                                poliAccCat =dimeList[y].Account_Category__c; //dimeList[y].Purchase_Line_Items__r.Account_Category__c;
                                            }
                                            if(dimeList[y].Chart_of_Account__c != undefined && dimeList[y].Chart_of_Account__c != null && dimeList[y].Chart_of_Account__c != ''){
                                                poliAccCOA = dimeList[y].Chart_of_Account__c; //dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c;
                                            }
                                        }
                                    }
                                }
                            }
                            if(poliAccCat != '') pli[x].Account_Category__c = poliAccCat;
                            console.log('getPOLIDimeListhelper pli[x].Account_Category__c set : ',poliAccCat);
                            if(poliAccCOA != '') pli[x].Chart_Of_Account__c = poliAccCOA;
                            console.log('getPOLIDimeListhelper pli[x].Chart_Of_Account__c set : ',poliAccCOA);
                            pli[x].Accounts = poliAcc;
                            console.log('getPOLIDimeListhelper pli[x].Accounts set');
                        }
                    }catch(e){
                        console.log('getPOLIDimeListhelper err heree1~>',e);
                        component.set("v.showMmainSpin",false);
                    }
                    console.log('getPOLIDimeListhelper setting here billItems pli~>',JSON.stringify(pli));
                    //component.set("v.billItems",[]);
                    component.set("v.billItems",pli);
                    component.set("v.showMmainSpin",false);
                }else{
                    var errors = response.getError();
                    console.log("server error in getPOLIDimeListhelper : ", JSON.stringify(errors));
                    component.set("v.showMmainSpin",false);
                } 
            });
            $A.enqueueAction(action);
        }catch(e){
            console.log('getPOLIDimeListhelper err heree~>',e);
            component.set("v.showMmainSpin",false);
        }
    },
    
    getPOLIDimeListMultihelper : function (component, event, helper) {
        try{
            component.set("v.showMmainSpin",true);
            console.log('getPOLIDimeListhelper called');
            var action = component.get("c.getPOLIDimeMultiList");
            action.setParams({
                "POIds": component.get("v.POIdsList"),
            });
            action.setCallback(this, function(response){
                if(response.getState() === "SUCCESS"){
                    component.set("v.showMmainSpin",false);
                    console.log("getPOLIDimeListhelper resp: ", JSON.stringify(response.getReturnValue()));
                    var dimeList = response.getReturnValue();
                    var pli = component.get("v.billItems");
                    var poliAcc = []; var poliAccCat = ''; var poliAccCOA = '';
                    for(var x in pli){
                        poliAcc = []; poliAccCat = ''; poliAccCOA = '';
                        for(var y in dimeList){
                            if(pli[x].Purchase_Order_Line_Items__c != undefined && pli[x].Purchase_Order_Line_Items__c != null && pli[x].Purchase_Order_Line_Items__c != ''){
                                if(pli[x].Purchase_Order_Line_Items__c == dimeList[y].Purchase_Line_Items__c){
                                    poliAcc.push(dimeList[y]);
                                    if(dimeList[y].Purchase_Line_Items__r.Account_Category__c != undefined && dimeList[y].Purchase_Line_Items__r.Account_Category__c != null && dimeList[y].Purchase_Line_Items__r.Account_Category__c != ''){
                                        poliAccCat = dimeList[y].Purchase_Line_Items__r.Account_Category__c;
                                    }
                                    if(dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c != undefined && dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c != null && dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c != ''){
                                        poliAccCOA = dimeList[y].Purchase_Line_Items__r.Chart_of_Account__c;
                                    }
                                }
                            }
                        }
                        if(poliAccCat != '') pli[x].Account_Category__c = poliAccCat;
                        if(poliAccCOA != '') pli[x].Chart_Of_Account__c = poliAccCOA;
                        pli[x].Accounts = poliAcc;
                    }
                    console.log('setting here billItems');
                    console.log(pli);
                    //component.set("v.billItems",[]);
                    component.set("v.billItems",pli);
                    component.set("v.showMmainSpin",false);
                }else{
                    var errors = response.getError();
                    console.log("server error in doInit : ", JSON.stringify(errors));
                    component.set("v.showMmainSpin",false);
                } 
            });
            $A.enqueueAction(action);
        }catch(e){
            console.log('err heree~>',e);
            component.set("v.showMmainSpin",false);
        }
    },
    
    hideSpinner : function (component, event) {
        var spinner = component.find('spinner');
        $A.util.addClass(spinner, "slds-hide");    
    },
    
    // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event) {
        var spinner = component.find('spinner');
        $A.util.removeClass(spinner, "slds-hide");   
    },
    
    validation_Check : function (component, event) {
        // component.NOerrors = true;
        var billName = component.find("billName");
        if(!$A.util.isUndefined(billName)) 
            this.checkValidationField(component,billName);
        var vendorAcc = component.find("vendorAccount");
        if(!$A.util.isUndefined(vendorAcc))
            this.checkvalidationLookup(component,vendorAcc);
        var billList = component.find("bill_Items");
        if(!$A.util.isUndefined(billList))
            if(billList.length>0){
                var flag = true;
                for(var x  in billList)
                    flag = billList[x].callValidate(); 
                if(!flag && component.NOerrors) component.NOerrors = false;
            }else{
                component.NOerrors = billList.callValidate(); 
            }       
    },
    
    checkValidationField : function(component,cmp){
        if($A.util.isEmpty(cmp.get("v.value"))){
            cmp.set("v.class","slds-input hasError");
            component.NOerrors = false;
        }else
            cmp.set("v.class","slds-input");   
    },
   
    checkvalidationLookup : function(component,lkpField){
        if($A.util.isEmpty(lkpField.get("v.selectedRecordId"))){
            lkpField.set("v.inputStyleclass","hasError");
            component.NOerrors = false;
        }else
            lkpField.set("v.inputStyleclass","");    
    },
    
    calculateAdvBill: function(cmp,event){
        
        cmp.set('v.advPayment',0.00);
        var action=cmp.get("c.fetchAdvBill");
        action.setParams({
            POId:cmp.get("v.Bill.Purchase_Order__c"),
            venId:cmp.get('v.Bill.Vendor__c')
        });
        action.setCallback(this, function(response){
            if(response.getState() =='SUCCESS'){
                var res=response.getReturnValue();
                cmp.set('v.advBillList',res);
                if(res.length > 0){
                    const resCont=JSON.parse(JSON.stringify(res));
                    var advPay=0;
                    for(var i in resCont){
                        if(resCont[i].Status__c='Paid' && resCont[i].Amount_Paid__c > 0){
                            advPay+=resCont[i].Amount_Paid__c;
                        }
                    }
                    cmp.set('v.advPayment',advPay);
                }
            }else{
                console.log('ERROR:',response.getError());
            }
        });
        $A.enqueueAction(action);
    },
    
    /*saveAtt : function(component,event,file,parentId){
        try{
            
            var getchunk,filename,fileType, fileContents ;
            var objFileReader = new FileReader();
            // set onload function of FileReader object   
            objFileReader.onload = $A.getCallback(function() {
                fileContents = objFileReader.result;
                var base64 = 'base64,';
                var dataStart = fileContents.indexOf(base64) + base64.length;
                fileContents = fileContents.substring(dataStart);
                var startPosition = 0;
                var endPosition = Math.min(fileContents.length, startPosition + 750000);
                getchunk = fileContents.substring(startPosition, endPosition);
                
                var saveAction = component.get("c.save_attachment");
                
                saveAction.setParams({
                    "parentId": parentId,
                    "FileName": file.name, 
                    "FileType" :file.type,
                    "Base64":fileContents.substring(startPosition, endPosition)
                });
                saveAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){
                    }else{
                    }
                });
                $A.enqueueAction(saveAction);
            });
            objFileReader.readAsDataURL(file);
        }catch(err){
        }        
    },*/
    
    /*AnalyticalAccountCheck : function(component, event, helper) {
        var poli = component.get("v.billItems");
        var arshbool = false;
        for(var x in poli){
            var TotalAmount = 0.00;
            TotalAmount = parseFloat(poli[x].Total_Amount__c); //.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            console.log('TotalAmount~>'+TotalAmount+' typeof ~>'+typeof TotalAmount);
            //if(poli[x].Tax_Amount__c != null && poli[x].Tax_Amount__c != undefined && poli[x].Tax_Amount__c != '') TotalAmount = parseFloat(poli[x].Total_Amount__c - poli[x].Tax_Amount__c);
            //else TotalAmount = poli[x].Total_Amount__c;
            var acc = [];
            console.log('AnalyticalAccountCheck : ',JSON.stringify(poli[x]));
            acc = poli[x].Accounts;
            var accTotal = 0.00;
            if(acc != undefined && acc != null){
                if(acc.length > 0){
                    for(var y in acc){
                        if(acc[y].Allocation_Amount__c != undefined && acc[y].Allocation_Amount__c != null && acc[y].Allocation_Amount__c != ''){
                            if(acc[y].Allocation_Amount__c > 0) accTotal += parseFloat(acc[y].Allocation_Amount__c);
                            console.log('accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                        }
                    }
                    console.log('final 1 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                    console.log('final 2 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal);
                    console.log('final 3 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    
                    console.log(' item '+x+' and its TotalAmount~>'+TotalAmount+' and its accTotal~>'+accTotal);
                    if(accTotal > TotalAmount){
                        //this.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error','Alanytical Account amount is greater then line item amount for line item '+x);
                        return true;
                    }else if(TotalAmount > accTotal){
                        return true;
                    }
                }
            }
        }
        return arshbool;
    },*/
    
    AnalyticalAccountCheck : function(component, event, helper) {
        var poli = component.get("v.billItems");
        var bool = false;
        //for(var x in poli){
        for(var x = 0; x < poli.length; x++){//Moin added this on 09th september
            var TotalAmount = 0.00;
            TotalAmount = parseFloat(poli[x].Total_Amount__c).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            console.log('final 1 TotalAmount~>'+TotalAmount+' typeof ~>'+typeof TotalAmount);
            
            TotalAmount = parseFloat(TotalAmount).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            console.log('final 2 TotalAmount~>'+TotalAmount+' typeof ~>'+typeof TotalAmount);
            TotalAmount = parseFloat(TotalAmount).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            console.log('final 3 TotalAmount~>'+TotalAmount+' typeof ~>'+typeof TotalAmount);
            
            var acc = [];
            console.log('AnalyticalAccountCheck : ',JSON.stringify(poli[x]));
            acc = poli[x].Accounts;
            var accTotal = 0.00;
            if(acc != undefined && acc != null){
                if(acc.length > 0){
                    for(var y in acc){
                        if(acc[y].Allocation_Amount__c != undefined && acc[y].Allocation_Amount__c != null && acc[y].Allocation_Amount__c != ''){
                            if(acc[y].Allocation_Amount__c > 0) accTotal += ((parseFloat(parseFloat(poli[x].Quantity__c) * parseFloat(poli[x].Amount__c) * acc[y].Allocation_Percentage__c)/100)); 
                            //parseFloat(acc[y].Allocation_Amount__c).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                            console.log('accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                        }
                    }
                    console.log('final 1 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                    console.log('final 2 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                    console.log('final 3 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    
                    console.log(' item '+x+' and its TotalAmount~>'+TotalAmount+' and its accTotal~>'+accTotal);
                    if(accTotal > TotalAmount){
                        //this.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error','Alanytical Account amount is greater then line item amount for line item '+x);
                        return true;
                    }else if(TotalAmount > accTotal){
                        return true; 
                    }
                }
            }
        }
        return bool;
    },
    
    AnalyticalAccountCoaCheck : function(component, event, helper) {
        var poli = component.get("v.billItems");
        var arshbool = false;
        for(var x in poli){
            var acc = [];
            acc = poli[x].Accounts;
            if(acc != undefined && acc != null){
                if(acc.length > 0){
                    if(poli[x].Chart_Of_Account__c == null || poli[x].Chart_Of_Account__c == undefined || poli[x].Chart_Of_Account__c == '') {
                        return true;
                    }
                    for(var y in acc){
                        if(acc[y].Project__c == null || acc[y].Project__c == undefined || acc[y].Project__c == ''){
                            return true;
                        }
                    }
                }
            }
        }
        return arshbool;
    },
    
    fetchcurrency : function(component, event, helper) {
        var action=component.get("c.getCurrencies");
        action.setParams({});
        action.setCallback(this,function(response){
            component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
            component.set("v.currencyList",response.getReturnValue().currencyList);
        });
        $A.enqueueAction(action);
    },
    
    fetchPOCurrncy : function(component, event, helper) {
        var action=component.get("c.getPOCurrencies");
        action.setParams({
            "PoId" : component.get("v.Bill.Purchase_Order__c")
        });
        action.setCallback(this,function(response){
            component.set("v.Bill.CurrencyIsoCode",response.getReturnValue());
            
        });
        $A.enqueueAction(action);
    },
    
    fetchOrgCurrncy : function(component, event, helper) {
        var action=component.get("c.getOrgCurrencies");
        action.setParams({'OrgId' : component.get("v.Bill.Organisation__c")});
        action.setCallback(this,function(response){
            if(response.getReturnValue() != null) component.set("v.Bill.CurrencyIsoCode",response.getReturnValue());
            
        });
        $A.enqueueAction(action);
    },
    
    getBillDetails : function(component, event, helper) {
        console.log('getBillDetails called');
        
        var action=component.get("c.getBillDetailAndItems");
        action.setParams({'recId' : component.get("v.recordId")});
        action.setCallback(this,function(response){
            console.log('response.getState() getBillDetailAndItems : ',response.getState());
            if(response.getState() === 'SUCCESS'){
                console.log('response.getReturnValue() getBillDetailAndItems : ',response.getReturnValue());
                if(response.getReturnValue() != null) {
                    var result =response.getReturnValue();
                    if(result.eror != undefined && result.eror != null && result.eror != ''){
                        helper.showToast('Error','error',result.eror);
                    }
                    else{
                        component.set("v.Bill",result.bill);
                        component.set("v.ShowBillType",false);
                        component.set("v.showPage",true);
                        component.set('v.setRT',component.get("v.Bill.RecordType.Name"));
                        console.log('getBillDetails v.clone~>'+component.get("v.clone"));
                        
                        if(!component.get("v.clone")){
                            component.set('v.uploadedFile',result.attachments); //Moin added this on 14th August 2023 if(!component.get("v.clone"))
                        	console.log('inhere');
                        }
                        
                        var billItems = result.billItems;
                        var dimensions = result.dimens;
                        var poliAcc = [];
                        if(billItems != null && billItems != undefined){
                            console.log('1');
                            if(dimensions != null && dimensions != undefined){
                                console.log('2');
                                for(var x in billItems){
                                    console.log('3');
                                    poliAcc = [];
                                    for(var y in dimensions){
                                        console.log('4');
                                        if(billItems[x].Id == dimensions[y].Bill_Line_Item__c)  {
                                            console.log('5');
                                            poliAcc.push(dimensions[y]);
                                        } 
                                    }
                                    console.log('poliAcc : ',JSON.stringify(poliAcc));
                                    billItems[x].Accounts = poliAcc;
                                    
                                }
                            }
                        }
                        component.set("v.billItems",billItems); 
                        
                    }
                    
                }
            }else{
                console.log('Error getBillDetailAndItems:',response.getError());
            }
            
            
        });
        $A.enqueueAction(action);
    },
    
    saveAtt : function(component,event,file,parentId){
        try{
            
            console.log('saveAtt called ');
            //var files = cmp.get("v.FileList");  
            //var file = files[0][0];
            //var filek = JSON.stringify(file);
            //var parentId = event.getSource().get("v.name");
            //if (files && files.length > 0) {
            var reader = new FileReader();
            console.log('saveAtt 1');
            reader.onloadend = function() {
                var contents = reader.result;
                var base64Mark = 'base64,';
                var dataStart = contents.indexOf(base64Mark) + base64Mark.length;
                var fileContents = contents.substring(dataStart);
                
                var action = component.get("c.uploadFile");
                console.log('saveAtt 2');
                action.setParams({
                    parent: parentId,
                    fileName: file.name,
                    base64Data: encodeURIComponent(fileContents),
                    contentType: file.type,
                    SyncSales: component.get("v.SyncSalesforce"),
                    SyncGDrive: component.get("v.SyncGDrive")
                });
                console.log('saveAtt 3');
                action.setCallback(this, function(response) {
                    console.log('response.getState() saveAtt: ',response.getState());
                    if(response.getState() === 'SUCCESS'){
                        console.log('saveAtt 4 : ',response.getReturnValue());
                    }else{
                        console.log('Error :',response.getError());
                    }
                });
                $A.enqueueAction(action); 
            }
            reader.readAsDataURL(file);
        }
        catch(e){
            console.log('catch Error :',e);
        }
        //}
    },
    
    //Moin added this 13th june 2023 SyncSales : true, SyncGDrive : false as the syntax was changed
    /*saveCloneAtt : function(component,event,file,parentId){
        try{ 
            console.log('saveCloneAtt called parentId~>'+parentId);
            
            var getchunk,filename,fileType, fileContents ;
            var objFileReader = new FileReader();
            // set onload function of FileReader object   
            objFileReader.onload = $A.getCallback(function() {
                fileContents = objFileReader.result;
                var base64 = 'base64,';
                var dataStart = fileContents.indexOf(base64) + base64.length;
                fileContents = fileContents.substring(dataStart);
                var startPosition = 0;
                var endPosition = Math.min(fileContents.length, startPosition + 750000);
                getchunk = fileContents.substring(startPosition, endPosition);
                
                var saveAction = component.get("c.save_attachment");
                
                saveAction.setParams({
                    "parentId": parentId,
                    "FileName": file.name, 
                    "FileType" :file.type,
                    "Base64":fileContents.substring(startPosition, endPosition)
                });
                saveAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){
                        console.log('inhere success saveCloneAtt');
                    }else{
                        var errors = response.getError();
                        console.log("server error in saveCloneAtt : ", JSON.stringify(errors));
                    }
                });
                $A.enqueueAction(saveAction);
                
                setTimeout($A.getCallback(function () {
                    console.log('setTimeout'); 
                }), 1000);   //dont remove setTimeout - for loading issue fix for upload files - Arshad
                
            });
            
            objFileReader.onerror = $A.getCallback(function() {
                console.log('objFileReader err~>'+reader.error);
            });
            
            objFileReader.readAsDataURL(file);
        }catch(err){
        } 
    },*/
    //Moin changed this method by commenting above one
    saveCloneAtt: function(component, event, file, parentId) {
        try {
            console.log('saveCloneAtt called parentId~>' + parentId);

            var objFileReader = new FileReader();

            // Set onload function of FileReader object
            objFileReader.onload = $A.getCallback(function () {
                var fileContents = objFileReader.result.split(',')[1]; // Remove 'base64,' from the result

                var saveAction = component.get("c.save_attachment");

                saveAction.setParams({
                    "parentId": parentId,
                    "FileName": file.name,
                    "FileType": file.type,
                    "Base64": fileContents
                });

                saveAction.setCallback(this, function (response) {
                    if (response.getState() === 'SUCCESS') {
                        console.log('in here success saveCloneAtt');
                    } else {
                        var errors = response.getError();
                        console.error("Server error in saveCloneAtt: ", JSON.stringify(errors));
                    }
                });

                $A.enqueueAction(saveAction);
            });

            objFileReader.onerror = $A.getCallback(function () {
                console.error('objFileReader error~>', objFileReader.error);
            });

            // Read the file as Data URL
            objFileReader.readAsDataURL(file);
        } catch (err) {
            console.error("Error in saveCloneAtt: ", err);
        }
    },

    createBill_PO_Lightning_button : function(component,event,helper){         
        var fetchpoliAction = component.get("c.fetch_Polis_bill");
        fetchpoliAction.setParams({"Id":component.get('v.Bill.Purchase_Order__c'),BillId:component.get('v.recordId')});
        fetchpoliAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var resultList = response.getReturnValue();
                if(resultList.length > 0){
                    var poliList = JSON.parse(resultList[1]);
                    if(!$A.util.isEmpty(poliList)){
                        return false;
                    }else{
                        return true;
                    }
                }
            }  
        });
        $A.enqueueAction(fetchpoliAction);
    },
    
    AnalyticalAccountingAccountCheck : function(component, event, helper) {
        var poli = component.get("v.billItems");
        var arshbool = true;
        for(var x in poli){
            var acc = [];
            acc = poli[x].Accounts;
            if(acc != undefined && acc != null && acc!=''){
                continue;
            }else{
                arshbool=false;
                break;
            }
        }
        return arshbool;
    },
    
    
    // the OCR part code by saqlain khan
    
    /* processInvoiceText: function(component, text) {
          // Extract invoice details using updated regex
        var invoiceNrMatch = text.match(/Invoice nr:\s*([A-Za-z0-9\-_]+)/i);
        var DateMatch = text.match(/Date:\s*([0-9]{2}\s[A-Za-z]{3}\s[0-9]{4})/i);
        var poNumberMatch = text.match(/PO nr:\s*([0-9]+)/i);
        var poDateMatch = text.match(/PO date:\s*([0-9]{2}\s[A-Za-z]{3}\s[0-9]{4})/i);
        var shipToMatch = text.match(/Address To\s+([\s\S]*?)\s+Tax Number:/i);
        var netorderamountMatch = text.match(/Net order amount €\s*([0-9.,]+)/i);
        var VatMatch = text.match(/VAT\( 20.00 %\) €\s*([0-9.,]+)/i);
        var grossamountMatch = text.match(/Gross amount €\s*([0-9.,]+)/i);
		var cashWithOrderMatch = text.match(/Cash with order €\s*-\s([0-9.,]+)/i);
        var amountPaidMatch = text.match(/Amount Paid €\s*([0-9.,]+)/i);
        var dueAmountMatch = text.match(/Due Amount €\s*([0-9.,]+)/i);

        // Set extracted details to component attributes
        component.set("v.invoiceNr", invoiceNrMatch ? invoiceNrMatch[1] : "");
        component.set("v.Date", DateMatch ? DateMatch[1] : "");
        component.set("v.poNumber", poNumberMatch ? poNumberMatch[1] : "");
        component.set("v.poDate", poDateMatch ? poDateMatch[1] : "");
        component.set("v.addressTo", shipToMatch ? shipToMatch[1].trim().replace(/\s{2,}/g, ', ') : "");
        component.set("v.netorderamount", netorderamountMatch ? netorderamountMatch[1] : "");
        component.set("v.vat", VatMatch ? VatMatch[1] : "");
        component.set("v.grossamount", grossamountMatch ? grossamountMatch[1] : "");
        component.set("v.cashWithOrder", cashWithOrderMatch ? cashWithOrderMatch[1] : "");
        component.set("v.amountPaid", amountPaidMatch ? amountPaidMatch[1] : "");
        component.set("v.dueAmount", dueAmountMatch ? dueAmountMatch[1] : "");

        // Extract line items
        var lineItems2 = [];
        var lineItemRegex2 = /(\d+)\s+([A-Za-z0-9_]+)\s+(\d+\.\d{2})\s+(\d+\.\d{2})/g;
        var match;
        while ((match = lineItemRegex2.exec(text)) !== null) {
            lineItems2.push({
                quantity2: match[1],
                description2: match[2].trim(),
                unitPrice2: match[3],
                totalPrice2: match[4]
            });
        }

        // Process second type of invoice details
        var invoiceNumberMatch = text.match(/Invoice No\.\s*([A-Za-z0-9\-_]+)/i);
        var invoiceDateMatch = text.match(/Invoice Date\s*(\d{4}-\d{2}-\d{2})/i);
        var billToMatch = text.match(/Bill To\s+([\s\S]*?)\s+Invoice No\./i);
        var shipToMatch2 = text.match(/Ship To\s+([\s\S]*?)\s+Invoice No\./i);
        var subTotalMatch = text.match(/Sub Total CAD\s+([0-9.,]+)/i);
        var salesTaxMatch = text.match(/Sales Tax CAD\s+([0-9.,]+)/i);
        var balanceDueMatch = text.match(/Balance Due CAD\s+([0-9.,]+)/i);

        component.set("v.invoiceNumber", invoiceNumberMatch ? invoiceNumberMatch[1] : "");
        component.set("v.invoiceDate", invoiceDateMatch ? invoiceDateMatch[1] : "");
        component.set("v.billTo", billToMatch ? billToMatch[1].trim().replace(/\s{2,}/g, ', ') : "");
        if (component.get("v.billTo") !== "") {
            var billingTo = component.get("v.billTo");
            var billingList = billingTo.split(',');
            if (billingList.length > 0) component.set("v.billTo", billingList[0]);
        }
        component.set("v.shipTo", shipToMatch2 ? shipToMatch2[1].trim().replace(/\s{2,}/g, ', ') : "");
        component.set("v.subTotal", subTotalMatch ? subTotalMatch[1] : "");
        component.set("v.salesTax", salesTaxMatch ? salesTaxMatch[1] : "");
        component.set("v.balanceDue", balanceDueMatch ? balanceDueMatch[1] : "");

           // Extract line items
        var lineItems = [];
        var lineItemRegex = /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+([0-9.]+)\s+([0-9.,]+)/g;
        var matche;
        while ((matche = lineItemRegex.exec(text)) !== null) {
            var quantity = matche[3];
            var description = matche[2].trim();    
            var unitPrice = matche[4];
            var amount = matche[5];
            var productName = description.split(/\s+/).slice(0, 3).join(' ');

            lineItems.push({
                quantity: quantity,
                productName: productName,
                description: description,
                unitPrice: unitPrice,
                amount: amount
            });
        }

        // Merge line items if present
        var finalLineItems = lineItems.length > 0 ? lineItems : lineItems2;
        component.set("v.lineItems", finalLineItems);

        component.set("v.tableType", lineItems.length > 0 ? 'Type1' : lineItems2.length > 0 ? 'Type2' : 'None');
        if (finalLineItems.length === 0) {
            console.error('No line items found');
        }
    },  */
    
    
    /*   Saqlain Khan's OCR code     */
    
       
    
 /*  processInvoiceText: function(component, text) {
        // Extract main invoice details using regex
        var billItemsData = {
            // InvoiceNr__c: text.match(/Invoice nr:\s*([A-Za-z0-9\-_]+)/i)?.[1] || "",
            // Date__c: text.match(/Date:\s*([0-9]{2}\s[A-Za-z]{3}\s[0-9]{4})/i)?.[1] || "",
            // PONumber__c: text.match(/PO nr:\s*([0-9]+)/i)?.[1] || "",
            // PODate__c: text.match(/PO date:\s*([0-9]{2}\s[A-Za-z]{3}\s[0-9]{4})/i)?.[1] || "",
            // AddressTo__c: text.match(/Address To\s+([\s\S]*?)\s+Tax Number:/i)?.[1]?.trim().replace(/\s{2,}/g, ', ') || "",
            // NetOrderAmount__c: text.match(/Net order amount €\s*([0-9.,]+)/i)?.[1] || "",
            // VAT__c: text.match(/VAT\( 20.00 %\) €\s*([0-9.,]+)/i)?.[1] || "",
            // GrossAmount__c: text.match(/Gross amount €\s*([0-9.,]+)/i)?.[1] || "",
            // CashWithOrder__c: text.match(/Cash with order €\s*-\s([0-9.,]+)/i)?.[1] || "",
            // AmountPaid__c: text.match(/Amount Paid €\s*([0-9.,]+)/i)?.[1] || "",
            // DueAmount__c: text.match(/Due Amount €\s*([0-9.,]+)/i)?.[1] || ""
        };

        // Alternative invoice details (if format differs)
        var alternativeDetails = {
            // InvoiceNumber__c: text.match(/Invoice No\.\s*([A-Za-z0-9\-_]+)/i)?.[1] || "",
            // InvoiceDate__c: text.match(/Invoice Date\s*(\d{4}-\d{2}-\d{2})/i)?.[1] || "",
            // BillTo__c: text.match(/Bill To\s+([\s\S]*?)\s+Invoice No\./i)?.[1]?.trim().replace(/\s{2,}/g, ', ') || "",
            // ShipTo__c: text.match(/Ship To\s+([\s\S]*?)\s+Invoice No\./i)?.[1]?.trim().replace(/\s{2,}/g, ', ') || "",
            // SubTotal__c: text.match(/Sub Total CAD\s+([0-9.,]+)/i)?.[1] || "",
			Tax_Amount__c: (text.match(/Sales Tax CAD\s+([0-9.,]+)/i) ? text.match(/Sales Tax CAD\s+([0-9.,]+)/i)[1] : "")
            // BalanceDue__c: text.match(/Balance Due CAD\s+([0-9.,]+)/i)?.[1] || ""
        };

    
       // Extract line items without table types
        var lineItems = [];
        var lineItemRegex = /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+([0-9.]+)\s+([0-9.,]+)/g;
        var match;

        while ((match = lineItemRegex.exec(text)) !== null) {
            if (match && match[3]) {
                // If match is valid, extract the data
                var productName = match[2].trim().split(/\s+/).slice(0, 3).join(' ');
                lineItems.push({
                    Quantity__c: match[3],
                    Product__c: productName,
                    Amount__c: match[4]
                });
            } else {
                console.warn("Line item match is incomplete or invalid:", match);
            }
        }

        // If no items found, use alternative line item format
        if (lineItems.length === 0) {
            var alternativeLineItems = [];
            var lineItemRegex2 = /(\d+)\s+([A-Za-z0-9_]+)\s+(\d+\.\d{2})\s+(\d+\.\d{2})/g;
            var match2;
            while ((match2 = lineItemRegex2.exec(text)) !== null) {
                if (match2 && match2[3]) {
                    alternativeLineItems.push({
                        Quantity__c: match2[1],
                        Product__c: match2[2].trim(),
                        Amount__c: match2[3]
                    });
                } else {
                    console.warn("Alternative line item match is incomplete or invalid:", match2);
                }
            }
            lineItems = alternativeLineItems;
        }

        // Return the extracted data to be set in the controller
        return {
            invoiceDetails: billItemsData,
            alternativeDetails: alternativeDetails,
            lineItems: lineItems
        };
    },
*/
    
  
/*    
    //this is working :)
 processInvoiceText: function (component, text) {
    var lineItems = [];
    var lineItemRegex = /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+([0-9.]+)\s+([0-9.,]+)/g;
    var match;

    while ((match = lineItemRegex.exec(text)) !== null) {
        if (match && match[3]) {
            // Extract the first 3 words for the product name
            var productName = match[2].trim().split(/\s+/).slice(0, 3).join(' ');

            // Push the extracted data into lineItems
            lineItems.push({
                Quantity__c: match[3], // Quantity
                Product__c: productName, // Product Name
                Amount__c: match[4] // Amount
            });
        } else {
            console.warn("Line item match is incomplete or invalid:", match);
        }
    }

    // Log extracted items
    if (lineItems.length > 0) {
        console.log("Extracted Line Items:");
        lineItems.forEach((item, index) => {
            console.log(`Item ${index + 1}:`, JSON.stringify(item, null, 2));
        });
    } else {
        console.warn("No matching line items found.");
    }

    return {
        lineItems: lineItems
    };
},
*/
    
    
    // this is working goood :) 
// processInvoiceText: function (component, text) {
//     var lineItems = [];

//     // Define regex patterns for possible invoice structures
//     var regexPatterns = [
//         /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+\$([0-9.]+)/g,   // Medical Invoice-like
//         /(\w+\s*\d*)\s+([\w\s]+)\s+(\d+)\s+(\d+)\s+\$(\d+)/g,  // Simple Invoice-like the 4 one
//         //([A-Za-z0-9\s\-]+)\s+(\d+)\s+\$([0-9.]+)\s+\$([0-9.]+)/g, // Sample Invoice-like
//         /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+([0-9.]+)\s+([0-9.,]+)/g // Salesforce-like
//     ];

//     var matchedPattern = null;

//     // Loop through patterns to process multiple templates
//     regexPatterns.forEach(function (pattern) {
//         var match;
//         while ((match = pattern.exec(text)) !== null) {
//             var productName = (match[2] || match[1] || "").trim().split(/\s+/).slice(0, 3).join(" ");
//             var quantity = match[3] || match[2] || "0";
//             var amount = match[4] || match[3] || "0";

//             lineItems.push({
//                 Product__c: productName,
//                 Quantity__c: quantity,
//                 Amount__c: amount
//             });
//         }
//     });

//     // Handle case where no line items are found
//     if (lineItems.length === 0) {
//         console.warn("No line items found in the uploaded invoice.");
//     } else {
//         console.log("Extracted Line Items:");
//         lineItems.forEach((item, index) => {
//             console.log(`Item ${index + 1}:`, JSON.stringify(item, null, 2));
//         });
//     }

//     // Safeguard to prevent window glitches in Salesforce
//     try {
//         return {
//             lineItems: lineItems
//         };
//     } catch (error) {
//         console.error("Error processing invoice text:", error);
//         // Preventing glitch fallback
//         $A.get("e.force:showToast").setParams({
//             title: "Error",
//             message: "An error occurred while processing the invoice. Please try again.",
//             type: "error"
//         }).fire();
//     }
// },

processInvoiceText: function (component, text) {
    var lineItems = [];

    // Pre-check to identify the invoice structure and decide which regex to use
    // We could look for specific keywords or structure
    var templateType = null;

    // Check for patterns unique to each template type
    if (text.includes("Product") && text.includes("Unit")) {
        // This seems like the "Simple-like" invoice template
        templateType = 'simple';
    } else if (text.includes("Northern")) {
        // This could be the "Salesforce-like" template
        templateType = 'salesforce';
    } else if (text.includes("Total")) {
        // This could match another template like "Medical-like"
        templateType = 'medical';
    } else {
        // Default case if none of the above match
        console.warn("Invoice format not recognized.");
        alert("Error: Invoice format not recognized. Please check the file and try again.");
    }

    // Now apply the correct regex based on templateType
    var regexPatterns = {
        simple: /(\w+\s*\d*)\s+([\w\s]+)\s+(\d+)\s+(\d+)\s+\$(\d+)/g, // Second regex (Simple-like)
        salesforce:/(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+([0-9.]+)\s+([0-9.,]+)/g	, // Salesforce-like
        medical: /(\d+)\s+([A-Za-z0-9\s\-\*\/]+)\s+(\d+)\s+\$([0-9.]+)/g // Medical-like
    };

    var matchedPattern = regexPatterns[templateType];

  if (matchedPattern) {
    // Apply the matched pattern
    var match;
    while ((match = matchedPattern.exec(text)) !== null) {
        // Extract and process the product name
        var productName = match[2]
            .trim() // Remove extra spaces
            .split(/\s+/) // Split into words by whitespace
            .slice(0, 3) // Take only the first 3 words
            .join(' '); // Join them back into a single string

        // Extract quantity and amount
        var quantity = match[3]; // Quantity
        var amount = match[4] || match[5]; // Amount (depending on pattern)
        
        // Store the extracted item
        lineItems.push({
            Product__c: productName,
            Quantity__c: quantity,
            Amount__c: amount
        });
    }
}
    // Handle case where no line items are found
    if (lineItems.length === 0) {
        console.warn("No valid line items extracted.");
    } else {
        console.log("Extracted Correct Items:");
        lineItems.forEach((item, index) => {
            console.log(`Item #${index + 1}:`, JSON.stringify(item, null, 2));
        });
    }

    return { lineItems: lineItems };
},



        
         processFile: function(file, component, helper) {
        if (file.type === 'application/pdf') {
            helper.processPDF(file, component, helper);
        } else if (file.type.startsWith('image/')) {
            helper.processImage(file, component, helper);
        } else {
            alert('Please select a PDF or image file.');
        }
    },
          processPDF: function(file, component, helper) {
        var reader = new FileReader();
        reader.onload = function() {
            try {
                var typedArray = new Uint8Array(reader.result);
                pdfjsLib.getDocument(typedArray).promise
                    .then(pdf => pdf.getPage(1))
                    .then(page => page.getTextContent())
                    .then(textContent => {
                        var extractedText = textContent.items.map(item => item.str).join(' ');
                        helper.handleExtractedText(component, extractedText, helper);
                    })
                    .catch(error => console.error("Error with PDF:", error));
            } catch (error) {
                console.error("Error processing PDF:", error);
            }
        };
        reader.readAsArrayBuffer(file);
    },
        
  
               
                    
                    
                    
   getProductIdByName: function(component, productNames) {
    return new Promise((resolve, reject) => {
        var action = component.get("c.getProductIdsByNames");
        action.setParams({ productNames: productNames });

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                resolve(response.getReturnValue()); // Resolve with list of IDs or names
            } else {
                console.error("Error fetching product IDs:", response.getError());
                reject("Failed to fetch product IDs");
            }
        });
        $A.enqueueAction(action);
    });
},

handleExtractedText: function(component, extractedText, helper) {
    var invoiceData = helper.processInvoiceText(component, extractedText);
    var productNames = invoiceData.lineItems.map(lineItem => lineItem.Product__c);

    console.log('Extracted Product Names:', productNames);

    if (productNames.length > 0) {
        helper.getProductIdByName(component, productNames)
            .then(productIds => {
                console.log("Product IDs or Names:", productIds);
                component.set("v.productList", productIds);
                helper.populateBillItems(component, invoiceData, productIds);
            })
            .catch(error => console.error("Error finding product IDs:", error));
    }
},

populateBillItems: function (component, invoiceData) {
    var billList = component.get("v.billItems") || [];
    var productIdMap = new Map();
    console.log('productIds-->' + JSON.stringify(component.get("v.productList")));
    var productIds = component.get("v.productList") || [];
    
    // Populate productIdMap
    productIds.forEach(item => {
        console.log('name-->' + item.Name);
        productIdMap.set(item.Name, item.Id);
    });

    // Process invoice line items
    invoiceData.lineItems.forEach(lineItem => {
        var isProductId = false;
        var productIdOrName = lineItem.Product__c;
        console.log('productIdMap-->' + JSON.stringify(productIdMap));
        console.log('lineItem-->' + JSON.stringify(lineItem));

        if (productIdMap.has(productIdOrName)) {
            isProductId = true;
            productIdOrName = productIdMap.get(productIdOrName); // Get the product ID
        }

        // Push the new bill line item into the list
        billList.push({
sObjectType: 'Bill_Line_Item__c',
            Accounts: [],
            Category: '',
            AccAccount: '',
            Name: lineItem.Product__c,
            Quantity__c: lineItem.Quantity__c || "",
            Product__c:isProductId? productIdOrName :'',// Set ID if found
            Amount__c: lineItem.Amount__c || ""
             });

        if (!isProductId) {
            console.warn("Product not found for: " + lineItem.Product__c);
        }
    });

    // // Force UI refresh
    // $A.getCallback(() => {
        component.set("v.billItems", []); // Clear first to ensure re-render
        component.set("v.billItems", billList); // Reassign to trigger re-render
        //component.set("v.isDataPopulated", true); // Set true after populating data
    // })();

    console.log("billItems:", JSON.stringify(billList));
},


clearBillItems: function (component) {
    let billItems = component.get("v.billItems");
    billItems.splice(0, billItems.length); // Removes all items from billItems
    component.set("v.billItems", billItems);
    console.log("Existing bill items cleared.");
},

     
});
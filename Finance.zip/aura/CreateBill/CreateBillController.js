({
    doInit : function(component, event, helper){  
        helper.fetchcurrency(component, event, helper);
        if(component.get('v.recordId') !=undefined && component.get('v.recordId') !=null && component.get('v.recordId') != ''){
            helper.getBillDetails(component, event, helper);
        }
        var isAttRequired=$A.get("$Label.c.isCreateBillAttRequired");
        if(isAttRequired ==='true'){                    
            component.set("v.isAttRequired",true);
        }else{
            component.set("v.isAttRequired",false);
        }
        if(component.get("v.isMultiPOBill")){
            $A.enqueueAction(component.get("c.fetchMultiPoli"));
        }
        if(component.get('v.pId') !=undefined && component.get('v.pId') !=null && component.get('v.pId') != ''){
            
            var pId=component.get('v.pId');
            component.set('v.Bill.Purchase_Order__c',pId);
            $A.enqueueAction(component.get("c.fetchPoli"));
            
            var isMulticurrency = component.get('v.isMultiCurrency');
            if(isMulticurrency == true) { 
                helper.fetchPOCurrncy(component,event,helper); 
            }
        }
        if(component.get("v.ProjId") != null && component.get("v.ProjId") != undefined && component.get("v.ProjId") != ""){
            component.set("v.Bill.Project__c", component.get("v.ProjId"));
        }
        if(component.get('v.vId') !=undefined && component.get('v.vId') !=null && component.get('v.vId') != ''){
            component.set('v.Bill.Vendor__c',component.get("v.vId"));
            $A.enqueueAction(component.get("c.fetchVendorDetails"));
        }
        var billPo=component.get("v.Bill.Purchase_Order__c");
        //alert(component.get("v.Bill.Purchase_Order__c"));
        if(billPo!=undefined && billPo!=null && billPo!=''){
            
            var isMulticurrencyEnabled = component.get('v.isMultiCurrency');
            if(isMulticurrencyEnabled == true) { 
                helper.fetchPOCurrncy(component,event,helper); 
            }
        }
        //var org=JSON.stringify(component.get('v.pId').Organisation__c);
        //component.set('v.Bill.Organisation__c',org);
        let Itemtype = component.get("c.getpicklist"); 
        Itemtype.setParams({"sObject_Type":'Bill_Line_Item__c',"Field":'Item_Type__c'});
        Itemtype.setCallback(this,function(response){
            if(component.get('v.recordId') == undefined || component.get('v.recordId') == null || component.get('v.recordId') == ''){
                var po=component.get('v.Bill.Purchase_Order__c');
                if(po!=undefined && po!=null && po!=''){
                    component.set('v.setRT','PO Bill');
                    component.set('v.ShowBillType',false);
                    component.set('v.showPage',true);
                }else{
                    if(component.get("v.isMultiPOBill")==false){
                        component.set('v.ShowBillType',true);
                        component.set('v.showPage',false);
                    }
                }  
            }
            component.set("v.Itemtype",response.getReturnValue());            
        });
        $A.enqueueAction(Itemtype);
        let Expensetype = component.get("c.getpicklist");
        Expensetype.setParams({"sObject_Type":'Bill_Line_Item__c',"Field":'Expense_Type__c'});
        Expensetype.setCallback(this,function(response){
            component.set("v.Expensetype",response.getReturnValue()); 
            //component.set("v.Bill.TDS_Amount__c",0);
            // component.set("v.Bill.Discount_Amount__c",0);
            //component.set("v.Bill.VAT_TAX_Amount__c",0);    
            //var venId = component.get('v.Bill.Vendor__r.Id');    
            //component.set('v.Bill.Vendor__c',venId);
        });
        $A.enqueueAction(Expensetype);
        
        try{
            let BillFC = component.get("c.getBillFC");
            BillFC.setCallback(this,function(response){
                console.log('state getBillFC~>'+response.getState());
                if(response.getState() === 'SUCCESS'){
                    console.log('getBillFC resp~>',response.getReturnValue());
                    component.set("v.showAllocations", response.getReturnValue().AllocationAccess);
                    component.set("v.SyncSalesforce", response.getReturnValue().SalesFile);
                    component.set("v.isGDrive", response.getReturnValue().DriveFile);
                    component.set("v.SyncGDrive", response.getReturnValue().DriveFile);
                    component.set("v.standOrder", response.getReturnValue().stdOrder);
                    component.set("v.displayName", response.getReturnValue().displayName);
                    component.set("v.showVenName", response.getReturnValue().showVenCode);
                    component.set("v.showProdCode", response.getReturnValue().showProdCode);
                    component.set("v.ProjectAccess", response.getReturnValue().ProjectOnBillScreen);
                    component.set("v.DepartmentAccess", response.getReturnValue().DepartmentOnBillScreen);
                    
                }else{
                    console.log('Error:',response.getError());
                }
            });
            $A.enqueueAction(BillFC);
        }catch(e){ console.log('ee',e); }
        
         // Fetch the "Read Bill OCR" checkbox value
    const action = component.get("c.getReadBillOCRState");
    action.setCallback(this, function (response) {
        if (response.getState() === "SUCCESS") {
            component.set("v.isReadBillChecked", response.getReturnValue());
        } else {
            console.error("Failed to fetch Read Bill OCR state.");
        }
    });
    $A.enqueueAction(action);
        
        
        helper.FieldAccess(component, event);
        /*var files = [];
        files = component.get("v.FileList");
        if(files!=null && files!=''){
            $A.enqueueAction(component.get("c.handleFilesChange"));
        }*/
    },
    
    fetch_vendor_details: function(component, event, helper){
        if(component.get('v.recordId') == null || component.get('v.recordId') == '' || component.get('v.recordId') == undefined){
            var action = component.get('c.fetchvendordetails');
            action.setParams({
                VendorId : component.get("v.Bill.Vendor__c"),
                bill_number : component.get("v.Bill.Vendor_Bill_Number__c")
            });    
            action.setCallback(this, function(response){
                var state = response.getState();
                if( state === "SUCCESS" ){
                    if(response.getReturnValue()==true)
                        alert($A.get('$Label.c.Bill_with_this_Vendor_Bill_Number_already_exist'));
                }
            });
            $A.enqueueAction(action);
        }
    },
    
   updateTotalDiscount : function(c, e, h){
        console.log('updateTotalDiscount');
        var items=c.get('v.billItems');
        if($A.util.isUndefined(items.length)){
            var dis=items.Discount__c;
            c.set("v.Bill.Discount_Amount__c",dis);
        }else{
            var dis=0;
            for(var x in items){
                if(items[x].Discount__c!=undefined && items[x].Discount__c!=''){
                    var discount = items[x].Discount__c;
                    dis=dis+discount*1;   
                }
                
            }
            c.set("v.Bill.Discount_Amount__c",dis);
        }
    }, 
    
    updateTotalTax : function(c, e, h){
        try{
            console.log('updateTotalTax called');
            var items=c.get('v.billItems');
            console.log('items~>',JSON.stringify(items));
            
            if(items.Tax_Rate__c==undefined)items.Tax_Rate__c=0;
            if(items.Other_Tax_Rate__c==undefined)items.Other_Tax_Rate__c=0;
            if(items.Quantity__c==undefined)items.Quantity__c=0;
            if(items.Amount__c==undefined)items.Amount__c=0;
            console.log('updateTotalTax set1 items~>',JSON.stringify(items));
            
            //Moin commented this on 13th september 2023
           // /*for(var x in items){
              //  if(items[x].Amount__c==undefined)items[x].Amount__c=0;
                //if(items[x].Other_Tax_Rate__c==undefined)items[x].Other_Tax_Rate__c=0;
               // if(items[x].Tax_Rate__c==undefined)items[x].Tax_Rate__c=0;
                //if(items[x].Quantity__c==undefined)items[x].Quantity__c=0;
            //}
            
            //Moin added this
            //
            //for (var x in items) {
              //  items[x].Amount__c = items[x].Amount__c || 0;
               // items[x].Other_Tax_Rate__c = items[x].Other_Tax_Rate__c || 0;
                //items[x].Tax_Rate__c = items[x].Tax_Rate__c || 0;
                //items[x].Quantity__c = items[x].Quantity__c || 0;
         //   }
            
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.Amount__c = item.Amount__c || 0;
                item.Other_Tax_Rate__c = item.Other_Tax_Rate__c || 0;
                item.Tax_Rate__c = item.Tax_Rate__c || 0;
                item.Quantity__c = item.Quantity__c || 0;
                item.Tax_Amount__c = item.Tax_Amount__c || 0;
                item.Total_Amount__c = item.Total_Amount__c || 0;
            }
            console.log('updateTotalTax set2 items~>',JSON.stringify(items));
            if($A.util.isUndefined(items.length)){
                var tax=((items.Total_Amount__c)/100)*items.Tax_Rate__c;
                var OTtax=(items.Amount__c/100)*items.Other_Tax_Rate__c;
                var totalTax=(tax+OTtax)*items.Quantity__c;
                c.set("v.Bill.VAT_TAX_Amount__c",totalTax);
                console.log('updateTotalTax set3 items~>',JSON.stringify(items));
            }else{
                var totaltax=0;
                var tax = 0;
                var OTtax = 0;
                for (var i = 0; i < items.length; i++) {
                	var item = items[i];
                    item.Amount__c = item.Amount__c || 0;
                    item.Tax_Amount__c = item.Tax_Amount__c || 0;
                    item.Other_Tax_Rate__c = item.Other_Tax_Rate__c || 0;
                    tax = parseFloat(item.Tax_Amount__c);
                    OTtax = parseFloat((item.Amount__c/100)) * parseFloat(item.Other_Tax_Rate__c); // Shaguftha M - 15_04_24 added parseFloat on the other tax rate as it was add the other tax rate as string for example if tax amount is 2 and other as 0 then as 20 so added parsefloat
                    totaltax += parseFloat(tax+OTtax);
                //for(var x in items){
                    //Moin commented this 0n 13th september 2023
                    //if($A.util.isEmpty(items[x].Tax_Amount__c) || $A.util.isUndefinedOrNull(items[x].Tax_Amount__c)) items[x].Tax_Amount__c=0;
                    //if($A.util.isEmpty(items[x].Amount__c) || $A.util.isUndefinedOrNull(items[x].Amount__c)) items[x].Amount__c=0;
                    //if($A.util.isEmpty(items[x].Other_Tax_Rate__c) || $A.util.isUndefinedOrNull(items[x].Other_Tax_Rate__c)) items[x].Other_Tax_Rate__c=0;
                    //tax = items[x].Tax_Amount__c;
                    //OTtax = parseFloat((items[x].Amount__c/100) * items[x].Other_Tax_Rate__c);
                    //totaltax += parseFloat(tax+OTtax);
                }
                console.log('totaltax~>'+totaltax);
                //if(totaltax >= 0 ) totaltax = totaltax.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                c.set("v.Bill.VAT_TAX_Amount__c",totaltax);
            }
        }catch(e){ console.log('updateTotalTax err '+e); }
    },
    
    updateTotalPrice: function(c, e, h) {
        try{
            console.log('updateTotalPrice called');
            var items=c.get('v.billItems');
            if($A.util.isUndefined(items.length)){
                var amt=items.Quantity__c * items.Amount__c;
                c.set("v.Bill.Amount__c",amt);//amt.toFixed($A.get("$Label.c.DecimalPlacestoFixed"))
            }else{ 
                var amt=0;
                for (var i = 0; i < items.length; i++) {
                    //Moin commented on 13th september
                    //if($A.util.isEmpty(items[x].Amount__c) || $A.util.isUndefinedOrNull(items[x].Amount__c)) items[x].Amount__c=0;
                    //if($A.util.isEmpty(items[x].Quantity__c) || $A.util.isUndefinedOrNull(items[x].Quantity__c)) items[x].Quantity__c=0;
                    var item = items[i];
                    item.Amount__c = item.Amount__c || 0;
                    item.Quantity__c = item.Quantity__c || 0;
                    amt += parseFloat(item.Quantity__c * item.Amount__c);
                }
                //if(amt >= 0) amt = amt.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                c.set("v.Bill.Amount__c",amt);
            }
        }catch(e){ console.log('updateTotalPrice err '+e); }
    },
    //added changes on this method on 13th sept 2023 for name or id setting.
    updateProduct: function(c, e, h) {
        try {
            console.log('updateProduct called');
            
            // Get the new value of the Product attribute
            var productName = c.get('v.Product');
            
            // Check if the product name is valid or assign a default value
            if ($A.util.isEmpty(productName)) {
                console.log('Product name is empty or undefined. Assigning default value.');
                productName = 'Default Product Name';
                c.set('v.Product', productName);
            }
            
            console.log('Updated Product Name:', productName);
    
            // Perform additional logic if necessary, e.g., updating related components or attributes
            // Example:
            // c.set("v.someOtherAttribute", "Updated based on Product change");
    
        } catch (err) {
            console.error('Error in updateProduct:', err);
        }
    },

    updateProductField: function (component, event, helper) {
    try {
        console.log("updateProductField called");
        var items = c.get("v.billItems"); // Retrieve the bill items
        var productId = c.get("v.Bill.Product__c"); // Get the Product ID from the Bill object

        if ($A.util.isUndefinedOrNull(items) || items.length === 0) {
            console.warn("No bill items found to update.");
            return;
        }

        // Loop through each item and update the Product field
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            item.Product__c = productId; // Update the `Product__c` field with productId

            // Log for debugging
            console.log(`Updated Item ${i + 1}:`, JSON.stringify(item));
        }

        // Update the billItems attribute with the modified list
        c.set("v.billItems", items);
        console.log("Product field updated successfully for all items.");
    } catch (e) {
        console.error("Error in updateProductField:", e);
    }
},  
    
    
   /* updateTotalDiscount: function (c, e, h) {
        console.log('updateTotalDiscount');
        var items = c.get('v.billItems');
        if ($A.util.isUndefined(items.length)) {
            var dis = items.Discount__c || 0;
            c.set("v.Bill.Discount_Amount__c", dis);
        } else {
            var dis = 0;
            for (var x in items) {
                if (
                    !$A.util.isEmpty(items[x].Discount__c) &&
                    !$A.util.isUndefinedOrNull(items[x].Discount__c)
                ) {
                    var discount = items[x].Discount__c;
                    dis += discount * 1;
                }
            }
            c.set("v.Bill.Discount_Amount__c", dis);
        }
    },

    updateTotalTax: function (c, e, h) {
        try {
            console.log('updateTotalTax called');
            var items = c.get('v.billItems');
            if (!items || items.length === 0) {
                console.warn('No bill items to process.');
                return;
            }

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.Amount__c = item.Amount__c || 0;
                item.Other_Tax_Rate__c = item.Other_Tax_Rate__c || 0;
                item.Tax_Rate__c = item.Tax_Rate__c || 0;
                item.Quantity__c = item.Quantity__c || 0;
                item.Tax_Amount__c = item.Tax_Amount__c || 0;

                // Check for Product__r and Product__r.Name, fallback to default value
                if (!$A.util.isEmpty(item.Product__c)) {
                    // Product__c is already populated
                } else if (item.Product__r && !$A.util.isEmpty(item.Product__r.Name)) {
                    item.Product__c = item.Product__r.Name;
                } else {
                    item.Product__c = "Default Product";
                }
            }

            var totaltax = 0;
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                var tax = parseFloat(item.Tax_Amount__c || 0);
                var OTtax = parseFloat((item.Amount__c / 100) * (item.Other_Tax_Rate__c || 0));
                totaltax += parseFloat(tax + OTtax);
            }
            c.set("v.Bill.VAT_TAX_Amount__c", totaltax);
        } catch (e) {
            console.error('Error in updateTotalTax:', e);
        }
    },

    updateTotalPrice: function (c, e, h) {
        try {
            console.log('updateTotalPrice called');
            var items = c.get('v.billItems');
            if ($A.util.isUndefined(items.length)) {
                var amt = items.Quantity__c * items.Amount__c;
                c.set("v.Bill.Amount__c", amt);
            } else {
                var amt = 0;
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    item.Amount__c = item.Amount__c || 0;
                    item.Quantity__c = item.Quantity__c || 0;

                    // Check for Product__r and Product__r.Name, fallback to default value
                    if (!$A.util.isEmpty(item.Product__c)) {
                        // Product__c is already populated
                    } else if (item.Product__r && !$A.util.isEmpty(item.Product__r.Name)) {
                        item.Product__c = item.Product__r.Name;
                    } else {
                        item.Product__c = "Default Product";
                    }

                    amt += item.Quantity__c * item.Amount__c;
                }
                c.set("v.Bill.Amount__c", amt);
            }
        } catch (e) {
            console.error('Error in updateTotalPrice:', e);
        }
    },
    
    updateProductField: function (c, e, h) {
        try {
            console.log("updateProductField called");
            var items = c.get("v.billItems"); // Retrieve the bill items
            var productId = c.get("v.Product"); // Get the Product field from the component

            if ($A.util.isUndefinedOrNull(items) || items.length === 0) {
                console.warn("No bill items found to update.");
                return;
            }

            // Loop through each item and update the Product field
            for (var i = 0; i < items.length; i++) {
                var item = items[i];

                // Ensure Product field is not blank
                if (!$A.util.isEmpty(productId)) {
                    item.Product__c = productId; // Update the `Product__c` field with productId
                } else if (item.Product__r && !$A.util.isEmpty(item.Product__r.Name)) {
                    item.Product__c = item.Product__r.Name; // Fall back to the product's name
                } else {
                    item.Product__c = "Default Product"; // Fallback to default product name
                }

                // Log for debugging
                console.log(`Updated Item ${i + 1}:`, JSON.stringify(item));
            }

            // Update the billItems attribute with the modified list
            c.set("v.billItems", items);
            console.log("Product field updated successfully for all items.");
        } catch (e) {
            console.error("Error in updateProductField:", e);
        }
    }, */
    
    handleCheckSalesforce : function(component, event, helper) {
        var isChecked = event.getSource().get("v.checked");
        component.set("v.SyncSalesforce", isChecked);
    },
    
    handleCheckGDrive : function(component, event, helper) {
        var isChecked = event.getSource().get("v.checked");
        component.set("v.SyncGDrive", isChecked);
    },
    
    saveBill : function(component, event, helper) {
        try{
            component.set("v.showMmainSpin",true);
            console.log('Save Bill button called before if');
            if(component.get('v.setRT')=='PO Bill' && (component.get('v.recordId') ==undefined || component.get('v.recordId')==null || component.get('v.recordId') == '')){
                var poliids = [];
                if(component.get("v.Bill.Purchase_Order__c") != undefined && component.get("v.Bill.Purchase_Order__c") != null && component.get("v.Bill.Purchase_Order__c") != ''){
                    poliids.push(component.get("v.Bill.Purchase_Order__c"));
                }
                console.log('Save Bill button called before line 443');
                if(component.get("v.isMultiPOBill")){
                    poliids = component.get("v.POIdsList");
                    console.log('Save Bill button -- called inside the if statement');

                    console.log('POIdsList:', poliids);
                }
                console.log('Save Bill button called before state responce');

                var fetchpoliAction = component.get("c.fetch_Polis_bill");
                fetchpoliAction.setParams({"poId":poliids,BillId:component.get('v.recordId')});
                fetchpoliAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){
                        //component.set("v.showMmainSpin",false);
                        console.log('Save Bill button called before state responce');
                        var resultList = response.getReturnValue();
                        if(resultList.length > 0 ){//|| component.get("v.isMultiPOBill")
                            var poliList = [];
                            //if(!component.get("v.isMultiPOBill")) poliList = JSON.parse(resultList[1]);
                            poliList = JSON.parse(resultList[1]);
                            console.log('Save Bill button called before 456 line');
                            if(!$A.util.isEmpty(poliList)){// || component.get("v.isMultiPOBill")
                                console.log('saveBill called');
                                
                                var billList = component.get("v.billItems");
                                var Billobj = component.get("v.Bill");
                                
                                //alert('Bill=>'+JSON.stringify(component.get("v.Bill")));
                                Billobj.Vendor_Contact__r = null;
                                Billobj.Vendor_Address__r = null;
                                Billobj.Purchase_Order__r = null;
                                Billobj.Posted__c = component.get('v.setBillPost');
                                if(Billobj.Total_Amount__c == undefined || Billobj.Total_Amount__c == null || Billobj.Total_Amount__c == '') Billobj.Total_Amount__c = 0.00;
                                
                                var totalAmount=parseFloat(Billobj.Amount__c);
                                var advAmount=component.get('v.advPayment');
                                console.log('Save Bill button called before helper');
                                if(component.get('v.setRT')=='Advance to vendor'){
                                    var amount1=component.find('amount1').get('v.value');
                                    if(parseFloat(amount1) <= 0 || amount1 ==''){
                                        

                                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_enter_a_valid_amount'));
                                        console.log('Save Bill button called line 477');

                                        component.set("v.showMmainSpin",false);

                                        return;
                                    }            
                                    /*if(amount1 == (totalAmount-advAmount)){
                    helper.showToast('Error!','error','You are creating bill for full amount, Please create a purchase order bill');
                    return;
                }*/
                                    if(amount1 > (totalAmount-advAmount)){
                                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Can_not_enter_more_than_todal_due_amount'));
                                        component.set("v.showMmainSpin",false);
                                        return;
                                    }
                                    Billobj.Amount__c=amount1;
                                }else{
                                    Billobj.Amount__c-=advAmount;
                                }
                                //component.set("v.showMmainSpin",false);
                                component.NOerrors =  true;
                                helper.validation_Check(component,event);
                                
                                var isErrorsAA = helper.AnalyticalAccountCheck(component, event, helper); 
                                var isErrorsAACOA = helper.AnalyticalAccountCoaCheck(component, event, helper); 
                                
                                if(component.NOerrors){
                                    var showError=false;
                                    
                                    if(billList.length>0){
                                        for(var a = 0; a < billList.length; a++){//Moin added this on 13th september
                                            if(billList[a].Product__r != null && billList[a].Product__r != undefined && billList[a].Product__r != '') delete billList[a].Product__r;
                                            //for(var a in billList ){
                                            if(component.get("v.isMultiCurrency")) billList[a].CurrencyIsoCode = component.get("v.Bill.CurrencyIsoCode");
                                            if(component.get("v.fromPortal") == false){ //change arshad
                                                if(billList[a].Chart_Of_Account__c=='' || billList[a].Chart_Of_Account__c==null || billList[a].Chart_Of_Account__c==undefined){
                                                    showError=true;
                                                    var po=component.get('v.Bill.Purchase_Order__c');
                                                    if(po!=null && po!='' && po!=undefined) helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_Select_the_inventory_account_for_all_line_items'));
                                                    else helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_Select_the_expense_account_for_all_line_items'));
                                                }
                                            }
                                        }
                                    }
                                    component.set("v.showMmainSpin",false);
                                    if($A.util.isUndefinedOrNull(component.get("v.Bill.Vendor_Bill_Number__c"))){
                                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_Enter_the_Vendor_Bill_Number'));
                                        component.set("v.showMmainSpin",false);
                                        return;
                                    }
                                    
                                    //Moin removed and added below code if(component.get("v.recordId") != null && component.get("v.recordId") ==  undefined &&  component.get("v.recordId") ==  ''){
                                    if(component.get("v.recordId") != null && component.get("v.recordId") !=  undefined &&  component.get("v.recordId") !=  ''){
                                        if(component.get("v.isAttRequired") && (component.get("v.uploadedFile") == null || component.get("v.uploadedFile").length == 0) && component.get('v.setRT')!='Advance to vendor'){
                                            var fillList11=component.get("v.fillList");
                                            if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                                                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                                                component.set("v.showMmainSpin",false);
                                                return;
                                            }
                                        }
                                        //Moin commented this
                                        /* 
                   else{
                       var fillList11=component.get("v.fillList");
                       if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                           helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                           return;
                       }
                   }*/
                                    }
                                    else{
                                        var fillList11=component.get("v.fillList");
                                        if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                                            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                                            component.set("v.showMmainSpin",false);
                                            return;
                                        }
                                    }
                                    
                                    
                                    if(!component.get("v.SyncSalesforce") && !component.get("v.SyncGDrive") && component.get("v.isGDrive")){                
                                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error','Please Select Salesforce or Google Drive');
                                        component.set("v.showMmainSpin",false);
                                        return;
                                    }
                                    
                                    if(component.get("v.showAllocations")){
                                        var accCheck =true;
                                        accCheck = helper.AnalyticalAccountingAccountCheck(component, event, helper);
                                        if(!accCheck){
                                            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.AddAnalyticalAccount'));
                                            return;
                                        }
                                    }
                                    if(billList.length > 0 && !(showError) ){
                                        if(!isErrorsAA &&!isErrorsAACOA){
                                            var dimensionList = [];
                                            try{
                                                
                                                //for(var x in billList){
                                                for(var x = 0; x < billList.length; x++){//Moin added this on 13th september
                                                    if(billList[x].Accounts != undefined && billList[x].Accounts != null){
                                                        if(billList[x].Accounts.length > 0){
                                                            for(var y in billList[x].Accounts){
                                                                if(billList[x].Accounts[y].Sort_Order__c != undefined && billList[x].Accounts[y].Sort_Order__c != null){
                                                                    console.log('before poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                                                    billList[x].Accounts[y].Sort_Order__c = parseInt(parseInt(x)+1);
                                                                    console.log('after poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                                                }
                                                            }
                                                            dimensionList.push(billList[x].Accounts);
                                                        }
                                                    }
                                                }
                                                console.log('dimensionList : ',dimensionList);
                                                
                                                for(var x in billList){
                                                    if(billList[x].Accounts != undefined && billList[x].Accounts != null) billList[x].Accounts = [];
                                                    billList[x].projBudget = '';
                                                    billList[x].projCommittedBudget = '';
                                                    billList[x].projConsumedBudget = '';
                                                    billList[x].projRemainingBudget = '';
                                                }
                                            }catch(e){
                                                console.log('arshad err,',e);
                                            }
                                            
                                            component.set("v.showMmainSpin",true);
                                            //Moin commented and added this on 31st july 2023
                                            var saveAction = component.get("c.save_UpdatedBill");
                                            //var saveAction = component.get("c.save_Bill");
                                            console.log('JSON.stringify(Billobj)~>'+JSON.stringify(Billobj));
                                            console.log('JSON.stringify(billList)~>'+JSON.stringify(billList));
                                            
                                            let jsonBill  = JSON.stringify(Billobj);
                                            let jsonBillItems = JSON.stringify(billList);
                                            var RTName;
                                            if(component.get('v.setRT')=='PO Bill')RTName='PO_Bill';
                                            if(component.get('v.setRT')=='Expense Bill')RTName='Expense_Bill';
                                            if(component.get('v.setRT')=='Advance to vendor')RTName='Advance_to_vendor';
                                            
                                            console.log('saveBill v.clone~>'+component.get("v.clone"));
                                            
                                            saveAction.setParams({"Bill": jsonBill, "BillItems" :jsonBillItems,RTName:RTName,clone:component.get("v.clone")});
                                            saveAction.setCallback(this,function(response){
                                                try{
                                                    if(response.getState() === 'SUCCESS'){ 
                                                        console.log('success here 1 resp~>',JSON.stringify(response.getReturnValue()));
                                                        var result = response.getReturnValue();
                                                        var bilobj = result['bill']; 
                                                        component.set("v.BillId",bilobj.Id);
                                                        
                                                        if(component.get("v.clone")){
                                                            component.set("v.recordId", bilobj.Id);//Moin added this on 14th august 2023 if(component.get("v.clone")) 
                                                            console.log('inhere1 clone true saveBill');
                                                        }
                                                        
                                                        console.log('here 1.1 : ',bilobj.Id);
                                                        console.log('setRT : ',component.get('v.setRT'));
                                                        console.log('fillList11 :',fillList11);
                                                        
                                                        if(!$A.util.isUndefinedOrNull(result['error'])) {
                                                            console.log('here 5 ');
                                                            helper.showToast('Error!','error',result['error']);
                                                            component.set("v.showMmainSpin",false);
                                                            return ;
                                                        }
                                                        
                                                        //added by arshad 23 Aug 2023
                                                        var hasAttachmentsToUpload = false;
                                                        
                                                        if(component.get('v.setRT')=='PO Bill' || component.get('v.setRT')=='Expense Bill' || component.get('v.setRT')=='Advance to vendor'){
                                                            if(component.find("fileId").get("v.files")!=null){
                                                                console.log('fileId get v.files not null');
                                                                if (component.find("fileId").get("v.files").length > 0 && component.find("fileId").get("v.files") != undefined && fillList11.length > 0 && fillList11 != undefined) {   
                                                                    console.log('fileId get v.files length > 0');
                                                                    hasAttachmentsToUpload = true;
                                                                    var fileInput = component.get("v.FileList");
                                                                    for(var i=0; i<fileInput.length; i++){
                                                                        if(!component.get("v.clone")) helper.saveAtt(component,event,fileInput[i],bilobj.Id);
                                                                        else helper.saveCloneAtt(component,event,fileInput[i],bilobj.Id);
                                                                    } 
                                                                }else console.log('not going fileId get v.files length 0');
                                                            }else console.log('not going fileId get v.files null');
                                                            
                                                            console.log('Attach : ',component.get("v.Attach"));
                                                            if(component.get("v.Attach")!=null){
                                                                console.log('save_attachment2 here 3 ');
                                                                var Billobj = component.get("v.BillId");
                                                                var action=component.get("c.save_attachment2");
                                                                action.setParams({"parentId": Billobj,"Pid":component.get("v.Bill.Purchase_Order__c"), });
                                                                action.setCallback(this,function(response){
                                                                    if(response.getState() === 'SUCCESS'){
                                                                        console.log('save_attachment2 here 4 success');
                                                                    }else{
                                                                        var errors = response.getError();
                                                                        console.log("server error in save_attachment2 : ", JSON.stringify(errors));
                                                                    }
                                                                });
                                                                $A.enqueueAction(action);
                                                            }
                                                            //return;
                                                        }
                                                        
                                                        console.log('dimensionList.length : ',dimensionList.length);
                                                        if(dimensionList.length > 0){
                                                            try{
                                                                var action2=component.get("c.createDimensionsList");
                                                                action2.setParams({'dimelist':JSON.stringify(dimensionList), 'BillId':bilobj.Id});
                                                                action2.setCallback(this,function(response){
                                                                    if(response.getState() === "SUCCESS"){
                                                                        console.log('createDimensionsList in success');
                                                                        //component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
                                                                        //component.set("v.currencyList",response.getReturnValue().currencyList);
                                                                    }else{
                                                                        var errors = response.getError();
                                                                        console.log("server error in dimelist : ", JSON.stringify(errors));
                                                                    } 
                                                                });
                                                                $A.enqueueAction(action2);
                                                            }catch(e){
                                                                console.log('arshad err 2,',e);
                                                            }
                                                        }
                                                        
                                                        // return;
                                                        if(component.get("v.recordId") != null && component.get("v.recordId") !=  undefined && component.get("v.recordId") !=  '' && !component.get("v.clone")){
                                                            console.log('inhere if going to record page');
                                                            var RecId = component.get("v.recordId");
                                                            var RecUrl = "/lightning/r/Bill__c/" + RecId + "/view";
                                                            helper.showToast($A.get('$Label.c.Success'),'success', result['bill'].Id+' '+ $A.get('$Label.c.Bill_Updated_Successfully'));
                                                            
                                                            //added by arshad 23 Aug 2023
                                                            if(!component.get("v.fromAP")){
                                                                if(hasAttachmentsToUpload){
                                                                    setTimeout(function(){ window.open(RecUrl,'_parent'); }, 5000);
                                                                }else{
                                                                    window.open(RecUrl,'_parent');
                                                                }
                                                            }
                                                        }
                                                        else{
                                                            console.log('inhere else bcoz maybe clone true');
                                                            helper.showToast($A.get('$Label.c.Success'),'success', result['bill'].Id+' '+ $A.get('$Label.c.Bill_Created_Successfully'));  
                                                        }
                                                        
                                                        if(component.get("v.navigateToRecord")){
                                                            console.log('inhere navigateToRecord true ');
                                                            var navEvt = $A.get("e.force:navigateToSObject");
                                                            if(navEvt != undefined){
                                                                navEvt.setParams({
                                                                    "isredirect": true,
                                                                    "recordId": result['bill'].Id,
                                                                    "slideDevName": "detail"
                                                                }); 
                                                                
                                                                //added by arshad 23 Aug 2023
                                                                if(hasAttachmentsToUpload){
                                                                    setTimeout(function(){  navEvt.fire(); }, 5000);
                                                                }else{
                                                                    navEvt.fire();
                                                                }
                                                            }
                                                            else {
                                                                console.log('inhere window.location.replace');
                                                                var selectedBillList=[];
                                                                selectedBillList.push(result['bill'].Id);
                                                                var url = '/'+result['bill'].Id;
                                                                
                                                                //added by arshad 23 Aug 2023
                                                                if(hasAttachmentsToUpload){
                                                                    setTimeout(function(){  window.location.replace(url); }, 5000);
                                                                }else{
                                                                    window.location.replace(url);
                                                                }
                                                            }
                                                        }else if(component.get("v.fromProject")){
                                                            var evt = $A.get("e.force:navigateToComponent");
                                                            evt.setParams({
                                                                componentDef : "c:Milestones",
                                                                componentAttributes: {
                                                                    "currentProj" : component.get("v.currentProj"),
                                                                    "projectId" : component.get("v.ProjId"),
                                                                    "newProj" : false
                                                                }
                                                            });
                                                            evt.fire();
                                                        }
                                                            else{
                                                                console.log('inhere navigateToRecord false');
                                                                var selectedBillList=[];
                                                                var result = response.getReturnValue(); 
                                                                var bilobj = result['bill2'];
                                                                var evt = $A.get("e.force:navigateToComponent");
                                                                evt.setParams({
                                                                    componentDef : "c:Accounts_Payable",
                                                                    componentAttributes: {
                                                                        "selectedTab" : 'Bills',
                                                                        "setSearch" : bilobj.Name,
                                                                    }
                                                                });
                                                                
                                                                //added by arshad 23 Aug 2023
                                                                if(hasAttachmentsToUpload){
                                                                    setTimeout(function(){  evt.fire();  }, 5000);
                                                                }else{
                                                                    evt.fire(); 
                                                                }
                                                            }
                                                        
                                                        console.log('here 7');
                                                        
                                                        if(component.get("v.fromPortal")){
                                                            //added by arshad 23 Aug 2023
                                                            if(hasAttachmentsToUpload){
                                                                setTimeout(function(){  location.reload();  }, 5000);
                                                            }else{
                                                                location.reload(); 
                                                            }
                                                        }
                                                        
                                                    }else{
                                                        var errors = response.getError();
                                                        console.log("server error in createBill : ", errors);
                                                        try{
                                                            if(errors != undefined && errors.length >0){
                                                                let err = errors[0].message;
                                                                helper.showToast('Error!','error', errors[0].message); 
                                                            }
                                                        }catch(e){ helper.showToast('Error!','error','Entries mismatch found!');  }
                                                        
                                                        component.set("v.showMmainSpin",false);
                                                    }
                                                    
                                                }catch(e){
                                                    console.log('error~>'+e);
                                                    if(response.getState() === 'SUCCESS'){ 
                                                        console.log('try error catch success so reloading if portalUser');
                                                        if(component.get("v.fromPortal")){
                                                            setTimeout(
                                                                $A.getCallback(function() {
                                                                    location.reload();
                                                                }), 5000
                                                            );
                                                        }
                                                    }else{
                                                        var errors = response.getError();
                                                        console.log("server error in createBill : ", errors);
                                                        try{
                                                            if(errors != undefined && errors.length >0){
                                                                let err = errors[0].message;
                                                                helper.showToast('Error!','error', errors[0].message); 
                                                            }
                                                        }catch(e){ helper.showToast('Error!','error','Entries mismatch found!');  }
                                                        component.set("v.showMmainSpin",false);
                                                    }
                                                }
                                                
                                                //added by arshad 23 Aug 2023
                                                if(hasAttachmentsToUpload){
                                                    setTimeout(function(){   component.set("v.showMmainSpin",false);  }, 5000);
                                                }else{
                                                    component.set("v.showMmainSpin",false);
                                                }
                                                
                                            });
                                            $A.enqueueAction(saveAction);
                                        }else{
                                            var errorMessage = '';
                                            if(isErrorsAACOA){
                                                errorMessage = 'Please select the Accounting Account and Analytical Account.';
                                            }else if(isErrorsAA){
                                                errorMessage = 'Total Analytical Account amount of an item cannot be greater or lesser then line item total amount.';
                                            }
                                            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',errorMessage);
                                        }
                                    }else{
                                        if(!showError) helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item'));
                                        
                                    } 
                                }else{
                                    helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Review_All_Errors'));
                                    component.set("v.showMmainSpin",false);
                                }
                            }else{
                                helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_Bill_Has_Already_Been_Created'));
                                component.set("v.showMmainSpin",false);
                                //return true;
                            }
                        }
                    }  
                    //component.set("v.showMmainSpin",false);
                });
                $A.enqueueAction(fetchpoliAction);
            }else{
                console.log('saveBill called');
                
                var billList = component.get("v.billItems");
                var Billobj = component.get("v.Bill");
                
                //alert('Bill=>'+JSON.stringify(component.get("v.Bill")));
                Billobj.Vendor_Contact__r = null;
                Billobj.Vendor_Address__r = null;
                Billobj.Purchase_Order__r = null;
                Billobj.Posted__c = component.get('v.setBillPost');
                if(Billobj.Total_Amount__c == undefined || Billobj.Total_Amount__c == null || Billobj.Total_Amount__c == '') Billobj.Total_Amount__c = 0.00;
                
                var totalAmount=parseFloat(Billobj.Amount__c);
                var advAmount=component.get('v.advPayment');
                if(component.get('v.setRT')=='Advance to vendor'){
                    var amount1=component.find('amount1').get('v.value');
                    if(parseFloat(amount1) <= 0 || amount1 ==''){
                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_enter_a_valid_amount'));
                        component.set("v.showMmainSpin",false);
                        return;
                    }            
                    /*if(amount1 == (totalAmount-advAmount)){
                    helper.showToast('Error!','error','You are creating bill for full amount, Please create a purchase order bill');
                    return;
                }*/
                if(amount1 > (totalAmount-advAmount)){
                    helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Can_not_enter_more_than_todal_due_amount'));
                    component.set("v.showMmainSpin",false);
                    return;
                }
                Billobj.Amount__c=amount1;
            }else{
                Billobj.Amount__c-=advAmount;
            }
                
                component.NOerrors =  true;
                helper.validation_Check(component,event);
                //component.set("v.showMmainSpin",false);
                var isErrorsAA = helper.AnalyticalAccountCheck(component, event, helper); 
                var isErrorsAACOA = helper.AnalyticalAccountCoaCheck(component, event, helper); 
                
                if(component.NOerrors){
                    var showError=false;
                    
                    if(billList.length>0){
                        for(var a = 0; a < billList.length; a++){//Moin added this on 13th september
                            //for(var a in billList ){
                            if(component.get("v.isMultiCurrency")) billList[a].CurrencyIsoCode = component.get("v.Bill.CurrencyIsoCode");
                            if(component.get("v.fromPortal") == false){ //change arshad
                                if(billList[a].Chart_Of_Account__c=='' || billList[a].Chart_Of_Account__c==null || billList[a].Chart_Of_Account__c==undefined){
                                    showError=true;
                                    var po=component.get('v.Bill.Purchase_Order__c');
                                    if(po!=null && po!='' && po!=undefined) helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_Select_the_inventory_account_for_all_line_items'));
                                    else helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_Select_the_expense_account_for_all_line_items'));
                                }
                            }
                        }
                    }
                    
                    if($A.util.isUndefinedOrNull(component.get("v.Bill.Vendor_Bill_Number__c"))){
                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_Enter_the_Vendor_Bill_Number'));
                        component.set("v.showMmainSpin",false);
                        return;
                    }
                    
                    //Moin removed and added below code if(component.get("v.recordId") != null && component.get("v.recordId") ==  undefined &&  component.get("v.recordId") ==  ''){
                    if(component.get("v.recordId") != null && component.get("v.recordId") !=  undefined &&  component.get("v.recordId") !=  ''){
                        if(component.get("v.isAttRequired") && (component.get("v.uploadedFile") == null || component.get("v.uploadedFile").length == 0) && component.get('v.setRT')!='Advance to vendor'){
                            var fillList11=component.get("v.fillList");
                            if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                                component.set("v.showMmainSpin",false);
                                return;
                            }
                        }
                        //Moin commented this
                        /* 
                   else{
                       var fillList11=component.get("v.fillList");
                       if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                           helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                           return;
                       }
                   }*/
                }
                else{
                    var fillList11=component.get("v.fillList");
                    if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor'){
                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Bill_Attachment_is_missing'));
                        component.set("v.showMmainSpin",false);
                        return;
                    }
                }
                
                
                if(!component.get("v.SyncSalesforce") && !component.get("v.SyncGDrive") && component.get("v.isGDrive")){                
                    helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error','Please Select Salesforce or Google Drive');
                    component.set("v.showMmainSpin",false);
                    return;
                }
                    if(component.get("v.showAllocations")){
                        var accCheck =true;
                        accCheck = helper.AnalyticalAccountingAccountCheck(component, event, helper);
                        if(!accCheck){
                            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.AddAnalyticalAccount'));
                            component.set("v.showMmainSpin",false);
                            return;
                        }
                    }
                if(billList.length > 0 && !(showError) ){
                    if(!isErrorsAA &&!isErrorsAACOA){
                        var dimensionList = [];
                        try{
                            
                            //for(var x in billList){
                            for(var x = 0; x < billList.length; x++){//Moin added this on 13th september
                                if(billList[x].Accounts != undefined && billList[x].Accounts != null){
                                    if(billList[x].Accounts.length > 0){
                                        for(var y in billList[x].Accounts){
                                            if(billList[x].Accounts[y].Sort_Order__c != undefined && billList[x].Accounts[y].Sort_Order__c != null){
                                                console.log('before poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                                billList[x].Accounts[y].Sort_Order__c = parseInt(parseInt(x)+1);
                                                console.log('after poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                            }
                                        }
                                        dimensionList.push(billList[x].Accounts);
                                    }
                                }
                            }
                            console.log('dimensionList : ',dimensionList);
                            
                            for(var x in billList){
                                if(billList[x].Accounts != undefined && billList[x].Accounts != null) billList[x].Accounts = [];
                            }
                        }catch(e){
                            console.log('arshad err,',e);
                        }
                        
                        component.set("v.showMmainSpin",true);
                        //Moin commented and added this on 31st july 2023
                        var saveAction = component.get("c.save_UpdatedBill");
                        //var saveAction = component.get("c.save_Bill");
                        console.log('JSON.stringify(Billobj)~>'+JSON.stringify(Billobj));
                        console.log('JSON.stringify(billList)~>'+JSON.stringify(billList));
                        
                        let jsonBill  = JSON.stringify(Billobj);
                        let jsonBillItems = JSON.stringify(billList);
                        var RTName;
                        if(component.get('v.setRT')=='PO Bill')RTName='PO_Bill';
                        if(component.get('v.setRT')=='Expense Bill')RTName='Expense_Bill';
                        if(component.get('v.setRT')=='Advance to vendor')RTName='Advance_to_vendor';
                        
                        console.log('saveBill v.clone~>'+component.get("v.clone"));
                        
                        saveAction.setParams({"Bill": jsonBill, "BillItems" :jsonBillItems,RTName:RTName,clone:component.get("v.clone")});
                        saveAction.setCallback(this,function(response){
                            try{
                                if(response.getState() === 'SUCCESS'){ 
                                    console.log('success here 1 resp~>',JSON.stringify(response.getReturnValue()));
                                    var result = response.getReturnValue();
                                    var bilobj = result['bill']; 
                                    component.set("v.BillId",bilobj.Id);
                                    
                                    if(component.get("v.clone")){
                                        component.set("v.recordId", bilobj.Id);//Moin added this on 14th august 2023 if(component.get("v.clone")) 
                                        console.log('inhere1 clone true saveBill');
                                    }
                                    
                                    console.log('here 1.1 : ',bilobj.Id);
                                    console.log('setRT : ',component.get('v.setRT'));
                                    console.log('fillList11 :',fillList11);
                                    
                                    if(!$A.util.isUndefinedOrNull(result['error'])) {
                                        console.log('here 5 ');
                                        helper.showToast('Error!','error',result['error']);
                                        component.set("v.showMmainSpin",false);
                                        return ;
                                    }
                                    
                                    //added by arshad 23 Aug 2023
                                    var hasAttachmentsToUpload = false;
                                    
                                    if(component.get('v.setRT')=='PO Bill' || component.get('v.setRT')=='Expense Bill' || component.get('v.setRT')=='Advance to vendor'){
                                        if(component.find("fileId").get("v.files")!=null){
                                            console.log('fileId get v.files not null');
                                            if (component.find("fileId").get("v.files").length > 0 && component.find("fileId").get("v.files") != undefined && fillList11.length > 0 && fillList11 != undefined) {   
                                                console.log('fileId get v.files length > 0');
                                                hasAttachmentsToUpload = true;
                                                var fileInput = component.get("v.FileList");
                                                for(var i=0; i<fileInput.length; i++){
                                                    if(!component.get("v.clone")) helper.saveAtt(component,event,fileInput[i],bilobj.Id);
                                                    else helper.saveCloneAtt(component,event,fileInput[i],bilobj.Id);
                                                } 
                                            }else console.log('not going fileId get v.files length 0');
                                        }else console.log('not going fileId get v.files null');
                                        
                                        console.log('Attach : ',component.get("v.Attach"));
                                        if(component.get("v.Attach")!=null){
                                            console.log('save_attachment2 here 3 ');
                                            var Billobj = component.get("v.BillId");
                                            var action=component.get("c.save_attachment2");
                                            action.setParams({"parentId": Billobj,"Pid":component.get("v.Bill.Purchase_Order__c"), });
                                            action.setCallback(this,function(response){
                                                if(response.getState() === 'SUCCESS'){
                                                    console.log('save_attachment2 here 4 success');
                                                }else{
                                                    var errors = response.getError();
                                                    console.log("server error in save_attachment2 : ", JSON.stringify(errors));
                                                }
                                            });
                                            $A.enqueueAction(action);
                                        }
                                        //return;
                                    }
                                    
                                    console.log('dimensionList.length : ',dimensionList.length);
                                    if(dimensionList.length > 0){
                                        try{
                                            var action2=component.get("c.createDimensionsList");
                                            action2.setParams({'dimelist':JSON.stringify(dimensionList), 'BillId':bilobj.Id});
                                            action2.setCallback(this,function(response){
                                                if(response.getState() === "SUCCESS"){
                                                    console.log('createDimensionsList in success');
                                                    //component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
                                                    //component.set("v.currencyList",response.getReturnValue().currencyList);
                                                }else{
                                                    var errors = response.getError();
                                                    console.log("server error in dimelist : ", JSON.stringify(errors));
                                                } 
                                            });
                                            $A.enqueueAction(action2);
                                        }catch(e){
                                            console.log('arshad err 2,',e);
                                        }
                                    }
                                    
                                    // return;
                                    if(component.get("v.recordId") != null && component.get("v.recordId") !=  undefined && component.get("v.recordId") !=  '' && !component.get("v.clone")){
                                        console.log('inhere if going to record page');
                                        var RecId = component.get("v.recordId");
                                        var RecUrl = "/lightning/r/Bill__c/" + RecId + "/view";
                                        helper.showToast($A.get('$Label.c.Success'),'success', result['bill'].Id+' '+ $A.get('$Label.c.Bill_Updated_Successfully'));
                                        
                                        //added by arshad 23 Aug 2023
                                        if(!component.get("v.fromAP")){
                                            if(hasAttachmentsToUpload){
                                                setTimeout(function(){ window.open(RecUrl,'_parent'); }, 5000);
                                            }else{
                                                window.open(RecUrl,'_parent');
                                            }
                                        }
                                    }
                                    else{
                                        console.log('inhere else bcoz maybe clone true');
                                        helper.showToast($A.get('$Label.c.Success'),'success', result['bill'].Id+' '+ $A.get('$Label.c.Bill_Created_Successfully'));  
                                    }
                                    
                                    if(component.get("v.navigateToRecord")){
                                        console.log('inhere navigateToRecord true ');
                                        var navEvt = $A.get("e.force:navigateToSObject");
                                        if(navEvt != undefined){
                                            navEvt.setParams({
                                                "isredirect": true,
                                                "recordId": result['bill'].Id,
                                                "slideDevName": "detail"
                                            }); 
                                            
                                            //added by arshad 23 Aug 2023
                                            if(hasAttachmentsToUpload){
                                                setTimeout(function(){  navEvt.fire(); }, 5000);
                                            }else{
                                                navEvt.fire();
                                            }
                                        }
                                        else {
                                            console.log('inhere window.location.replace');
                                            var selectedBillList=[];
                                            selectedBillList.push(result['bill'].Id);
                                            var url = '/'+result['bill'].Id;
                                            
                                            //added by arshad 23 Aug 2023
                                            if(hasAttachmentsToUpload){
                                                setTimeout(function(){  window.location.replace(url); }, 5000);
                                            }else{
                                                window.location.replace(url);
                                            }
                                        }
                                    }
                                    else{
                                        console.log('inhere navigateToRecord false');
                                        var selectedBillList=[];
                                        var result = response.getReturnValue(); 
                                        var bilobj = result['bill2'];
                                        var evt = $A.get("e.force:navigateToComponent");
                                        evt.setParams({
                                            componentDef : "c:Accounts_Payable",
                                            componentAttributes: {
                                                "selectedTab" : 'Bills',
                                                "setSearch" : bilobj.Name,
                                            }
                                        });
                                        
                                        //added by arshad 23 Aug 2023
                                        if(hasAttachmentsToUpload){
                                            setTimeout(function(){  evt.fire();  }, 5000);
                                        }else{
                                            evt.fire(); 
                                        }
                                    }
                                    
                                    console.log('here 7');
                                    
                                    if(component.get("v.fromPortal")){
                                        //added by arshad 23 Aug 2023
                                        if(hasAttachmentsToUpload){
                                            setTimeout(function(){  location.reload();  }, 5000);
                                        }else{
                                            location.reload(); 
                                        }
                                    }
                                    
                                }else{
                                    var errors = response.getError();
                                    console.log("server error in createBill : ", errors);
                                    try{
                                        if(errors != undefined && errors.length >0){
                                            let err = errors[0].message;
                                            helper.showToast('Error!','error', errors[0].message); 
                                        }
                                    }catch(e){ helper.showToast('Error!','error','Entries mismatch found!');  }
                                    
                                    component.set("v.showMmainSpin",false);
                                }
                                
                            }catch(e){
                                console.log('error~>'+e);
                                if(response.getState() === 'SUCCESS'){ 
                                    console.log('try error catch success so reloading if portalUser');
                                    if(component.get("v.fromPortal")){
                                        setTimeout(
                                            $A.getCallback(function() {
                                                location.reload();
                                            }), 5000
                                        );
                                    }
                                }else{
                                    var errors = response.getError();
                                    console.log("server error in createBill : ", errors);
                                    try{
                                        if(errors != undefined && errors.length >0){
                                            let err = errors[0].message;
                                            helper.showToast('Error!','error', errors[0].message); 
                                        }
                                    }catch(e){ helper.showToast('Error!','error','Entries mismatch found!');  }
                                    component.set("v.showMmainSpin",false);
                                }
                            }
                            
                            //added by arshad 23 Aug 2023
                            if(hasAttachmentsToUpload){
                                setTimeout(function(){   component.set("v.showMmainSpin",false);  }, 5000);
                            }else{
                                component.set("v.showMmainSpin",false);
                            }
                            
                        });
                        $A.enqueueAction(saveAction);
                    }else{
                        var errorMessage = '';
                        if(isErrorsAACOA){
                            errorMessage = 'Please select the Accounting Account and Analytical Account.';
                        }else if(isErrorsAA){
                            errorMessage = 'Total Analytical Account amount of an item cannot be greater or lesser then line item total amount.';
                        }
                        helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',errorMessage);
                        component.set("v.showMmainSpin",false);
                    }
                }else{
                    if(!showError) helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item'));
                    component.set("v.showMmainSpin",false);
                    
                } 
            }else{
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Review_All_Errors'));
                component.set("v.showMmainSpin",false);
            }
            }
        }
        
        catch(e){
            console.log('Error On Saving Bills ',e);
        }
    },
    
    goBack : function(component, event, helper) {
        //location.reload();
        if(component.get("v.recordId") != null && component.get("v.recordId") !=  undefined && component.get("v.recordId") !=  '' && !component.get("v.fromAP")){
            var RecId = component.get("v.recordId");
            var RecUrl = "/lightning/r/Bill__c/" + RecId + "/view";
            window.open(RecUrl,'_parent');
        }
        else if(component.get("v.fromAP")){
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:Accounts_Payable",
                componentAttributes: {
                    "aura:id": "AccountsPayable",
                    "selectedTab":"Bills"
                }
            });
            evt.fire();
        }else if(component.get("v.fromProject")){
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:Milestones",
                componentAttributes: {
                    "currentProj" : component.get("v.currentProj"),
                    "projectId" : component.get("v.ProjId"),
                    "newProj" : false
                }
            });
            evt.fire();
        }else if(component.get("v.supplier")){
                $A.createComponent("c:SupplierPortalBills",{
                },function(newCmp, status, errorMessage){
                    if (status === "SUCCESS") {
                        var body = component.find("body");
                        body.set("v.body", newCmp);
                    }
                });
            }else if(component.get("v.recordPage")){
                history.back(); 
            }else{
                $A.createComponent("c:SupplierPortalPO",{
                },function(newCmp, status, errorMessage){
                    if (status === "SUCCESS") {
                        var body = component.find("body");
                        body.set("v.body", newCmp);
                    }
                });
            }
        //history.back();  
    },
    
    validateField : function(component, event, helper){
        var billName = component.find("billName");
        if(!$A.util.isUndefined(billName)) 
            helper.checkValidationField(component,billName);
    },
    
    addNew : function(component, event, helper) {
        try{
            var billList = component.get("v.billItems");
            billList.push({sObjectType :'Bill_Line_Item__c',Accounts : [], Category:'', AccAccount:''});
            console.log('billList'+JSON.stringify(billList));
            component.set("v.billItems",billList);
        }catch(e){
            console.log('addNew err',e);
        }
    },
    
    delete_Item : function(component, event, helper) {
        var billList = component.get("v.billItems");
        billList.splice(component.get("v.Index2del"),1);
        component.set("v.billItems",billList);
    },
    
    deleteLineItem : function(component, event, helper) {
        component.set("v.showMmainSpin",true);
        try{
            var billList = component.get("v.billItems");
            billList.splice(event.getParam("Index"),1);
            component.set("v.billItems",billList);
            setTimeout(function() {
                component.set("v.showMmainSpin", false);
            }, 2000);
            $A.enqueueAction(component.get("c.updateTotalDiscount"));
            $A.enqueueAction(component.get("c.updateTotalPrice"));
            $A.enqueueAction(component.get("c.updateTotalTax"));
        }catch(e){
            console.log('deleteLineItem err',e);
            setTimeout(function() {
                // Hide the spinner after 2 seconds
                component.set("v.showMmainSpin", false);
            }, 2000);
        }
    },
    
    fetchPoli : function(component, event, helper) {
        console.log('fetchPoli called');
        if(component.get('v.recordId') == null || component.get('v.recordId') == '' || component.get('v.recordId') == undefined){
            try{
                var fetchpoliAction = component.get("c.fetch_Polis");
                fetchpoliAction.setParams({"Id":component.get("v.Bill.Purchase_Order__c")});
                fetchpoliAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){
                        var resultList = response.getReturnValue();
                        if(resultList.length > 0){
                            console.log('in here fetchpoliAction~>'+JSON.stringify(resultList));
                            try{
                                var po = JSON.parse(resultList[0]);
                                component.set("v.Bill.Vendor__c", po.Vendor__c);
                                component.set("v.Bill.Vendor_Contact__c", po.Vendor_Contact__c);
                                component.set("v.Bill.Vendor_Address__c", po.Vendor_Address__c);
                                component.set("v.Bill.Project__c", po.Project__c);
                                component.set("v.Bill.Department__c", po.Organisation_Business_Unit__c);
                                var descrip = '';
                                if(po.Description__c!=null && po.Description__c !=undefined && po.Description__c!=''){
                                    descrip = po.Description__c;
                                    descrip = descrip.replace(/<[^>]*>/g, '');
                                }
                                component.set("v.Bill.Description__c", descrip);
                                //component.set("v.Bill.Description__c", po.Description__c);
                                //alert('PO Org : ' +po.Organisation__c);
                                component.set("v.Bill.Organisation__c", po.Organisation__c);
                                var poliList = JSON.parse(resultList[1]);
                                var billingQty = JSON.parse(resultList[2]);
                                //alert('1==>'+JSON.stringify(poliList));
                                if(!$A.util.isEmpty(poliList)){
                                    var billList = [];//component.get("v.billItems");
                                    for(var x in poliList){
                                        for(var y in billingQty){
                                            if(x == y){
                                                //Changes made by Arshad tp populate tax rate same as it is from poli, to handle even if partial bills qty created - 29-June-2023
                                                if(poliList[x].Product__c == null || poliList[x].Product__c == undefined){
                                                    var obj = {Chart_Of_Account__c:null,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,Discount__c:0.00,
                                                               Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c,Vendor_Part_Number__c : poliList[x].Vendor_product_Name__c};
                                                    billList.push(obj);
                                                }else if(poliList[x].Product__r.Track_Inventory__c && !poliList[x].Product__r.Is_Asset__c){//Moin added this 29th november 2023 && !poliList[x].Product__r.Is_Asset__c
                                                    console.log('poliList[x]~>',JSON.stringify(poliList[x]));
                                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                               Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c,Vendor_Part_Number__c : poliList[x].Vendor_product_Name__c,Product__r : {ProductCode : poliList[x].Product__r.ProductCode}};//,Product__r : {ProductCode : poliList[x].Product__r.ProductCode}
                                                    billList.push(obj);
                                                }else if(poliList[x].Product__r.Is_Asset__c){
                                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                               Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c,Vendor_Part_Number__c : poliList[x].Vendor_product_Name__c,Product__r : {ProductCode : poliList[x].Product__r.ProductCode}};//
                                                    billList.push(obj);
                                                }else{
                                                    console.log('in here expense po');
                                                    var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                               Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c,Vendor_Part_Number__c : poliList[x].Vendor_product_Name__c,Product__r : {ProductCode : poliList[x].Product__r.ProductCode}};//,Product__r : {ProductCode : poliList[x].Product__r.ProductCode}
                                                    billList.push(obj);
                                                }
                                            }
                                        }
                                    }     
                                    console.log('billList~>',JSON.stringify(billList));
                                    
                                    component.set("v.billItems",billList);
                                    console.log('arshad before getPOLIDimeListhelper for PO fromhere1');
                                    
                                    if(component.get("v.Bill.Purchase_Order__c") != undefined && component.get("v.Bill.Purchase_Order__c") != null && component.get("v.Bill.Purchase_Order__c") != '' && component.get("v.billItems") != null && component.get("v.billItems") != undefined){
                                        if(component.get("v.billItems.length") > 0){
                                            helper.getPOLIDimeListhelper(component,event,helper);
                                        }
                                    }
                                    //var billPo=component.get("v.Bill.Purchase_Order__c");
                                    if(component.get("v.Bill.Purchase_Order__c") != undefined && component.get("v.Bill.Purchase_Order__c") != null && component.get("v.Bill.Purchase_Order__c") != ''){
                                        if(component.get("v.isMultiCurrency")) { 
                                            helper.fetchPOCurrncy(component,event,helper); 
                                        }
                                    }
                                    //component.set('v.setRT','PO Bill');
                                    component.set("v.Bill.Discount_Amount__c",0);
                                    helper.calculateAdvBill(component,event);
                                    //
                                }else{
                                    helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_Bill_Has_Already_Been_Created'));
                                    setTimeout(
                                        $A.getCallback(function() {
                                            $A.enqueueAction(component.get("c.cancelclick"));
                                        }), 3000
                                    );
                                    
                                }
                            }catch(e){
                                console.log('arshad err1',e);
                            }
                        }
                    }  
                });
                $A.enqueueAction(fetchpoliAction);
                /*var action2=component.get("c.uploadFile");
                action2.setParams({
                    "pid" : component.get("v.Bill.Purchase_Order__c")
                });
                action2.setCallback(this, function(response){
                    var state = response.getState();
                    if( state === "SUCCESS" ){
                        if(!component.get("v.clone")){
                            component.set("v.fileName",response.getReturnValue().Name);
                            component.set("v.Attach",response.getReturnValue());
                        }
                        
                    }
                });
                $A.enqueueAction(action2);*/
            }catch(e){
                console.log('arshad err2',e);
            }
        }
    },
    
    fetchMultiPoli : function(component, event, helper) {
        console.log('fetchMultiPoli called');
        try{
            var fetchpoliAction = component.get("c.fetch_Polis_Multi");
            fetchpoliAction.setParams({"Ids":component.get("v.POIdsList")});
            fetchpoliAction.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){
                    var resultList = response.getReturnValue();
                    if(resultList.length > 0){
                        console.log('in here fetchpoliAction~>'+JSON.stringify(resultList));
                        try{
                            var po = JSON.parse(resultList[0]);
                            component.set("v.Bill.Vendor__c", po.Vendor__c);
                            //component.set("v.Bill.Sales_Order__c", po.Sales_Order__c);
                            component.set("v.Bill.Vendor_Contact__c", po.Vendor_Contact__c);
                            component.set("v.Bill.Vendor_Address__c", po.Vendor_Address__c);
                            //component.set("v.Bill.Description__c", po.Description__c);
                            //alert('PO Org : ' +po.Organisation__c);
                            component.set("v.Bill.Organisation__c", po.Organisation__c);
                            var poliList = JSON.parse(resultList[1]);
                            var billingQty = JSON.parse(resultList[2]);
                            var PoList = JSON.parse(resultList[3]);
                            component.set("v.PoList", PoList);
                            //alert('1==>'+JSON.stringify(poliList));
                            if(!$A.util.isEmpty(poliList)){
                                var billList = [];//component.get("v.billItems");
                                for(var x in poliList){
                                    for(var y in billingQty){
                                        if(x == y){
                                            //Changes made by Arshad tp populate tax rate same as it is from poli, to handle even if partial bills qty created - 29-June-2023
                                            if(poliList[x].Product__c == null || poliList[x].Product__c == undefined){
                                                var obj = {Chart_Of_Account__c:null,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,Discount__c:0.00,
                                                           Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c};
                                                billList.push(obj);
                                            }else if(poliList[x].Product__r.Track_Inventory__c){
                                                console.log('poliList[x]~>'+JSON.stringify(poliList[x]));
                                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                           Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c};
                                                billList.push(obj);
                                            }else if(poliList[x].Product__r.Is_Asset__c){
                                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                           Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c};
                                                billList.push(obj);
                                            }else{
                                                console.log('in here expense po');
                                                var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,
                                                           Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c,Other_Tax__c:0.00,Description__c:poliList[x].Description__c,Tax_Rate__c:poliList[x].Tax_Rate__c};
                                                billList.push(obj);
                                            }
                                        }
                                    }
                                }     
                                component.set("v.billItems",billList);
                                console.log('arshad before getPOLIDimeListhelper for PO');
                                
                                if(component.get("v.billItems") != null && component.get("v.billItems") != undefined){
                                    if(component.get("v.billItems.length") > 0){
                                        helper.getPOLIDimeListMultihelper(component,event,helper);
                                    }
                                }
                            }else{
                                helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_Bill_Has_Already_Been_Created'));
                                setTimeout(
                                    $A.getCallback(function() {
                                        $A.enqueueAction(component.get("c.cancelclick"));
                                    }), 3000
                                );
                                
                            }
                        }catch(e){
                            console.log('arshad err1',e);
                        }
                    }
                }  
            });
            $A.enqueueAction(fetchpoliAction);
        }catch(e){
            console.log('arshad err2',e);
        }
    },
    
    updateDate : function(component,event,helper){
        var vBillDate = component.get("v.Bill.Vendor_Bill_Date__c");
        if(!$A.util.isEmpty(vBillDate)){
            var parts =vBillDate.split('-');
            var dueDate = new Date(parts[0], parts[1] - 1, parts[2]); 
            dueDate.setDate(dueDate.getDate() + component.get("v.payTerms"));
            component.set("v.Bill.Due_Date__c",dueDate.getFullYear() + "-" + (dueDate.getMonth() + 1) + "-" + dueDate.getDate());
        }
    },
    
    fetchVendorDetails  : function(component,event,helper){
        if((component.get('v.recordId') == undefined || component.get('v.recordId') == null || component.get('v.recordId') == '') || component.get('v.clone')){
            let vendorAction = component.get("c.getVendorDetails");
            var recID = component.get("v.Bill.Vendor__c");
            if(!$A.util.isEmpty(recID)){
                vendorAction.setParams({"recordId":recID});
                vendorAction.setCallback(this,function(response){
                    if(response.getState() === 'SUCCESS'){
                        console.log('fetchVendorDetails~>'+response.getReturnValue());
                        //component.set("v.Bill.Vendor__c",recID);
                        //var bill = component.get("v.Bill");
                        var dueDate = new Date();
                        var vBillDate = new Date();
                        if(!$A.util.isUndefined(response.getReturnValue().Payment_Terms__c)){
                            dueDate.setDate(dueDate.getDate() + parseInt(response.getReturnValue().Payment_Terms__c));
                            vBillDate.setDate(vBillDate.getDate());
                            component.set("v.payTerms",parseInt(response.getReturnValue().Payment_Terms__c));
                        }
                        component.set("v.Bill.Vendor_Bill_Date__c", vBillDate.getFullYear() + "-" + (vBillDate.getMonth() + 1) + "-" + vBillDate.getDate());
                        console.log('Vendor_Bill_Date__c set here1~>'+component.get("v.Bill.Vendor_Bill_Date__c"));
                        component.set("v.Bill.Due_Date__c",dueDate.getFullYear() + "-" + (dueDate.getMonth() + 1) + "-" + dueDate.getDate()); //bill.Due_Date__c = response.getReturnValue().Payment_Terms__c;
                    }
                });
                $A.enqueueAction(vendorAction);
            }else
                component.set("v.Bill.Vendor__c",'');
        }
    },
    
    onCheck: function(component,event,helper){
        var currBillTrye = event.currentTarget.getAttribute('data-billType');
        component.set('v.setRT',currBillTrye);
        component.set('v.ShowBillType',false);
        component.set('v.showPage',true);
        /* var poCheck=component.find('pOcheckbox').get("v.value");
         var billCheck=component.find('billcheckbox').get("v.value");
        var Advcheckbox=component.find('Advcheckbox').get("v.value");
       
         if(poCheck)component.set('v.setRT','PO Bill');
         if(billCheck)component.set('v.setRT','Expense Bill');
        if(Advcheckbox)component.set('v.setRT','Advance to vendor');
         component.set('v.ShowBillType',false);
         component.set('v.showPage',true);
         */
    },
    
    setpostFalse:function(component,event,helper){
        component.set('v.setBillPost',false);
    },
    
    setpostTrue:function(component,event,helper){
        component.set('v.setBillPost',true);
    },
    
    /*doSave: function(component, event, helper) {
        if (component.find("fileId").get("v.files").length > 0) {
            helper.uploadHelper(component, event);
        } else {
            alert('Please Select a Valid File');
        }
    },*/
    
   
    removeAttachment: function(component, event, helper) {
        // Hide the delete button
        component.set("v.showDelete", false);
    
        // Clear the billItems (or any line items in the bill)
        var billItems = component.get("v.billItems");
        billItems.splice(0, billItems.length); // Removes all items from billItems
        component.set("v.billItems", billItems); // Update the component's billItems attribute
    
        // Clear the FileList and fillList attributes
        component.set("v.FileList", []);
        component.set("v.fillList", []);
    
        // Clear the file input field by resetting its value
        let fileInput = component.find("fileId");
        if (fileInput) {
            fileInput.getElement().value = ""; // Reset the file input value
        }
    },
    
   

    navigatetoPO : function(component, event, helper) {
        var POId=component.get('v.Bill.Purchase_Order__c');
        if(POId == undefined){
            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.Please_select_Purchase_Order'));
            return;
        }
        /*var evt = $A.get("e.force:navigateToComponent");
         evt.setParams({
             componentDef : "c:CreatePurchaseOrder",
             componentAttributes: {
                 recordId : component.get("v.Bill.Purchase_Order__c"),
                 fromCB : "true"
             }
         });
         evt.fire();*/
        
        $A.createComponent("c:CreatePurchaseOrder",{
            recordId : component.get("v.Bill.Purchase_Order__c"),
            fromCB : true
        },function(newCmp, status, errorMessage){
            if (status === "SUCCESS") {
                var body = component.find("body");
                body.set("v.body", newCmp);
            }
        }); 
        
        /*var url = '/apex/CreatePurchaseOrderLC?PoId=';
         url = url + component.get("v.Bill.Purchase_Order__c");
         url = url + '&fromCB=true'
         window.location.replace(url);*/
        //window.open(url,"__self");
    },
    
      /* handleFilesChange: function(component, event, helper) {
        
        
        
     
        var billList = component.get("v.billItems");
        billList.push({sObjectType :'Bill_Line_Item__c',Accounts : [], Category:'', AccAccount:''});
        var Billobj = component.get("v.Bill");
        for(var x in billList){
            billList[x].Quantity__c = 5;
            billList[x].Amount__c = 20.5;
            billList[x].Product__c = '01t0600000D1finAAB';
        }
        component.set("v.billItems", billList);
        billList = component.get("v.billItems");
        billList.push({sObjectType :'Bill_Line_Item__c',Accounts : [], Category:'', AccAccount:''});
        for(var x in billList){
            if(x!=0){
                billList[x].Quantity__c = 6;
                billList[x].Amount__c = 27.5;
                billList[x].Product__c = '01t1o00000BAqoDAAT';
            }
        }
        component.set("v.billItems", billList);
        Billobj.Vendor__c = '0010600002Hg6KVAAZ';
        Billobj.Vendor_Contact__c = '0030600002GDfp3AAD';
        Billobj.Vendor_Address__c = 'a00J6000001nAoBIAU';
        Billobj.Vendor_Bill_Number__c = 'CR-0001-3456723467';
        var dueDate = new Date();
        var vBillDate = new Date();
        component.set("v.Bill.Vendor_Bill_Date__c", vBillDate.getFullYear() + "-" + (vBillDate.getMonth() + 1) + "-" + vBillDate.getDate());
        console.log('Vendor_Bill_Date__c set here1~>'+component.get("v.Bill.Vendor_Bill_Date__c"));
        component.set("v.Bill.Due_Date__c",dueDate.getFullYear() + "-" + (dueDate.getMonth() + 1) + "-" + dueDate.getDate()); 
        component.set("v.Bill", Billobj);
        component.set("v.showDelete",true);
        var fileName = 'No File Selected..';
        //var files = component.get("v.FileList");  
        
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            var fileItem = [];
            for(var i=0;i<event.getSource().get("v.files").length;i++){
                fileItem.push(event.getSource().get("v.files")[i]['name']);
            }
        }
        //alert(fileItem);
        component.set("v.fillList",fileItem);
        component.set("v.fileName", fileName);
    }, */
    
    updateTDS : function(cmp, e, h){
        
        var tds_rate = cmp.get('v.TDS_Rate');
        
        if(tds_rate==undefined || tds_rate==null)tds_rate=0
        var TDS_Amount =0;
        if(tds_rate>0)TDS_Amount=(cmp.get('v.Bill.Amount__c')/100)*tds_rate;
        cmp.set('v.Bill.TDS_Amount__c',TDS_Amount);
    },
    
    cancelclick : function(cmp,event,helper){
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:Accounts_Payable",
            componentAttributes: {
                "selectedTab" : 'Bills'
            }
        });
        evt.fire();
        
    },
    
    UpdateOA: function(component,event,helper){
        if(component.get('v.recordId') == null || component.get('v.recordId') == '' || component.get('v.recordId') == undefined){
            console.log('UpdateOA called');
            if(component.get("v.Bill.Organisation__c") != null && component.get("v.Bill.Organisation__c") != undefined && component.get('v.setRT')=='Expense Bill'){
                var isMulticurrency = component.get('v.isMultiCurrency');
                if(isMulticurrency == true) { 
                    helper.fetchOrgCurrncy(component,event,helper); 
                }
            }
        }
    },
    
    imageError: function(component,event,helper){
        console.log('imageError called');
        event.target.style.display = 'none';
    },  
    
    DeleteRecordAT: function(component, event) {
        var result = confirm("Are you sure?");
        console.log('result : ',result);
        var RecordId = event.getSource().get("v.name");
        console.log('RecordId : ',RecordId);
        var parentId = event.getSource().get("v.title");
        console.log('parentId : ',parentId);
        if (result) {
            //window.scrollTo(0, 0);
            //$A.util.removeClass(component.find('mainSpin'), "slds-hide");
            try{
                var action = component.get("c.DeleteAttachment");
                action.setParams({
                    attachId: RecordId,
                    parentId: parentId,
                });
                action.setCallback(this, function(response) {
                    if (response.getState() === "SUCCESS") {
                        console.log("DeleteRecordAT resp: ", JSON.stringify(response.getReturnValue()));
                        component.set('v.uploadedFile',response.getReturnValue());
                        $A.util.addClass(component.find('mainSpin'), "slds-hide");
                    }
                    else{
                        $A.util.addClass(component.find('mainSpin'), "slds-hide");
                        var errors = response.getError();
                        console.log("server error in doInit : ", JSON.stringify(errors));
                        component.set("v.exceptionError", errors[0].message);
                    }
                });
                $A.enqueueAction(action);
            }
            catch(err) {
                console.log('Exception : ',err);
            }
        } 
    },
    
    
    // Code forthe OCR part by saqlain khan
    
       onScriptsLoaded: function(component, event, helper) {
        console.log('Script Loaded');
    },

    onScriptsLoaded1: function(component, event, helper) {
        console.log('Script Loaded 1');
        globalThis = window;
        var workerSrcUrl = $A.get('$Resource.PDFReaderWorkerJS');
        pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrcUrl;
    },
    
    


    
   
   /* handleFilesChange: function(component, event, helper) {
        try {
            var fileInput = event.getSource().get("v.files")[0];
            var file = fileInput;

            if (file) {
                if (file.type === 'application/pdf') {
                    // Handle PDF processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            var typedArray = new Uint8Array(reader.result);
                            pdfjsLib.getDocument(typedArray).promise.then(function(pdf) {
                                pdf.getPage(1).then(function(page) {
                                    page.getTextContent().then(function(textContent) {
                                        var extractedText = textContent.items.map(item => item.str).join(' ');
                                        helper.processInvoiceText(component, extractedText);
                                         try{
            var billList = component.get("v.billItems");
            billList.push({sObjectType :'Bill_Line_Item__c',Accounts : [], Category:'', AccAccount:''});
            console.log('billList'+JSON.stringify(billList));
            component.set("v.billItems",billList);
        }catch(e){
            console.log('addNew err',e);
        }
                                    }).catch(error => {
                                        console.error("Error extracting text from PDF page:", error);
                                        alert("An error occurred while extracting text from the PDF page.");
                                    });
                                }).catch(error => {
                                    console.error("Error loading PDF page:", error);
                                    alert("An error occurred while loading the PDF page.");
                                });
                            }).catch(error => {
                                console.error("Error loading PDF document:", error);
                                alert("An error occurred while loading the PDF document.");
                            });
                        } catch (error) {
                            console.error("Error processing PDF:", error);
                            alert("An error occurred while processing the PDF.");
                        }
                    };
                    reader.readAsArrayBuffer(file);
                } else if (file.type.startsWith('image/')) {
                    // Handle Image processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            Tesseract.recognize(
                                reader.result,
                                'eng',
                                {
                                    logger: m => console.log(m) // Log progress
                                }
                            ).then(({ data: { text } }) => {
                                helper.processInvoiceText(component, text);
                            }).catch(error => {
                                console.error("Error processing image with OCR:", error);
                                alert("An error occurred while processing the image with OCR.");
                            });
                        } catch (error) {
                            console.error("Error in image OCR processing:", error);
                            alert("An error occurred while reading the image file.");
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    alert('Please select a PDF or image file.');
                }
            }
        } catch (error) {
            console.error("Error in handleFileChange:", error);
            alert("An error occurred while reading the file.");
        }
    },  */
    
  
/*    handleFilesChange: function(component, event, helper) {
        try {
            var fileInput = event.getSource().get("v.files")[0];
            var file = fileInput;

            if (file) {
                if (file.type === 'application/pdf') {
                    // Handle PDF processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            var typedArray = new Uint8Array(reader.result);
                            pdfjsLib.getDocument(typedArray).promise.then(function(pdf) {
                                pdf.getPage(1).then(function(page) {
                                    page.getTextContent().then(function(textContent) {
                                        var extractedText = textContent.items.map(item => item.str).join(' ');

                                        // Process the extracted text
                                        var invoiceData = helper.processInvoiceText(component, extractedText);
                                        var billList = component.get("v.billItems") || [];

                                        billList.push({
                                            sObjectType: 'Bill_Line_Item__c',
                                            Accounts: [],
                                            Category: '',
                                            AccAccount: '',
                                           Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c ? invoiceData.alternativeDetails.Tax_Amount__c : "",
Quantity__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Quantity__c ? invoiceData.lineItems[0].Quantity__c : "",
Product__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Product__c ? invoiceData.lineItems[0].Product__c : "",
Amount__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Amount__c ? invoiceData.lineItems[0].Amount__c : ""

                                        });

                                        component.set("v.billItems", billList);
                                        console.log("Updated billItems:", JSON.stringify(billList));
                                    }).catch(error => {
                                        console.error("Error extracting text from PDF page:", error);
                                        alert("An error occurred while extracting text from the PDF page.");
                                    });
                                }).catch(error => {
                                    console.error("Error loading PDF page:", error);
                                    alert("An error occurred while loading the PDF page.");
                                });
                            }).catch(error => {
                                console.error("Error loading PDF document:", error);
                                alert("An error occurred while loading the PDF document.");
                            });
                        } catch (error) {
                            console.error("Error processing PDF:", error);
                            alert("An error occurred while processing the PDF.");
                        }
                    };
                    reader.readAsArrayBuffer(file);
                } else if (file.type.startsWith('image/')) {
                    // Handle Image processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            Tesseract.recognize(
                                reader.result,
                                'eng',
                                {
                                    logger: m => console.log(m) // Log progress
                                }
                            ).then(({ data: { text } }) => {
                                var invoiceData = helper.processInvoiceText(component, text);
                                var billList = component.get("v.billItems") || [];

                                billList.push({
                                    sObjectType: 'Bill_Line_Item__c',
                                    Accounts: [],
                                    Category: '',
                                    AccAccount: '',
                                    Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c ? invoiceData.alternativeDetails.Tax_Amount__c : "",
Quantity__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Quantity__c ? invoiceData.lineItems[0].Quantity__c : "",
Product__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Product__c ? invoiceData.lineItems[0].Product__c : "",
Amount__c: invoiceData.lineItems.length > 0 && invoiceData.lineItems[0].Amount__c ? invoiceData.lineItems[0].Amount__c : ""

                                });

                                component.set("v.billItems", billList);
                                console.log("Updated billItems:", JSON.stringify(billList));
                            }).catch(error => {
                                console.error("Error processing image with OCR:", error);
                                alert("An error occurred while processing the image with OCR.");
                            });
                        } catch (error) {
                            console.error("Error in image OCR processing:", error);
                            alert("An error occurred while reading the image file.");
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    alert('Please select a PDF or image file.');
                }
            }
        } catch (error) {
            console.error("Error in handleFileChange:", error);
            alert("An error occurred while reading the file.");
        }
    }

*/
    
    /*
     handleFilesChange: function(component, event, helper) {
        try {
            var fileInput = event.getSource().get("v.files")[0];
            var file = fileInput;

            if (file) {
                if (file.type === 'application/pdf') {
                    // Handle PDF processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            var typedArray = new Uint8Array(reader.result);
                            pdfjsLib.getDocument(typedArray).promise.then(function(pdf) {
                                pdf.getPage(1).then(function(page) {
                                    page.getTextContent().then(function(textContent) {
                                        var extractedText = textContent.items.map(item => item.str).join(' ');

                                        // Process the extracted text
                                        var invoiceData = helper.processInvoiceText(component, extractedText);

                                        var billList = component.get("v.billItems") || [];
                                        var lineItem = invoiceData.lineItems.length > 0 ? invoiceData.lineItems[0] : {};

                                     var productName = invoiceData.lineItems.length > 0 ? invoiceData.lineItems[0].Product__c : '';
                                            console.log('Extracted Product Name:', productName);
                                            
                                            if (productName) {
                                                // Call Helper method to fetch product ID by name
                                                helper.getProductIdByName(component, productName)
                                                    .then((productId) => {
                                                        // Create a new bill line item with the product ID or name
                                                        var billList = component.get("v.billItems") || []; // Retrieve existing billItems or initialize a new list
                                                        invoiceData.lineItems.forEach(lineItem => {
                                                            billList.push({
                                                                sObjectType: 'Bill_Line_Item__c',
                                                                Accounts: [],
                                                                Category: '',
                                                                AccAccount: '',
                                                                Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c || "",
                                                                Quantity__c: lineItem.Quantity__c || "",
                                                                Product__r: { Name: productId ? '' : productName },  // Set Name if no ID found
                                                                Amount__c: lineItem.Amount__c || "",
                                                                Product__c: productId || '',  // Set ID if found
                                                            });
                                                        });
                                                        component.set("v.billItems", billList);
                                                        console.log("Updated billItems:", JSON.stringify(billList));
                                                    })
                                                    .catch((error) => {
                                                        console.error("Error finding product ID:", error);
                                                    });
                                        }
                                    }).catch(error => {
                                        console.error("Error extracting text from PDF page:", error);
                                    });
                                }).catch(error => {
                                    console.error("Error loading PDF page:", error);
                                });
                            }).catch(error => {
                                console.error("Error loading PDF document:", error);
                            });
                        } catch (error) {
                            console.error("Error processing PDF:", error);
                        }
                    };
                    reader.readAsArrayBuffer(file);
                } else if (file.type.startsWith('image/')) {
                    // Handle Image processing
                    var reader = new FileReader();
                    reader.onload = function() {
                        try {
                            Tesseract.recognize(
                                reader.result,
                                'eng',
                                {
                                    logger: m => console.log(m) // Log progress
                                }
                            ).then(({ data: { text } }) => {
                                var invoiceData = helper.processInvoiceText(component, text);

                                var billList = component.get("v.billItems") || [];
                                var lineItem = invoiceData.lineItems.length > 0 ? invoiceData.lineItems[0] : {};

                                var productName = invoiceData.lineItems.length > 0 ? invoiceData.lineItems[0].Product__c : '';
                                            console.log('Extracted Product Name:', productName);
                                            
                                            if (productName) {
                                                // Call Helper method to fetch product ID by name
                                                helper.getProductIdByName(component, productName)
                                                    .then((productId) => {
                                                        // Create a new bill line item with the product ID or name
                                                        var billList = component.get("v.billItems") || []; // Retrieve existing billItems or initialize a new list
                                                        invoiceData.lineItems.forEach(lineItem => {
                                                            billList.push({
                                                                sObjectType: 'Bill_Line_Item__c',
                                                                Accounts: [],
                                                                Category: '',
                                                                AccAccount: '',
                                                                Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c || "",
                                                                Quantity__c: lineItem.Quantity__c || "",
                                                                Product__r: { Name: productId ? '' : productName },  // Set Name if no ID found
                                                                Amount__c: lineItem.Amount__c || "",
                                                                Product__c: productId || '',  // Set ID if found
                                                            });
                                                        });
                                                        component.set("v.billItems", billList);
                                                        console.log("Updated billItems:", JSON.stringify(billList));
                                                    })
                                                    .catch((error) => {
                                                        console.error("Error finding product ID:", error);
                                                    });
                                }
                            }).catch(error => {
                                console.error("Error processing image with OCR:", error);
                            });
                        } catch (error) {
                            console.error("Error in image OCR processing:", error);
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    alert('Please select a PDF or image file.');
                }
            }
        } catch (error) {
            console.error("Error in handleFileChange:", error);
        }
    }
    */
 
  /*handleFilesChange: function(component, event, helper) {
    try {
        var fileInput = event.getSource().get("v.files")[0];
        var file = fileInput;

        if (file) {
            if (file.type === 'application/pdf') {
                // Handle PDF processing
                var reader = new FileReader();
                reader.onload = function() {
                    try {
                        var typedArray = new Uint8Array(reader.result);
                        pdfjsLib.getDocument(typedArray).promise.then(function(pdf) {
                            pdf.getPage(1).then(function(page) {
                                page.getTextContent().then(function(textContent) {
                                    var extractedText = textContent.items.map(item => item.str).join(' ');

                                    // Process the extracted text
                                    var invoiceData = helper.processInvoiceText(component, extractedText);
                                    var billList = component.get("v.billItems") || [];

                                   var productNames = invoiceData.lineItems.map(lineItem => lineItem.Product__c);
console.log('Extracted Product Names:', productNames);

if (productNames.length > 0) {
    helper.getProductIdByName(component, productNames)
        .then((productIdMap) => {
            invoiceData.lineItems.forEach(lineItem => {
                var productId = productIdMap[lineItem.Product__c] || '';
                billList.push({
                    sObjectType: 'Bill_Line_Item__c',
                    Accounts: [],
                    Category: '',
                    AccAccount: '',
                    Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c || "",
                    Quantity__c: lineItem.Quantity__c || "",
                    Product__r: { Name: productId ? '' : lineItem.Product__c },  // Use name if ID not found
                    Amount__c: lineItem.Amount__c || "",
                    Product__c: productId || ''  // Set product ID if found
                });
            });

            component.set("v.billItems", billList);
            console.log("Updated billItems:", JSON.stringify(billList));
        })
        .catch((error) => {
            console.error("Error finding product IDs:", error);
        });
                                    }
                                }).catch(error => {
                                    console.error("Error extracting text from PDF page:", error);
                                });
                            }).catch(error => {
                                console.error("Error loading PDF page:", error);
                            });
                        }).catch(error => {
                            console.error("Error loading PDF document:", error);
                        });
                    } catch (error) {
                        console.error("Error processing PDF:", error);
                    }
                };
                reader.readAsArrayBuffer(file);

            } else if (file.type.startsWith('image/')) {
                // Handle image processing
                var reader = new FileReader();
                reader.onload = function() {
                    try {
                        Tesseract.recognize(reader.result, 'eng', {
                            logger: m => console.log(m) // Log progress
                        }).then(({ data: { text } }) => {
                            var invoiceData = helper.processInvoiceText(component, text);
                            var billList = component.get("v.billItems") || [];

                          var productNames = invoiceData.lineItems.map(lineItem => lineItem.Product__c);
console.log('Extracted Product Names:', productNames);

if (productNames.length > 0) {
    helper.getProductIdByName(component, productNames)
        .then((productIdMap) => {
            invoiceData.lineItems.forEach(lineItem => {
                var productId = productIdMap[lineItem.Product__c] || '';
                billList.push({
                    sObjectType: 'Bill_Line_Item__c',
                    Accounts: [],
                    Category: '',
                    AccAccount: '',
                    Tax_Amount__c: invoiceData.alternativeDetails.Tax_Amount__c || "",
                    Quantity__c: lineItem.Quantity__c || "",
                    Product__r: { Name: productId ? '' : lineItem.Product__c },  // Use name if ID not found
                    Amount__c: lineItem.Amount__c || "",
                    Product__c: productId || ''  // Set product ID if found
                });
            });

            component.set("v.billItems", billList);
            console.log("Updated billItems:", JSON.stringify(billList));
        })
        .catch((error) => {
            console.error("Error finding product IDs:", error);
        });
                            }
                        }).catch(error => {
                            console.error("Error processing image with OCR:", error);
                        });
                    } catch (error) {
                        console.error("Error in image OCR processing:", error);
                    }
                };
                reader.readAsDataURL(file);
            } else {
                alert('Please select a PDF or image file.');
            }
        }
    } catch (error) {
        console.error("Error in handleFilesChange:", error);
    }
}
*/
 
//  handleFilesChange: function(component, event, helper) {
//     try {
//         var fileInput = event.getSource().get("v.files")[0];
//         if (fileInput) {
//             component.set("v.showDelete", true);
//             helper.processFile(fileInput, component, helper);
//         } else {
//             alert('Please select a valid file.');
//         }
//     } catch (error) {
//         console.error("Error in handleFilesChange:", error);
//     }
// },
// 
// 


    
    
   
   /* 
   
   

handleFilesChange: function (component, event, helper) {
    
    
    
      // Check the state of the "Read bill" checkbox
        const isReadBillChecked = component.get("v.isReadBillChecked");
        
        if (isReadBillChecked) {
            console.log('The OCR file reading funtion is called');
    
    
    
    try {
        const fileInput = event.getSource().get("v.files")[0];
        if (fileInput) {
              // Track the recently added file
              component.set("v.recentFileData", fileInput);
            // Save the file temporarily for further action
            component.set("v.selectedFile", fileInput);

            // Show the modal
            component.set("v.showModal", true);
        } else {
            alert("Please select a valid file.");
        }
    } catch (error) {
        console.error("Error in handleFilesChange:", error);
    }
        } else {
            component.set("v.showDelete",true);
        var fileName = 'No File Selected..';
        //var files = component.get("v.FileList");  
         console.log('The Normal default funtion is called for file upload, NOT the OCR');
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            var fileItem = [];
            for(var i=0;i<event.getSource().get("v.files").length;i++){
                fileItem.push(event.getSource().get("v.files")[i]['name']);
            }
        }
        //alert(fileItem);
        component.set("v.fillList",fileItem);
        component.set("v.fileName", fileName);
        }
   
},
*/
    closeModal: function (component, event, helper) {
    // Set the showModal attribute to false to close the modal
    component.set("v.showModal", false);
},
    
    
   handleFilesChange: function (component, event, helper) {
        // Check the state of the "Read bill" checkbox
        const isReadBillChecked = component.get("v.isReadBillChecked");

        if (isReadBillChecked) {
            console.log('The OCR file reading function is called.');
            try {
                const fileInput = event.getSource().get("v.files")[0];
                if (fileInput) {
                    // Track the recently added file
                    component.set("v.recentFileData", fileInput);
                    // Save the file temporarily for further action
                    component.set("v.selectedFile", fileInput);

                    // Show the modal
                    component.set("v.showModal", true);
                } else {
                    alert("Please select a valid file.");
                }
            } catch (error) {
                console.error("Error in handleFilesChange:", error);
            }
        } else {
            console.log('The normal default function is called for file upload, NOT the OCR.');
            component.set("v.showDelete", true);
            let fileName = 'No File Selected..';

            if (event.getSource().get("v.files").length > 0) {
                fileName = event.getSource().get("v.files")[0]['name'];
                const fileItem = [];
                for (let i = 0; i < event.getSource().get("v.files").length; i++) {
                    fileItem.push(event.getSource().get("v.files")[i]['name']);
                }
                component.set("v.fillList", fileItem);
                component.set("v.fileName", fileName);
            }
        }
    },  
    
    
alterBill: function (component, event, helper) {
    try {
        const fileInput = component.get("v.selectedFile");
        if (fileInput) {
            // Process the file using helper logic
            component.set("v.showDelete", true);
            helper.processFile(fileInput, component, helper);
        }
        // Close the modal
        component.set("v.showModal", false);
    } catch (error) {
        console.error("Error in alterBill:", error);
    }
},


createNewBill: function (component, event, helper) {
    try {
        const fileInput = component.get("v.selectedFile");
        if (fileInput) {
            // Clear existing bill items
            let billItems = component.get("v.billItems");
            billItems.splice(0, billItems.length); // Removes all items from billItems
            component.set("v.billItems", billItems);

            // Process the new file
            component.set("v.showDelete", true);
            helper.processFile(fileInput, component, helper);
        }
        // Close the modal
        component.set("v.showModal", false);
    } catch (error) {
        console.error("Error in createNewBill:", error);
    }
},

// onScriptsLoaded: function (component, event, helper) {
//     console.log('Tesseract.js script loaded successfully.');
//     console.log('Tesseract object:', typeof Tesseract !== 'undefined' ? 'Loaded' : 'Not Loaded');
// },


    
 /*// This function is triggered when files are selected
 handleFilesChange: function(component, event, helper) {
    try {
        var fileInput = event.getSource().get("v.files")[0];
        
        if (fileInput) {
            // Show the modal asking whether to alter or create a new bill
            component.set("v.showModal", true);

            // Optionally store the file name to display in the modal
            component.set("v.fileName", fileInput.name);
        } else {
            alert('Please select a valid file.');
        }
    } catch (error) {
        console.error("Error in handleFilesChange:", error);
    }
},

// Close the modal dialog
closeModal: function(component, event, helper) {
    component.set("v.showModal", false); // Hide the modal
},

// This function handles altering the existing bill (adding the file to it)
alterBill: function(component, event, helper) {
    console.log("User chose to alter the existing bill.");

    // Process the file to add it to the existing bill
    var fileInput = event.getSource().get("v.files")[0];
            if (fileInput) {
                component.set("v.showDelete", true);
                helper.processFile(fileInput, component, helper);
            } else {
                alert('Please select a valid file.');
            }
    // Close the modal after processing the file
    component.set("v.showModal", false);
},

// This function handles creating a new bill (resetting the bill items)
createNewBill: function(component, event, helper) {
    console.log("User chose to create a new bill.");

    // Reset the bill items (clear the existing items)
    var billItems = component.get("v.billItems");
    billItems.splice(0, billItems.length); // Clears all bill items
    component.set("v.billItems", billItems); // Update the billItems array

    // Process the file to add it to the new bill
    var fileInput = event.getSource().get("v.files")[0];
            if (fileInput) {
                component.set("v.showDelete", true);
                helper.processFile(fileInput, component, helper);
            } else {
                alert('Please select a valid file.');
            }

    // Close the modal after processing the file
    component.set("v.showModal", false);
}*/
    
})
({
	 showToast : function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent != undefined){
            toastEvent.setParams({
                "mode":"dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }else{
            sforce.one.showToast({
                "title": title,
                "message": message,
                "type": type
            });
        }
        
    },
    
    validation_Check : function (component, event) {
       // component.NOerrors = true;
        var billName = component.find("billName");
        if(!$A.util.isUndefined(billName)) 
             this.checkValidationField(component,billName);
        var vendorAcc = component.find("vendorAccount");
        if(!$A.util.isUndefined(vendorAcc))
             this.checkvalidationLookup(component,vendorAcc);
        var billList = component.find("bill_Items");
        if(!$A.util.isUndefined(billList))
        if(billList.length>0){
            var flag = true;
            for(var x  in billList)
             flag = billList[x].callValidate(); 
            if(!flag && component.NOerrors) component.NOerrors = false;
        }else{
           component.NOerrors = billList.callValidate(); 
        }       
    },
    
    
     saveAtt : function(component,event,file,parentId){
       		var reader = new FileReader();
            reader.onloadend = function() {
                var contents = reader.result;
                var base64Mark = 'base64,';
                var dataStart = contents.indexOf(base64Mark) + base64Mark.length;
                var fileContents = contents.substring(dataStart);
                        
                var action = component.get("c.uploadFile");
                
                action.setParams({
                    parent: parentId,
                    fileName: file.name,
                    base64Data: encodeURIComponent(fileContents),
                    contentType: file.type
                });
                action.setCallback(this, function(response) {
                    if(response.getState() === 'SUCCESS'){
                    }else{
                        console.log('Error :',response.getError());
                    }
                });
                $A.enqueueAction(action); 
            }
            reader.readAsDataURL(file);
    },
    
    
    AnalyticalAccountCheck : function(component, event, helper) {
        var poli = component.get("v.lineItems");
        var arshbool = false;
        for(var x in poli){
            var TotalAmount = 0.00;
            TotalAmount = parseFloat(poli[x].Total_Amount__c); //.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            console.log('TotalAmount~>'+TotalAmount+' typeof ~>'+typeof TotalAmount);
            //if(poli[x].Tax_Amount__c != null && poli[x].Tax_Amount__c != undefined && poli[x].Tax_Amount__c != '') TotalAmount = parseFloat(poli[x].Total_Amount__c - poli[x].Tax_Amount__c);
            //else TotalAmount = poli[x].Total_Amount__c;
            var acc = [];
            console.log('AnalyticalAccountCheck : ',JSON.stringify(poli[x]));
            acc = poli[x].Accounts;
            var accTotal = 0.00;
            if(acc != undefined && acc != null){
                if(acc.length > 0){
                    for(var y in acc){
                        if(acc[y].Allocation_Amount__c != undefined && acc[y].Allocation_Amount__c != null && acc[y].Allocation_Amount__c != ''){
                            if(acc[y].Allocation_Amount__c > 0) accTotal += parseFloat(acc[y].Allocation_Amount__c);
                            console.log('accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                        }
                    }
                    console.log('final 1 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                    console.log('final 2 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    accTotal = parseFloat(accTotal);
                    console.log('final 3 accTotal~>'+accTotal+' typeof ~>'+typeof accTotal);
                    
                    console.log(' item '+x+' and its TotalAmount~>'+TotalAmount+' and its accTotal~>'+accTotal);
                    if(accTotal > TotalAmount){
                        //this.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error','Alanytical Account amount is greater then line item amount for line item '+x);
                        return true;
                    }else if(TotalAmount > accTotal){
                        return true;
                    }
                }
            }
        }
        return arshbool;
    },
    
    AnalyticalAccountCoaCheck : function(component, event, helper) {
        var poli = component.get("v.lineItems");
        var arshbool = false;
        for(var x in poli){
            var acc = [];
            acc = poli[x].Accounts;
             if(acc != undefined && acc != null){
                 if(acc.length > 0){
                     if(poli[x].Chart_Of_Account__c == null || poli[x].Chart_Of_Account__c == undefined || poli[x].Chart_Of_Account__c == '') {
                         return true;
                     }
                     for(var y in acc){
                         if(acc[y].Project__c == null || acc[y].Project__c == undefined || acc[y].Project__c == ''){
                             return true;
                         }
                     }
                 }
             }
        }
        return arshbool;
    },
})
({
    
    doInit : function(component, event, helper){
        console.log('CreateDebitNote cmp doinit');
        var isAttRequired=$A.get("$Label.c.isCreateBillAttRequired");
        if(isAttRequired ==='true'){                    
            component.set("v.isAttRequired",true);
        }else{
            component.set("v.isAttRequired",false);
        }
        if(component.get('v.pId')!=undefined && component.get('v.pId')!=null && component.get('v.pId')!=''){
            
            var pId=component.get('v.pId');
            component.set("v.DebitNote.Purchase_Orders__c", component.get("v.pId"));
            component.set('v.setRT','PO Bill');
            $A.enqueueAction(component.get("c.fetchPoli"));
        }
        
        if(component.get('v.DebitId')!=undefined && component.get('v.DebitId')!=null && component.get('v.DebitId')!=''){
            $A.enqueueAction(component.get("c.fetchDBLine"));
        }
         if(component.get('v.vId') !=undefined && component.get('v.vId') !=null && component.get('v.vId') != ''){
            component.set('v.DebitNote.Account__c',component.get("v.vId"));
        }
        var action = component.get("c.getFunctionalityControlAllocation");	
        action.setCallback(this,function(response){
            if(response.getState()==='SUCCESS'){
                if(response.getReturnValue()){
                    component.set("v.showAllocations", response.getReturnValue());
                }
            }  
        });
        $A.enqueueAction(action); 
    },
    
	fetchPoli : function(component, event, helper) {
        if(!component.get("v.isUpdate")){
        if(component.get("v.DebitNote.Purchase_Orders__c") == ''){
            //component.set("v.DebitNote", '');
            var emp = [];
            component.set("v.lineItems",emp);
        }else{
        var fetchpoliAction = component.get("c.fetch_Polis");
        fetchpoliAction.setParams({"Id":component.get("v.DebitNote.Purchase_Orders__c")});
        fetchpoliAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var resultList = response.getReturnValue();
                if(resultList.length > 0){
                    var po = JSON.parse(resultList[0]);
                    component.set("v.DebitNote.Account__c", po.Vendor__c);
                    //component.set("v.Bill.Vendor_Contact__c", po.Vendor_Contact__c);
                    //component.set("v.Bill.Vendor_Address__c", po.Vendor_Address__c);
                    //alert('PO Org : ' +po.Company__c);
                    component.set("v.DebitNote.Company__c", po.Company__c);
                    var poliList = JSON.parse(resultList[1]);
                    console.log('updatedPoli::~>',poliList);
                    var billingQty = JSON.parse(resultList[2]);
                    //alert(JSON.parse(resultList[3]));
                    if(resultList.length>3) var dimeList = JSON.parse(resultList[3]);
                    //alert('1==>'+JSON.stringify(poliList));
                    if(!$A.util.isEmpty(poliList)){
                        
                        var billList = [];//component.get("v.billItems");
                        for(var x in poliList){
                            for(var y in billingQty){
                                if(x == y){
                                    var poliAcc = [];
                                    if(dimeList != undefined && dimeList != null && resultList.length>3){
                                        for(var y in dimeList){
                                            if(poliList[x].Id == dimeList[y].Purchase_Line_Items__c){
                                                dimeList[y].Id = null;
                                                poliAcc.push(dimeList[y]);
                                            }
                                        }
                                    }
                                    if(poliList[x].Product__r.Track_Inventory__c){
                                        var obj = {Chart_Of_Account__c:poliList[x].Product__r.Inventory_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c, Sort_Order__c:poliList[x].Sort_Order__c
                                                   ,Other_Tax__c:0.00,Description__c:poliList[x].Description__c, Accounts : poliAcc
                                                  };
                                        billList.push(obj);
                                    }else if(poliList[x].Product__r.Is_Asset__c){
                                        var obj = {Chart_Of_Account__c:poliList[x].Product__r.Asset_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c, Sort_Order__c:poliList[x].Sort_Order__c
                                                   ,Other_Tax__c:0.00,Description__c:poliList[x].Description__c, Accounts : poliAcc
                                                  };
                                        billList.push(obj);
                                    }else{
                                        var obj = {Chart_Of_Account__c:poliList[x].Product__r.Expense_Account__c,Item_Type__c:'Item',Name:poliList[x].Name,Product__c:poliList[x].Product__c,Quantity__c:billingQty[y],Amount__c:poliList[x].Unit_Price__c,Item_Description__c:poliList[x].Special_Instruction__c, Purchase_Order_Line_Items__c:poliList[x].Id,Discount__c:0.00,Tax_Amount__c:poliList[x].Tax__c, Sort_Order__c:poliList[x].Sort_Order__c
                                                   ,Other_Tax__c:0.00,Description__c:poliList[x].Description__c, Accounts : poliAcc
                                                  };
                                        billList.push(obj);
                                    }
                                    
                                }
                            }
                        }     
                        component.set("v.lineItems",billList);
                        //component.set("v.Bill.Discount_Amount__c",0);
                        //helper.calculateAdvBill(component,event);
                    }else{
                        helper.showToast($A.get('$Label.c.PH_Warning'),'warning',$A.get('$Label.c.PH_Bill_Has_Already_Been_Created'));
                        setTimeout(
                            $A.getCallback(function() {
                                $A.enqueueAction(component.get("c.cancelclick"));
                            }), 3000
                        );
                        
                    }
                }
            }  
        });
        $A.enqueueAction(fetchpoliAction);
        }
       /* var action2=component.get("c.uploadFile");
        action2.setParams({
            "pid" : component.get("v.Bill.Purchase_Order__c")
        });
        action2.setCallback(this, function(response){
            var state = response.getState();
            if( state === "SUCCESS" ){
                 component.set("v.fileName",response.getReturnValue().Name);
                component.set("v.Attach",response.getReturnValue());
                
            }
        });
        $A.enqueueAction(action2);*/
        }
    },
    
    
    fetchDBLine : function(component, event, helper) {
        var fetchpoliAction = component.get("c.fetch_deblis");
        fetchpoliAction.setParams({"Id":component.get("v.DebitId")});
        fetchpoliAction.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                var resultList = response.getReturnValue();
                if(resultList.length > 0){
                    var po = JSON.parse(resultList[0]);
                    component.set("v.DebitNote", po);
                    var poliList = JSON.parse(resultList[1]);
                    if(!$A.util.isEmpty(poliList)){
                        component.set("v.lineItems",poliList);
                        var dimeList = [];
                        if(resultList.length>1){
                            dimeList = JSON.parse(resultList[2]);
                            for(var x in poliList){
                                var poliAcc = [];
                                for(var y in dimeList){
                                    if(poliList[x].Id == dimeList[y].Debit_Note_Item__c){
                                        poliAcc.push(dimeList[y]);
                                    }
                                }
                                poliList[x].Accounts = poliAcc;
                            }
                            component.set("v.lineItems",poliList);
                        }
                    }else{
                        /*helper.showToast('!Warning','warning','Bill Has Already Been Created');
                        setTimeout(
                            $A.getCallback(function() {
                                $A.enqueueAction(component.get("c.cancelclick"));
                            }), 3000
                        );*/
                        
                    }
                }
            }  
        });
        $A.enqueueAction(fetchpoliAction);
    },
    
    
    
    
                          
    /*updateTotalDiscount : function(c, e, h){
        var items=c.get('v.billItems');
        if($A.util.isUndefined(items.length)){
            var dis=items.Discount__c;
            c.set("v.Bill.Discount_Amount__c",dis);
        }else{
               var dis=0;
               for(var x in items){
                   if(items[x].Discount__c!=undefined && items[x].Discount__c!=''){
                     var discount = items[x].Discount__c;
                     dis=dis+discount*1;   
                   }
                  
               }
            c.set("v.Bill.Discount_Amount__c",dis);
        }
     },*/ 
    updateTotalTax : function(c, e, h){
        var items=c.get('v.lineItems');
        if(items.Tax_Rate__c==undefined)items.Tax_Rate__c=0;
        if(items.Other_Tax_Rate__c==undefined)items.Other_Tax_Rate__c=0;
        if(items.Quantity__c==undefined)items.Quantity__c=0;
        if(items.Amount__c==undefined)items.Amount__c=0;
         for(var x in items){
                   if(items[x].Amount__c==undefined)items[x].Amount__c=0;
                   if(items[x].Other_Tax_Rate__c==undefined)items[x].Other_Tax_Rate__c=0;
                   if(items[x].Tax_Rate__c==undefined)items[x].Tax_Rate__c=0;
                   if(items[x].Quantity__c==undefined)items[x].Quantity__c=0;
         }
        if($A.util.isUndefined(items.length)){
            var tax=((items.Total_Amount__c)/100)*items.Tax_Rate__c;
            var OTtax=(items.Amount__c/100)*items.Other_Tax_Rate__c;
            var totalTax=(tax+OTtax)*items.Quantity__c;
             c.set("v.DebitNote.Tax_Amount__c",totalTax);
        }else{
               var totaltax=0;
               var tax = 0;
               var OTtax = 0;
               for(var x in items){
                   tax = items[x].Tax_Amount__c;
                   OTtax =(items[x].Amount__c/100)*items[x].Other_Tax_Rate__c;
                   totaltax+=tax+OTtax;
               }
            c.set("v.DebitNote.Tax_Amount__c",totaltax);
           }
     },
    updateTotalPrice: function(c, e, h) {
       var items=c.get('v.lineItems');
        if($A.util.isUndefined(items.length)){
            var amt=items.Quantity__c * items.Amount__c;
            c.set("v.DebitNote.Amount__c",amt);
        }else{
               var amt=0;
               for(var x in items){
                  amt+=items[x].Quantity__c * items[x].Amount__c 
               }
            c.set("v.DebitNote.Amount__c",amt);
        }
        
       },
    

    UpdateTDS : function(c, e, h){
        
    },
    
    
    goBack : function(component, event, helper) {
        history.back();
    },
    
    
    addNew : function(component, event, helper) {
        var billList = component.get("v.lineItems");
        billList.unshift({sObjectType :'Debit_Note_Item__c'});
        component.set("v.lineItems",billList);
    },
    
    
    saveBill : function(component, event, helper) {
        var billList = component.get("v.lineItems");
        var Billobj = component.get("v.DebitNote");
        
        //alert('Bill=>'+JSON.stringify(component.get("v.Bill")));
        //Billobj.Vendor_Contact__r = null;
        //Billobj.Vendor_Address__r = null;
        Billobj.Purchase_Orders__r = null;
        Billobj.Posted__c = component.get('v.setBillPost');
        
        var totalAmount=parseFloat(Billobj.Amount__c);
        
        
       component.NOerrors =  true;
        //helper.validation_Check(component,event);
        
        if(component.NOerrors){
            var showError=false;
            if(component.get("v.DebitNote.Credit_Note_Number__c")=='' || component.get("v.DebitNote.Credit_Note_Number__c")==undefined || component.get("v.DebitNote.Credit_Note_Number__c")==null){
                showError = true;
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH7_DebNote_Please_Enter_the_Debit_Note_Number'));
            }
            /*if(billList.length>0 && !(showError)){
                for(var a in billList ){
                    if(billList[a].Chart_Of_Account__c=='' || billList[a].Chart_Of_Account__c==null
                       || billList[a].Chart_Of_Account__c==undefined){
                        showError=true;
                        var po=component.get('v.DebitNote.Purchase_Orders__c');
                        if(po!=null && po!='' && po!=undefined)helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_Select_the_account_for_all_line_items'));
                        else helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_Select_the_expense_account_for_all_line_items'));
                    }
                }
            }*/
            var fillList11=component.get("v.fillList");
            if(component.get("v.isAttRequired") && (component.find("fileId").get("v.files")==null || fillList11.length == 0) && component.get('v.setRT')!='Advance to vendor' && !(showError)){
                helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Debit_Note_Attachment_is_missing'));
                return;
            }
            var isErrorsAA = helper.AnalyticalAccountCheck(component, event, helper); 
        	var isErrorsAACOA = helper.AnalyticalAccountCoaCheck(component, event, helper); 
            if(billList.length>0 && !(showError)){
                if(!isErrorsAA &&!isErrorsAACOA){
                    var dimensionList = [];
                    try{
                        
                        for(var x in billList){
                            if(billList[x].Accounts != undefined && billList[x].Accounts != null){
                                if(billList[x].Accounts.length > 0){
                                    for(var y in billList[x].Accounts){
                                        if(billList[x].Accounts[y].Sort_Order__c != undefined && billList[x].Accounts[y].Sort_Order__c != null){
                                            console.log('before poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                            billList[x].Accounts[y].Sort_Order__c = parseInt(parseInt(x)+1);
                                            console.log('after poLIst['+x+'].Accounts['+y+'].Sort_Order__c ~>'+billList[x].Accounts[y].Sort_Order__c);
                                        }
                                    }
                                    dimensionList.push(billList[x].Accounts);
                                }
                            }
                        }
                        console.log('dimensionList : ',dimensionList);
                        
                        for(var x in billList){
                            if(billList[x].Accounts != undefined && billList[x].Accounts != null) billList[x].Accounts = [];
                        }
                    }catch(e){
                        console.log('arshad err,',e);
                    }
                component.set("v.showMmainSpin",true);
                var saveAction = component.get("c.save_Bill");
                let jsonBill  = JSON.stringify(Billobj);
                let jsonBillItems = JSON.stringify(billList);
                var RTName;
                if(component.get('v.setRT')=='PO Bill')RTName='PO_Bill';
                if(component.get('v.setRT')=='Expense Bill')RTName='Expense_Bill';
                if(component.get('v.setRT')=='Advance to vendor')RTName='Advance_to_vendor';
               
                saveAction.setParams({"Bill": jsonBill, "BillItems" :jsonBillItems,RTName:RTName,});
                saveAction.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){ 
                    
                    var result = response.getReturnValue();
                    //if(!$A.util.isUndefined(result)){
                    var bilobj = result['bill']; 
                    component.set("v.BillId",bilobj.Id);
                    if(component.get('v.setRT')=='PO Bill' || component.get('v.setRT')=='Expense Bill' || component.get('v.setRT')=='Advance to vendor'){
                        if(component.find("fileId").get("v.files")!=null){
                            
                            if (component.find("fileId").get("v.files").length > 0 && fillList11.length > 0) {                                
                                var fileInput = component.get("v.FileList");
                                for(var i=0;i<fileInput.length;i++)
                                    helper.saveAtt(component,event,fileInput[i],bilobj.Id);
                            }
                        }
                    if(component.get("v.Attach")!=null){
                        //var Body = EncodingUtil.base64Encode(component.get("v.Attach.Body"));
                        //var =;
                        
                         var Billobj = component.get("v.BillId");
                        var action=component.get("c.save_attachment2");
                    action.setParams({"parentId": Billobj,"Pid":component.get("v.Bill.Purchase_Order__c"), 
                      });
                      action.setCallback(this,function(response){
                          if(response.getState() === 'SUCCESS'){
                          }
                      });
                     $A.enqueueAction(action);
                    }
                    
                    }
                       if(!$A.util.isUndefinedOrNull(result['error'])) {
                            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',result['error']);
                           	component.set("v.showMmainSpin",false);
                            return ;
                        }
                    
                    	if(dimensionList.length > 0){
                                    try{
                                        var action2=component.get("c.createDimensionsList");
                                        action2.setParams({'AA':JSON.stringify(dimensionList), 'DId':component.get("v.BillId")});
                                        action2.setCallback(this,function(response){
                                            if(response.getState() === "SUCCESS"){
                                                //component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
                                                //component.set("v.currencyList",response.getReturnValue().currencyList);
                                            }else{
                                                var errors = response.getError();
                                                console.log("server error in dimelist : ", JSON.stringify(errors));
                                            } 
                                        });
                                        $A.enqueueAction(action2);
                                    }catch(e){
                                        console.log('arshad err 2,',e);
                                    }
                                }
                    
                        if(component.get("v.isUpdate")) helper.showToast($A.get('$Label.c.Success'),'success', $A.get('$Label.c.PH_DebNote_Debit_Note_Updated_Successfully'));
                        else helper.showToast($A.get('$Label.c.Success'),'success', $A.get('$Label.c.PH_DebNote_Debit_Note_Created_Successfully'));
                        //component.set("v.showLoadingSpinner", false);
                        if(component.get("v.navigateToRecord")){
                            var navEvt = $A.get("e.force:navigateToSObject");
                            if(navEvt != undefined){
                                var url = '/'+result['bill'].Id;
                                window.location.replace(url);
                                /*navEvt.setParams({
                                    "isredirect": true,
                                    "recordId": result['bill'].Id,
                                    "slideDevName": "detail"
                                }); 
                                navEvt.fire();*/
                            }else {
                                var selectedBillList=[];
                                selectedBillList.push(result['bill'].Id);
                                //location.reload();
                                var url = '/'+result['bill'].Id;
                                window.location.replace(url);
                                //window.open(url,"__self");
                                /*var evt = $A.get("e.force:navigateToComponent");
                                evt.setParams({
                                    componentDef : "c:Accounts_Payable",
                                    componentAttributes: {
                                        "selectedTab" : 'Purchase_Orders',
                                        "setSearch" : 'a1J1o000008OCla'
                                    }
                                });
                                evt.fire();  */
                                
                                /*$A.createComponent(
                                    "c:Accounts_Payable", { 
                                        "showTabs":'Purchase_Orders',
                                        "setSearch" : 'a1J1o000008OCla',
                                    },
                                    function(newComp) {
                                        var content = component.find("body");
                                        content.set("v.body", newComp);
                                    }
                                );	*/  
                            }
                        }else{
                            /*var params = event.getParam('arguments');
                            var callback;
                            if (params) {
                                callback = params.callback;
                            }
                            if (callback) callback(response.getReturnValue());*/
                            /*var selectedBillList=[];
                                var result = response.getReturnValue(); 
                                var bilobj = result['bill2'];
                            var evt = $A.get("e.force:navigateToComponent");
                                evt.setParams({
                                    componentDef : "c:Accounts_Payable",
                                    componentAttributes: {
                                        "selectedTab" : 'Bills',
                                        "setSearch" : bilobj.Name,
                                    }
                                });
                                evt.fire(); */
                            	var url = '/'+result['bill'].Id;
                                window.location.replace(url);
                        }
                    } 
                });
               $A.enqueueAction(saveAction);
               }else{
                    var errorMessage = '';
                    if(isErrorsAACOA){
                        errorMessage = 'Please select the Accounting Account and Analytical Account.';
                    }else if(isErrorsAA){
                        errorMessage = 'Total Analytical Account amount of an item cannot be greater or lesser then line item total amount.';
                    }
                    helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',errorMessage);
                } 
            }else{
                if(!showError)helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item'));
            } 
        }else{
            helper.showToast($A.get('$Label.c.Error_UsersShiftMatch'),'error',$A.get('$Label.c.PH_DebNote_Review_All_Errors'));
        }
    },
    
     handleFilesChange: function(component, event, helper) {
        component.set("v.showDelete",true);
        var fileName = 'No File Selected..';
        //var files = component.get("v.FileList");  
        
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            var fileItem = [];
            for(var i=0;i<event.getSource().get("v.files").length;i++){
                fileItem.push(event.getSource().get("v.files")[i]['name']);
            }
        }
        //alert(fileItem);
        component.set("v.fillList",fileItem);
        component.set("v.fileName", fileName);
    },
    
     removeAttachment : function(component, event, helper) {
        component.set("v.showDelete",false);
        var fileName = 'No File Selected..';
        component.set("v.fileName", fileName);
        //component.set('v.fillList',null);
        
        var fillList=component.get("v.fillList");
        fillList.splice(0, fillList.length); 
        component.set("v.fillList",fillList);
        /*for(var i in fillList){
            fillList[i].po
        }*/
    },
    
    deleteLineItem : function(component, event, helper) {
       var billList = component.get("v.lineItems");
        billList.splice(event.getParam("Index"),1);
        component.set("v.lineItems",billList);
    },
    
})
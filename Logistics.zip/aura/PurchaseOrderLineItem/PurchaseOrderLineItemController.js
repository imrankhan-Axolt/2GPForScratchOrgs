({
    getPrice: function (component, event, helper) {
        try {
            // component.find() 

            if (component.get("v.getPriceBool") == true) {
                var action = component.get("c.fetchPrice");
                if (component.get("v.item.Cost_Card__c") != undefined && component.get("v.item.Cost_Card__c") != null && component.get("v.item.Cost_Card__c") != '') {

                    action.setParams({
                        "ccId": component.get("v.item.Cost_Card__c")
                    });
                    action.setCallback(this, function (response) {
                        var state = response.getState();
                        if (component.isValid() && state === "SUCCESS") {
                            if (response.getReturnValue() != null) {
                                var res = response.getReturnValue().costcard;
                                var multiCurrencyEnabled = response.getReturnValue().multiCurrencyEnabled;
                                if (res != null) {
                                    if (multiCurrencyEnabled) component.set("v.item.CurrencyIsoCode", res.CurrencyIsoCode);
                                    component.set('v.alloweditPrice', response.getReturnValue().editUnitPrice);
                                    console.log('res.editUnitPrice : ', response.getReturnValue().editUnitPrice);
                                    //if(res.Quantity__c >= 0) component.set("v.item.Quantity__c",res.Quantity__c); 
                                    if (res.Cost__c >= 0) component.set("v.item.Unit_Price__c", res.Cost__c);
                                    var totalPrice = 0.00;
                                    component.set("v.item.Tax_Rate__c", component.get("v.DefTaxRate"));
                                    //var totalPrice= parseFloat(component.get("v.item.Quantity__c")) * parseFloat(component.get("v.item.Unit_Price__c")); 
                                    if (res.Cost__c >= 0 && component.get("v.item.Quantity__c") >= 0) totalPrice = res.Cost__c * component.get("v.item.Quantity__c");
                                    var taxAmount = (component.get("v.item.Tax_Rate__c") * totalPrice) / 100;
                                    component.set("v.item.Tax__c", taxAmount.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
                                    if (component.get("v.item.Tax__c") != null && component.get("v.item.Tax__c") != '' && component.get("v.item.Tax__c") != undefined) totalPrice = totalPrice;// + taxAmount.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                                    component.set("v.item.Cost_Card__c", component.get("v.item.Cost_Card__c"));
                                    var totAmount = 0.00;
                                    totAmount = parseFloat(totalPrice.toFixed($A.get("$Label.c.DecimalPlacestoFixed"))) + parseFloat(taxAmount.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
                                    component.set("v.item.Total_Price__c", totAmount);
                                    component.set("v.item.Vendor_product_Name__c", res.Vendor_Part_Number__c);

                                }
                                //component.set("v.getPriceBool",'false');          
                            } else {
                                //('getPrice response  null');
                            }

                        }
                        else {
                            //('getPrice Exception Occured');  
                        }
                    });
                    $A.enqueueAction(action);
                }
            }

        } catch (e) { console.log('err~>' + e); }
    },

    getCategory: function (component, event, helper) {
        //component.set("v.displayAccount", false);
        var TotalAAPercentage = 0;
        if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
            if (component.get("v.item.Accounts.length") > 0) {
                var itemAccs = component.get("v.item.Accounts");
                for (var i in itemAccs) {
                    if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                        if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                    }
                }
            }
        }
        component.set("v.TotalAAPercentage", TotalAAPercentage);
        let poStatus = component.get("c.getCategoryList");
        poStatus.setCallback(this, function (response) {
            let resList = response.getReturnValue();
            let resListupdated = [];
            for (var i in resList) {
                if (i != 0) resListupdated.push(resList[i]);
            }
            component.set("v.PoliCategoryList", resListupdated);
            $A.util.addClass(component.find('mainSpin'), "slds-hide");
        });
        $A.enqueueAction(poStatus);
        /*setTimeout(
            $A.getCallback(function() {
                component.set("v.displayAccount", true);
            }), 3000
        );*/
    },

    getCostCard: function (component, event, helper) {
        try {
            var action = component.get("c.fetchCostCardIds");
            action.setParams({
                "vendorId": component.get("v.vendorId")
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    if (response.getReturnValue() != null) component.set("v.costCardIds", response.getReturnValue()); //item.Cost_Card__c         
                }
            });
            $A.enqueueAction(action);
        } catch (e) { console.log('err~>' + e); }
    },

    getProductCC: function (component, event, helper) {
        try {
            if ($A.util.isEmpty(component.get("v.item"))) {
                if ($A.util.isEmpty(component.get("v.item.Product__c")) || $A.util.isUndefinedOrNull(component.get("v.item.Product__c"))) {
                    if (component.get("v.item.Cost_Card__c") != undefined)
                        component.set("v.item.Cost_Card__c", null);
                    if (component.get("v.item.Description__c") != undefined)
                        component.set("v.item.Description__c", '');
                    if (component.get("v.item.Name") != undefined)
                        component.set("v.item.Name", '');
                    if (component.get("v.item.Quantity__c") != undefined)
                        component.set("v.item.Quantity__c", '');
                    if (component.get("v.item.Unit_Price__c") != undefined)
                        component.set("v.item.Unit_Price__c", '');
                    if (component.get("v.item.Total_Price__c") != undefined)
                        component.set("v.item.Total_Price__c", '');
                }
            }
            else {
                var action = component.get("c.fetchProductCC");
                action.setParams({
                    "vendorId": component.get("v.vendorId"),
                    "productId": component.get("v.item.Product__c")
                });
                action.setCallback(this, function (response) {
                    var state = response.getState();
                    if (component.isValid() && state === "SUCCESS") {
                        if (response.getReturnValue() != null) {
                            component.set("v.item.Cost_Card__c", response.getReturnValue().Id);
                        }
                        else component.set("v.item.Cost_Card__c", null);
                    }
                });
                $A.enqueueAction(action);
                if (component.get("v.item.Description__c ") == null || component.get("v.item.Description__c ") == '' || component.get("v.item.Description__c ") == undefined) {
                    var action = component.get("c.fetchProductDesc");
                    action.setParams({ "productId": component.get("v.item.Product__c") });
                    action.setCallback(this, function (response) {
                        var state = response.getState();
                        if (component.isValid() && state === "SUCCESS") {
                            if (response.getReturnValue() != null) {
                                component.set("v.item.Description__c", response.getReturnValue().Vendor_Supplier_Description__c);
                                if (response.getReturnValue().BOM__c != null) component.set("v.item.BOM__c", response.getReturnValue().BOM__c);
                                var Name = response.getReturnValue().Name;
                                console.log('Name : ', Name, ' Length : ', Name.length);
                                if (Name.length >= 80) {
                                    var trimmedString = Name.substring(0, 79);
                                    console.log('trimmedString : ', trimmedString);
                                    component.set("v.item.Name", trimmedString);
                                }
                                else {
                                    component.set("v.item.Name", response.getReturnValue().Name);
                                }

                                if (component.get("v.item.Vendor_product_Name__c ") == null || component.get("v.item.Vendor_product_Name__c ") == '' || component.get("v.item.Vendor_product_Name__c ") == undefined) component.set("v.item.Vendor_product_Name__c", response.getReturnValue().Vendor_product_Name__c);

                            }
                        }
                    });
                    $A.enqueueAction(action);
                }
            }
        } catch (e) { console.log('err~>' + e); }
    },

    setccList: function (component, event, helper) {
        component.find("costCard").set("v.listOfSearchRecords", component.get("v.costCardIds"));
    },

    updateTotalPrice: function (component, event, helper) {
        try {
            console.log('updateTotalPrice poli called');
            var qty = (!$A.util.isEmpty(component.get("v.item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Quantity__c"))) ? component.get("v.item.Quantity__c") : 0;
            var unitprice = (!$A.util.isEmpty(component.get("v.item.Unit_Price__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Unit_Price__c"))) ? component.get("v.item.Unit_Price__c") : 0;
            var taxamt = (!$A.util.isEmpty(component.get("v.item.Tax__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Tax__c"))) ? component.get("v.item.Tax__c") : 0;

            var val = parseFloat(qty * unitprice) + parseFloat(taxamt);
            if (val != undefined && val != null) {
                if (val > 0) val = val.toFixed($A.get("$Label.c.DecimalPlacestoFixed")); else val = 0;
            } else val = 0;
            component.set("v.item.Total_Price__c", val);
            component.set("v.item.Tax_Rate__c", component.get("v.DefTaxRate"));
            component.set("v.TotalPrice", val);
            var cmpqty = component.find("qty");
            if (!$A.util.isUndefined(cmpqty)) helper.validateCheck(cmpqty);
            /*var price = component.find("amount");
        if (!$A.util.isUndefined(price))
            helper.validateCheck(price);*/
            helper.ValidateQuantity(component, event, helper);
            /* if(component.get("v.item.Total_Price__c") != '' && component.get("v.item.Total_Price__c") != null && component.get("v.item.Total_Price__c") != undefined){
            if(component.get("v.item.Total_Price__c") > 0){
                //do nothing
            }else component.set("v.item.Accounts",[]); 
        }else component.set("v.item.Accounts",[]); */
            $A.enqueueAction(component.get("c.UpdateTax"));
        } catch (e) { console.log('updateTotalPrice err~>' + e); }
    },

    deletePoli: function (component, event, helper) {

        //var itemToDel=component.get('v.itemToDel');
        var currtItem = event.getSource().get('v.title');
        //if(currtItem != null) itemToDel.push(currtItem);
        //component.set('v.itemToDel',itemToDel);
        console.log('currtItem:', currtItem);
        console.log('Index:', component.get("v.index"));
        try {
            console.log('try1');
            var e = $A.get("e.c:RequisitionToPurchaseOrderEvent"); //  component.getEvent("ExpertServiceEvent");                                                       
            console.log('try2');
            e.setParams({
                "Index": component.get("v.index"),
                "itemToDelCurr": currtItem
            });
            console.log('try3');
            e.fire();
            console.log('try4');
        } catch (ex) { console.log('catch:', ex); }
        console.log('out1');
        component.set("v.Tax", 0);
        console.log('out2');
    },

    validate: function (component, event, helper) {
        var NoErrors = true;
        var cmpqty = component.find("qty");
        if (!$A.util.isUndefined(cmpqty))
            NoErrors = helper.validateCheck(cmpqty);
        var price = component.find("amount");
        if (!$A.util.isUndefined(price))
            NoErrors = helper.validateCheck(price);

        /*var productField = component.find("product");
        if (!$A.util.isUndefined(productField))
            NoErrors = helper.checkvalidationLookup(productField);*/
        return NoErrors;
    },

    lookupClickCostCard: function (cmp, helper) {
        try {
            var pro = cmp.get("v.item.Product__c");
            var ven = cmp.get("v.vendorId");

            var qry = ' ';
            if (pro != undefined && pro != '') qry = 'And Product__c = \'' + pro + '\'';
            if (ven != undefined && ven != '') qry += ' AND Supplier__c =\'' + ven + '\'';
            qry += ' AND Cost__c >\=\ 0    And Active__c = true And Quantity__c >\=\ 0 And Minimum_Quantity__c >\=\ 0 And Start_Date__c <\=\ TODAY And End_Date__c >\=\ TODAY';
            //alert(qry);
            cmp.set("v.qry", qry);
        } catch (e) { console.log('err~>' + e); }
    },

    lookupClickProduct: function (cmp, helper) {
        try {
            var ven = cmp.get("v.vendorId");
            var filerbaseOnven = $A.get("$Label.c.Show_Vendor_Product_Name");
            console.log('filerbaseOnven : ', filerbaseOnven);
            var qry = ' ';
            if (ven != undefined && ven != '' && filerbaseOnven) qry += ' AND (Default_Vendor__c =\'' + ven + '\' OR Default_Vendor__c = \'\' )';
            //if(filerbaseOnven) qry += ' AND Issue_Manufacturing_Order__c = false ';
            qry += ' AND Issue_Purchase_Order__c = true ';
            //qry += 'OR Default_Vendor__c = \'\' ';
            cmp.set("v.prodqry", qry);
            console.log('prodqry : ', qry);
        } catch (e) { console.log('err~>' + e); }
    },

    getstockdetails: function (cmp, helper) {
        try {
            var obj = cmp.get('v.item');
            console.log('obj : ' + JSON.stringify(obj));
            var currprod = cmp.get('v.item.Product__c');
            console.log('currprod : ' + currprod);
            console.log('Dc : ' + cmp.get('v.dCId'));
            if (currprod != '' && currprod != null && cmp.get('v.dCId') != '' && cmp.get('v.dCId') != null) {
                let defaultcc;
                if (cmp.get('v.vendorId') != null && cmp.get('v.vendorId') != '' && cmp.get('v.vendorId') != undefined) defaultcc = { 'Product__c': currprod, 'Supplier__c': cmp.get('v.vendorId') };
                else defaultcc = { 'Product__c': currprod };
                cmp.set('v.defaultCCval', defaultcc);
                console.log('defaultCCval : ' + cmp.get('v.defaultCCval'));
                var action = cmp.get('c.getstocks');
                action.setParams({ 'DCId': cmp.get('v.dCId'), 'ProductId': currprod });
                action.setCallback(this, function (response) {
                    let resList = response.getReturnValue();
                    console.log('response : ' + JSON.stringify(resList));
                    if (currprod == resList.Product) {
                        cmp.set('v.item.ItemsinStock', resList.Stock);
                        cmp.set('v.item.demand', resList.Demand);
                        cmp.set('v.item.AwaitingStock', resList.AwaitingStocks);
                    }
                    //component.set("v.POStatusoptions",resList);                
                    //$A.util.addClass(component.find('mainSpin'), "slds-hide");            
                });
                $A.enqueueAction(action);
            }
        } catch (e) { console.log('err~>' + e); }
    },

    /*getvencostcard :function(component, helper) {
        var pro = component.get("v.item.Product__c");
        var approveven = component.get('v.approvedVendor');
        if(approveven!= null){
            var action = component.get("c.fetchvenCC");
        
        action.setParams({
            "vendorId": approveven,
            "productId": pro
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (component.isValid() && state === "SUCCESS") {
                if(response.getReturnValue() != null){   component.set("v.item.Cost_Card__c", response.getReturnValue().Id);   
                }
                else component.set("v.item.Cost_Card__c",'');
            } 
        });
        $A.enqueueAction(action);
            
        }
    },*/

    /* lookupClickApprover : function (component,event){
        var pro = component.get("v.item.Product__c");
        var cc = component.get("v.item.Cost_Card__c");
        var qry= ' ';
        if (pro != undefined && pro != '') qry +=  'AND Product__c = \''+ pro +'\' ';
        if(cc != undefined && cc != '') qry += 'AND Cost_Card__c = \''+ cc +'\'';
        component.set('v.venqry',qry);
    }*/

    /* start :function (cmp,event){
        var row = event.currentTarget;
        cmp.set('v.row',row);
    },
    dragover: function(cmp,event){
        var e = event;
        e.preventDefault();
        
        var row=cmp.get('v.row');
        let children= Array.from(e.target.parentNode.parentNode.children);
        if(children.indexOf(e.target.parentNode)>children.indexOf(row))
            e.target.parentNode.after(row);
        else
            e.target.parentNode.before(row);
    },*/

    UpdateTax: function (component, event, helper) {
        try {
            var qty = (!$A.util.isEmpty(component.get("v.item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Quantity__c"))) ? component.get("v.item.Quantity__c") : 0;
            var unitprice = (!$A.util.isEmpty(component.get("v.item.Unit_Price__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Unit_Price__c"))) ? component.get("v.item.Unit_Price__c") : 0;
            var taxamt = 0;
            var taxrate = (!$A.util.isEmpty(component.get("v.item.Tax_Rate__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Tax_Rate__c"))) ? component.get("v.item.Tax_Rate__c") : 0;

            if (taxrate > 0 && unitprice > 0) taxamt = parseFloat((unitprice / 100) * taxrate).toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
            if (qty > 0 && taxamt > 0) taxamt = parseFloat(taxamt * qty).toFixed($A.get("$Label.c.DecimalPlacestoFixed")); else taxamt = 0;
            console.log('taxamt ~>' + taxamt + ' typeof~>' + typeof taxamt);

            component.set("v.item.Tax__c", taxamt);
            console.log('v.item.Tax__c set here~>' + component.get("v.item.Tax__c"));

            component.set("v.Tax", parseFloat((unitprice * taxrate) / 100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            console.log('v.Tax set here~>' + component.get("v.Tax"));

            console.log('parseFloat(qty * unitprice)~>' + parseFloat(qty * unitprice));

            var totalPrice = parseFloat(qty * unitprice) + parseFloat(taxamt);
            console.log('totalPrice ~>' + totalPrice + ' typeof~>' + typeof totalPrice);
            if (totalPrice != undefined && totalPrice != null) {
                if (totalPrice > 0) totalPrice = totalPrice.toFixed($A.get("$Label.c.DecimalPlacestoFixed")); else totalPrice = 0;
            } else totalPrice = 0;

            component.set("v.item.Total_Price__c", totalPrice);
            console.log('v.item.Total_Price__c set here~>' + component.get("v.item.Total_Price__c"));

            /*
            var item = component.get("v.item");
            if(item.Tax_Rate__c == undefined) component.set("v.item.Tax_Rate__c",0); //item.Tax_Rate__c=0;
            if(item.Quantity__c == undefined) component.set("v.item.Quantity__c",0);//item.Quantity__c=0;
            var tax=0; 
            item = component.get("v.item");
            if(item.Tax_Rate__c != 0) tax = (item.Unit_Price__c/100)*item.Tax_Rate__c;
            tax=tax*item.Quantity__c;
            try{ console.log('v.item.Tax__c changes here2 ~>'+tax); }catch(e){}
            var OTtax=0;
            var totalTax=tax+OTtax;
            item.Tax__c = (tax > 0) ? tax.toFixed($A.get("$Label.c.DecimalPlacestoFixed")) : tax;
            try{ console.log('v.item.Tax__c changes here3 ~>'+tax.toFixed($A.get("$Label.c.DecimalPlacestoFixed"))); }catch(e){}
            component.set("v.item.Tax__c",tax.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            console.log('cmp v.item.Tax__c~>'+component.get("v.item.Tax__c"));
            //item.Total_Amount__c = item.Amount__c + item.Tax_Amount__c;
            //component.set("v.item",item);
            console.log('item.Unit_Price__c after: '+component.get("v.item.Unit_Price__c"));
            //component.set("v.Tax",totalTax);
            var rate=component.get("v.item.Tax_Rate__c");
            var Amount=component.get("v.item.Unit_Price__c");
            //component.set("v.Tax_Amount",((Amount*rate)/100).toFixed(3));
            //var rate2=component.get("v.Item.Other_Tax_Rate__c");
            //component.set("v.Other_Tax_Amount",(Amount*rate2)/100);
            //var value=component.get("v.Tax_Amount");
            //var value2=component.get("v.Other_Tax_Amount");
            component.set("v.Tax",((Amount*rate)/100).toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            var amount=component.get("v.item.Unit_Price__c")*component.get("v.item.Quantity__c");
            var tax=component.get("v.item.Tax__c");
            var totalPrice = amount+tax; 
            component.set("v.item.Total_Price__c",totalPrice.toFixed($A.get("$Label.c.DecimalPlacestoFixed")));
            */
            /* if(component.get("v.item.Total_Price__c") != '' && component.get("v.item.Total_Price__c") != null && component.get("v.item.Total_Price__c") != undefined){
            if(component.get("v.item.Total_Price__c") > 0){
                //do nothing
            }else component.set("v.item.Accounts",[]); 
        }else component.set("v.item.Accounts",[]);  */
            $A.enqueueAction(component.get("c.updateACTaxAmount"));
        } catch (e) { console.log('UpdateTax err~>' + e); }
    },

    displayAccounts: function (component, event, helper) {
        try {
            var TotalAAPercentage = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage);

            console.log('arshad TotalAAPercentage~>' + component.get("v.TotalAAPercentage") + ' typeof~>' + typeof component.get("v.TotalAAPercentage"));
            var remainingTotalAAPercent = parseFloat(100 - component.get("v.TotalAAPercentage"));
            console.log('arshad remainingTotalAAPercent~>' + remainingTotalAAPercent + ' typeof~>' + typeof remainingTotalAAPercent);

            component.set("v.displayAccount", true);
            var poliList = [];
            var polList = [];
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) polList = component.get("v.item.Accounts");
            console.log('polList before~>' + polList.length);

            var pol = [];
            pol = component.get("v.poli");
            var indexed = pol.length;
            var poliIndex = parseInt(component.get("v.index") + 1);
            if (pol != null) poliList = pol[indexed - 1].Accounts;

            if (component.get("v.AutoAccountAllocation")) {
                var coaId = '';
                var projId = '';
                /*
                if(poliList[0] != undefined){
                    coaId = pol[indexed-1].Chart_of_Account__c;
                    projId = poliList[0].Project__c;
                    //component.set("v.coaId", coaId); why? 
                    //component.set("v.projId", projId); why?
                    component.set("v.item.Chart_of_Account__c", pol[indexed-1].Chart_of_Account__c);
                    component.set("v.item.Account_Category__c", pol[indexed-1].Account_Category__c);
                }
                */

                if (pol.length > 0) {
                    console.log('Auto pol[0]~>' + JSON.stringify(pol[0]));
                    if (pol[0].Accounts != null && pol[0].Accounts != undefined) {
                        if (pol[0].Accounts.length > 0) {
                            if (pol[0].Accounts[0].Project__c != undefined && pol[0].Accounts[0].Project__c != null && pol[0].Accounts[0].Project__c != '') {
                                projId = pol[0].Accounts[0].Project__c;
                            }
                        }
                    }
                    console.log('projId~>' + projId);
                    if (pol[0].Chart_of_Account__c != null && pol[0].Chart_of_Account__c != undefined && pol[0].Chart_of_Account__c != '') {
                        coaId = pol[0].Chart_of_Account__c;
                    }
                    console.log('coaId~>' + coaId);
                    component.set("v.item.Chart_of_Account__c", coaId);
                    if (pol[0].Account_Category__c != null && pol[0].Account_Category__c != undefined && pol[0].Account_Category__c != '') {
                        component.set("v.item.Account_Category__c", pol[0].Account_Category__c);
                    }
                }

                if (remainingTotalAAPercent > 0) {
                    polList.push({ sObjectType: 'Dimension__c', Chart_of_Account__c: coaId, Project__c: projId, Sort_Order__c: parseInt(poliIndex), Allocation_Percentage__c: remainingTotalAAPercent, Allocation_Amount__c: (parseFloat(parseFloat(component.get("v.item.Quantity__c")) * parseFloat(component.get("v.item.Unit_Price__c"))) * remainingTotalAAPercent) / 100 });
                } else console.log('arshad new dimension not added because remainingTotalAAPercent~>' + remainingTotalAAPercent);
            } else {
                if (remainingTotalAAPercent > 0) {
                    polList.push({ sObjectType: 'Dimension__c', Chart_of_Account__c: null, Project__c: null, Sort_Order__c: parseInt(poliIndex), Allocation_Percentage__c: remainingTotalAAPercent, Allocation_Amount__c: (parseFloat(parseFloat(component.get("v.item.Quantity__c")) * parseFloat(component.get("v.item.Unit_Price__c"))) * remainingTotalAAPercent) / 100 });
                } else console.log('arshad new dimension not added because remainingTotalAAPercent~>' + remainingTotalAAPercent);
            }
            console.log('polList after~>' + polList.length);
            component.set("v.item.Accounts", polList);

            var TotalAAPercentage2 = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage2 += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage2);
        } catch (e) { console.log('displayAccounts err~>' + e); }
    },

    updateACTaxAmount: function (component, event, helper) {
        try {
            var TotalAAPercentage = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage);

            if (component.get("v.item.Total_Price__c") != '' && component.get("v.item.Total_Price__c") != null && component.get("v.item.Total_Price__c") != undefined) {
                var aaacount = []; aaacount = component.get("v.item.Accounts");
                if (aaacount != null && aaacount != undefined) {
                    if (aaacount.length > 0) {
                        for (var a in aaacount) {
                            if (aaacount[a].Allocation_Percentage__c != undefined && aaacount[a].Allocation_Percentage__c != null && aaacount[a].Allocation_Percentage__c != '') {
                                if (aaacount[a].Allocation_Percentage__c > 0) {
                                    if (!$A.util.isEmpty(component.get("v.item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Quantity__c")) && !$A.util.isEmpty(component.get("v.item.Unit_Price__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Unit_Price__c"))) {
                                        aaacount[a].Allocation_Amount__c = parseFloat((parseFloat(component.get("v.item.Quantity__c")) * parseFloat(component.get("v.item.Unit_Price__c"))) * aaacount[a].Allocation_Percentage__c) / 100;
                                        aaacount[a].Allocation_Amount__c = aaacount[a].Allocation_Amount__c.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                                    } else aaacount[a].Allocation_Amount__c = 0;
                                    //if(component.get("v.item.Tax__c") == null || component.get("v.item.Tax__c") == undefined || component.get("v.item.Tax__c") == ''){
                                    //    aaacount[a].Allocation_Amount__c = parseFloat(component.get("v.item.Total_Price__c") * aaacount[a].Allocation_Percentage__c)/100;
                                    //} else aaacount[a].Allocation_Amount__c = parseFloat( parseFloat(component.get("v.item.Total_Price__c") - component.get("v.item.Tax__c")) * aaacount[a].Allocation_Percentage__c)/100;
                                } else aaacount[a].Allocation_Amount__c = 0;
                            } else aaacount[a].Allocation_Amount__c = 0;
                        }
                    }
                }
                component.set("v.item.Accounts", aaacount);
            }
        } catch (e) { console.log('updateACTaxAmount err~>' + e); }
    },

    updateACTaxPerentage: function (component, event, helper) {
        try {
            if (component.get("v.item.Total_Price__c") != '' && component.get("v.item.Total_Price__c") != null && component.get("v.item.Total_Price__c") != undefined) {
                var aaacount = [];
                aaacount = component.get("v.item.Accounts");
                for (var a in aaacount) {
                    if (aaacount[a].Allocation_Amount__c != undefined && aaacount[a].Allocation_Amount__c != null && aaacount[a].Allocation_Amount__c != '') {
                        if (aaacount[a].Allocation_Amount__c > 0) {
                            var percent = 0;
                            if (!$A.util.isEmpty(component.get("v.item.Quantity__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Quantity__c")) && !$A.util.isEmpty(component.get("v.item.Unit_Price__c")) && !$A.util.isUndefinedOrNull(component.get("v.item.Unit_Price__c"))) {
                                percent = parseFloat(parseFloat(aaacount[a].Allocation_Amount__c) / parseFloat(parseFloat(component.get("v.item.Quantity__c")) * parseFloat(component.get("v.item.Unit_Price__c")))) * 100;
                                aaacount[a].Allocation_Percentage__c = percent.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                            } else aaacount[a].Allocation_Percentage__c = 0;
                            //if(component.get("v.item.Tax__c") == null || component.get("v.item.Tax__c") == undefined || component.get("v.item.Tax__c") == ''){
                            //    percent = parseFloat(aaacount[a].Allocation_Amount__c / component.get("v.item.Total_Price__c"))*100;
                            //}else percent = parseFloat(aaacount[a].Allocation_Amount__c / parseFloat(component.get("v.item.Total_Price__c") - component.get("v.item.Tax__c")))*100;

                        } else aaacount[a].Allocation_Percentage__c = 0;
                    } else aaacount[a].Allocation_Percentage__c = 0;
                }
                component.set("v.item.Accounts", aaacount);
            }

            var TotalAAPercentage = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage);
        } catch (e) { console.log('updateACTaxPerentage err~>' + e); }
    },

    deleteAnalyAcc: function (component, event, helper) {
        try {
            if (event.getSource().get('v.title') != undefined && event.getSource().get('v.title') != null) {
                if (event.getSource().get('v.title') != '') {
                    var action = component.get("c.deleteDimensions");
                    action.setParams({ 'demId': event.getSource().get('v.title') });
                    action.setCallback(this, function (response) {
                        //component.set("v.isMultiCurrency",response.getReturnValue().isMulticurrency);
                        //component.set("v.currencyList",response.getReturnValue().currencyList);
                    });
                    $A.enqueueAction(action);
                }
            }
            console.log('inside deleteAnalyAcc');
            var poliList = [];
            poliList = component.get("v.item.Accounts");
            console.log('poliList before delete length~>' + poliList.length);
            if (event.getSource().get('v.name') != undefined && event.getSource().get('v.name') != null) {
                var index = event.getSource().get('v.name');
                console.log('going to delete index~>' + index);
                //poliList[index].Project__c = null;
                //delete poliList[index].Project__c;
                console.log('poliList before delete ~>' + JSON.stringify(poliList));
                poliList.splice(index, 1);
            }
            console.log('poliList after delete length ~>' + poliList.length);
            console.log('poliList after delete ~>' + JSON.stringify(poliList));

            component.set("v.item.Accounts", poliList);

            if (poliList.length <= 0 && component.get("v.item.Accounts.length") > 0) {
                component.set("v.item.Accounts", null);
            }

            console.log('v.item.Accounts after delete length~>' + component.get("v.item.Accounts.length"));
            console.log('v.item.Accounts after delete ~>' + JSON.stringify(component.get("v.item.Accounts")));

            var TotalAAPercentage = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage);

        } catch (e) { console.log('deleteAnalyAcc err~>' + e); }
    },

    resetAA: function (component, event, helper) {
        try {
            console.log('inside resetAA');
            var TotalAAPercentage = 0;
            if (component.get("v.item.Accounts") != undefined && component.get("v.item.Accounts") != null) {
                if (component.get("v.item.Accounts.length") > 0) {
                    var itemAccs = component.get("v.item.Accounts");
                    for (var i in itemAccs) {
                        if (itemAccs[i].Allocation_Percentage__c != undefined && itemAccs[i].Allocation_Percentage__c != null && itemAccs[i].Allocation_Percentage__c != '') {
                            if (itemAccs[i].Allocation_Percentage__c > 0) TotalAAPercentage += parseFloat(itemAccs[i].Allocation_Percentage__c);
                        }
                    }
                }
            }
            component.set("v.TotalAAPercentage", TotalAAPercentage);

            component.set("v.item.Chart_of_Account__c", null);
            var poliList = [];
            poliList = component.get("v.item.Accounts");
            for (var x in poliList) {
                poliList[x].Project__c = null;
            }
            component.set("v.item.Accounts", poliList);
        } catch (e) { console.log('resetAA err~>' + e); }
    },
})
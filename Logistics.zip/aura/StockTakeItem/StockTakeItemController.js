({    
    updateDefaults : function(component, event, helper) {
        console.log('updateDefaults called');
        var stockInwardItem  = component.get("v.stockInwardItem");
        var stockOutwardItem = component.get("v.stockOutwardItem");
        if(component.get("v.stockTakeItem.Inventory_Stock__c") != undefined && component.get("v.stockTakeItem.Inventory_Stock__c") != null){
            stockInwardItem['Site_ProductService_InventoryStock__r'] = component.get("v.stockTakeItem.Inventory_Stock__r");
            stockOutwardItem['Site_Product_Service_Inventory_Stock__r'] = component.get("v.stockTakeItem.Inventory_Stock__r");
            stockInwardItem['Site_ProductService_InventoryStock__c'] = component.get("v.stockTakeItem.Inventory_Stock__c");
            stockOutwardItem['Site_Product_Service_Inventory_Stock__c'] = component.get("v.stockTakeItem.Inventory_Stock__c");
            
            if(component.get("v.stockTakeItem.Inventory_Stock__r.StorageContainer__c") != undefined && component.get("v.stockTakeItem.Inventory_Stock__r.StorageContainer__c") != null){
                stockInwardItem['StorageContainer__c'] = component.get("v.stockTakeItem.Inventory_Stock__r.StorageContainer__c");
                stockInwardItem['StorageContainer__r'] = component.get("v.stockTakeItem.Inventory_Stock__r.StorageContainer__r");
            }
            
            if(component.get("v.stockTakeItem.Inventory_Stock__r.Location__c") != undefined && component.get("v.stockTakeItem.Inventory_Stock__r.Location__c") != null){
                stockInwardItem['Location__r'] = component.get("v.stockTakeItem.Inventory_Stock__r.Location__r");
                stockInwardItem['Location__c'] = component.get("v.stockTakeItem.Inventory_Stock__r.Location__c");
            }
        }
        
        let inwardName = '';
        let outwardName = '';
        if(Boolean(component.get("v.stockTakeItem.Product__r.Is_Asset__c")) && component.get("v.stockTakeItem.Fixed_Asset__c") != undefined && component.get("v.stockTakeItem.Fixed_Asset__c") != null){
            stockInwardItem['Fixed_Asset__c'] =  component.get("v.stockTakeItem.Fixed_Asset__c");
            stockInwardItem['Fixed_Asset__r'] = component.get("v.stockTakeItem.Fixed_Asset__r");
            stockOutwardItem['Fixed_Asset__c'] =  component.get("v.stockTakeItem.Fixed_Asset__c")
            stockOutwardItem['Fixed_Asset__r'] = component.get("v.stockTakeItem.Fixed_Asset__r");
            inwardName = component.get("v.stockTakeItem.Fixed_Asset__r.Name");
            outwardName = component.get("v.stockTakeItem.Fixed_Asset__r.Name");
        }
        //else{
        if(component.get("v.stockTakeItem.Product__c") != undefined && component.get("v.stockTakeItem.Product__c") != null){
            stockInwardItem['Product__c'] =  component.get("v.stockTakeItem.Product__c");
            stockInwardItem['Product__r'] = component.get("v.stockTakeItem.Product__r");
            inwardName = component.get("v.stockTakeItem.Product__r.Name");
            stockOutwardItem['Product__c'] =  component.get("v.stockTakeItem.Product__c");
            stockOutwardItem['Product__r'] = component.get("v.stockTakeItem.Product__r");
            outwardName = component.get("v.stockTakeItem.Product__r.Name");
        }
        //}
        let stockTakeLineItem = {};
        stockTakeLineItem['Name'] = component.get("v.stockTakeItem.Name");  
        if(component.get("v.stockTakeItem.Id") != undefined && component.get("v.stockTakeItem.Id") != null) stockTakeLineItem['Id'] = component.get("v.stockTakeItem.Id");
        
        stockInwardItem['Stock_Take_Line_Item__r'] = stockTakeLineItem;
        stockInwardItem['Name'] = ($A.util.isEmpty(component.get("v.stockTakeItem.Name")))? inwardName : component.get("v.stockTakeItem.Name");
        stockOutwardItem['Stock_Take_Line_Item__r'] = stockTakeLineItem;
        stockOutwardItem['Name'] = ($A.util.isEmpty(component.get("v.stockTakeItem.Name")))? outwardName : component.get("v.stockTakeItem.Name");
        
        //stockInwardItem['Material_Batch_Lot__r'] = 
        if(component.get("v.stockTakeItem.Serial__c") != undefined && component.get("v.stockTakeItem.Serial__c") != null){
            stockInwardItem['Serial__r'] = component.get("v.stockTakeItem.Serial__r");
            stockInwardItem['Serial__c'] = component.get("v.stockTakeItem.Serial__c");
            stockOutwardItem['Serial__r'] = component.get("v.stockTakeItem.Serial__r");
            stockOutwardItem['Serial__c'] = component.get("v.stockTakeItem.Serial__c");
        }
        
        component.set("v.stockInwardItem",stockInwardItem);
        component.set("v.stockOutwardItem",stockOutwardItem);
        component.set("v.outWardStatusOptions",component.get("v.stockOutWardStatus"));
        component.set("v.inWardReasonOptions",component.get("v.stockInWardReason"));
        
    },
    
    updateVariance : function(component, event, helper) {
        console.log('updateVariance called');
        component.set("v.showInward",false);
        component.set("v.showOutward",false);
        component.set("v.showInwardList",false);
        component.set("v.showOutwardList",false);
        let source = event.getSource().get("v.value");
        console.log('source : ',source);
        let inputCmp =  component.find("StockInHand");
        if(source >= 0){
            console.log('in here source >= 0');
            let stockItem = component.get("v.stockTakeItem");
            if(source != null && parseFloat(source) >= 0.00){
                console.log('stockItem.Product__r.Serialise__c : '+stockItem.Product__r.Serialise__c);
                console.log('stockItem.Stock_In_Hand__c : ',stockItem.Stock_In_Hand__c);
                if(stockItem.Product__r.Serialise__c && stockItem.Stock_In_Hand__c >1){
                    //inputCmp.set("v.errors", [{message:"Value must be <= 1"}]);
                    inputCmp.setCustomValidity("Value must be <= 1");
                }
                /* else if(!stockItem.Product__r.Serialise__c && stockItem.Stock_In_Hand__c == 0){
                        inputCmp.setCustomValidity("Value must be >= 0.00");
                        helper.showToast('Error','error','Please enter value greater than zero');
                        console.log('error 2');
                    }*/
                else{
                    console.log('success else');
                    inputCmp.setCustomValidity("");
                    helper.calculateVariance(component, event);  
                }
            } else {
                console.log('in here source~>'+source)
                if(source != undefined && source != null && source != '') inputCmp.setCustomValidity("Value must be >= 0"); 
                else inputCmp.setCustomValidity("");
                //inputCmp.set("v.errors", [{message:"Value must be >= 0.00 "}]); 
                stockItem.Variance__c = 0.00; 
                
            }
            component.set("v.stockTakeItem",stockItem);
        }  else{
            console.log('in here 2')
            inputCmp.setCustomValidity("");
        }      
    },
    
    closepopups:  function (component, event, helper) {
        component.set("v.showInward",false);
        component.set("v.showOutward",false);
        component.set("v.showInwardList",false);
        component.set("v.showOutwardList",false);
        component.set("v.saveHide",false);
    },
    
    showStockInwardpopup:  function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            let stockItem = component.get("v.stockTakeItem");
            let stockInward = component.get("v.stockInwardItem");
            if(parseFloat(stockItem.Variance__c)>0.00){
                stockInward['Quantity__c'] =  parseFloat(stockItem.Variance__c) -  parseFloat(stockItem.Adjusted_Quantity__c);
            }
            component.set("v.stockInwardItem",stockInward);
            component.set("v.showInward",true);
            component.set("v.showOutward",false);
            component.set("v.showInwardList",false);
            component.set("v.showOutwardList",false);
            component.set("v.saveHide",true);
        }
    },
    
    showStockOutwardpopup:  function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            var stockItem = component.get("v.stockTakeItem");
            var stockOutward = component.get("v.stockOutwardItem");
            if(parseFloat(stockItem.Variance__c)<0.00){
                stockOutward['Quantity__c'] =  (0.00 - parseFloat(stockItem.Variance__c)) -  parseFloat(stockItem.Adjusted_Quantity__c);
            } 
            component.set("v.stockOutwardItem",stockOutward); 
            component.set("v.showInward",false);
            component.set("v.showOutward",true);
            component.set("v.showInwardList",false);
            component.set("v.showOutwardList",false);
            component.set("v.saveHide",true);
        }
    },
    
    showStockInwardListpopup:  function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            component.set("v.showInward",false);
            component.set("v.showOutward",false);
            component.set("v.showInwardList",true);
            component.set("v.showOutwardList",false);
            component.set("v.saveHide",true);
        }
    },
    
    showStockOutwardListpopup:  function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            component.set("v.showInward",false);
            component.set("v.showOutward",false);
            component.set("v.showInwardList",false);
            component.set("v.showOutwardList",true);
            component.set("v.saveHide",true);
        }
    },
    
    createStockInward : function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            console.log('createStockInward called stockItem~>'+JSON.stringify(component.get("v.stockTakeItem")));
            component.set("v.showInward",false);
            component.set("v.showOutward",false);
            component.set("v.showInwardList",false);
            component.set("v.showOutwardList",false);
            component.set("v.saveHide",false);
            if(!$A.util.isUndefinedOrNull(component.get("v.indexcount")) && !$A.util.isEmpty(component.get("v.indexcount"))){
                component.set("v.indexcount",undefined);
            }else{
                let stockItem = component.get("v.stockTakeItem");
                let stockInward = component.get("v.stockInwardItem");
                if(parseFloat(stockItem.Variance__c)>0.00){
                    stockInward['Quantity__c'] =  parseFloat(stockItem.Variance__c) -  parseFloat(stockItem.Adjusted_Quantity__c);
                }
                component.set("v.stockInwardItem",stockInward);
                
                if(component.get("v.prdIndex") != undefined && component.get("v.prdIndex") != null){
                    var prdArr = [] ;
                    if(component.get("v.isAdjusted")){
                        prdArr = component.get("v.adjustedProducts");
                    }else{
                        prdArr = component.get("v.products");
                    }
                    var ik = []; var arsh = []; var stkowlst = [];
                    if(prdArr.length > 0){
                        ik = prdArr[component.get("v.prdIndex")].stockInWardList;
                        arsh = prdArr[component.get("v.prdIndex")].stockOutWardList;
                    }  else console.log('prdArr.length 0');
                    var found = false;
                    for(var x in ik){
                        if(ik[x].Product__c != undefined && ik[x].Product__c != null && ik[x].Product__c != '' && stockInward.Product__c != undefined && stockInward.Product__c != null && stockInward.Product__c != ''){
                            if(ik[x].Product__c == stockInward.Product__c) {
                                ik[x] = stockInward;
                                found = true;
                                break; 
                            }
                        }
                    }
                    for(var x in arsh){
                        if(!$A.util.isUndefinedOrNull(arsh[x].Stock_Take_Line_Item__c) && !$A.util.isEmpty(arsh[x].Stock_Take_Line_Item__c)){
                            stkowlst.push(arsh[x]);
                        }
                    }
                    if(!found){
                        console.log('not found pushing to ik');
                        ik.push(stockInward); 
                    } else console.log('found true so not pushing');
                    if(prdArr.length > 0){
                        prdArr[component.get("v.prdIndex")].stockInWardList = ik;
                        prdArr[component.get("v.prdIndex")].stockOutWardList = stkowlst;
                    }else console.log('prdArr.length is 0');  
                }else console.log('prdIndex null');
            }
        }
    },
    
    createStockOutward : function (component, event, helper) {
        var dis = component.get("v.disabbled");
        if(!dis){
            console.log('createStockOutward called stockItem~>'+JSON.stringify(component.get("v.stockTakeItem")));
            component.set("v.showInward",false);
            component.set("v.showOutward",false);
            component.set("v.showInwardList",false);
            component.set("v.showOutwardList",false);
            component.set("v.saveHide",false);
            console.log('createStockOutward !dis indexcount~>'+component.get("v.indexcount"));
            if(!$A.util.isUndefinedOrNull(component.get("v.indexcount")) && !$A.util.isEmpty(component.get("v.indexcount"))){
                component.set("v.indexcount",undefined);
            }else{
                var stockItem = component.get("v.stockTakeItem");
                var stockOutward = component.get("v.stockOutwardItem");
                if(parseFloat(stockItem.Variance__c)<0.00){
                    stockOutward['Quantity__c'] =  (0.00 - parseFloat(stockItem.Variance__c)) -  parseFloat(stockItem.Adjusted_Quantity__c);
                } 
                component.set("v.stockOutwardItem",stockOutward); 
                
                if(component.get("v.prdIndex") != undefined && component.get("v.prdIndex") != null){
                    var prdArr = [] ;
                    if(component.get("v.isAdjusted")){
                        prdArr = component.get("v.adjustedProducts");
                    }else{
                        prdArr = component.get("v.products");
                    }
                    
                    var ik = []; var arsh = []; var stkiwlst = [];
                    if(prdArr.length > 0){
                        ik = prdArr[component.get("v.prdIndex")].stockOutWardList;
                        arsh = prdArr[component.get("v.prdIndex")].stockInWardList;
                    }  else console.log('prdArr.length 0');
                    var found = false;
                    for(var x in ik){
                        if(ik[x].Product__c != undefined && ik[x].Product__c != null && ik[x].Product__c != '' && stockOutward.Product__c != undefined && stockOutward.Product__c != null && stockOutward.Product__c != ''){
                            if(ik[x].Product__c == stockOutward.Product__c) {
                                ik[x] = stockOutward;
                                found = true;
                                break; 
                            }
                        }
                    }
                    for(var x in arsh){
                        if(!$A.util.isUndefinedOrNull(arsh[x].Stock_Take_Line_Item__c) && !$A.util.isEmpty(arsh[x].Stock_Take_Line_Item__c)){
                            stkiwlst.push(arsh[x]);
                        }
                    }
                    if(!found){
                        console.log('not found pushing to ik');
                        ik.push(stockOutward); 
                    }else console.log('found true so not pushing');
                    if(prdArr.length > 0){
                        prdArr[component.get("v.prdIndex")].stockOutWardList = ik;
                        prdArr[component.get("v.prdIndex")].stockInWardList = stkiwlst;
                    }else console.log('prdArr.length is 0');  
                }else console.log('prdIndex null');
            }
        }
    },
    
})
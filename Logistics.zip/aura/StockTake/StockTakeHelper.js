({
    focusTOscan: function (component, event) {
        console.log('focusTOscan helper called');
        $(document).ready(function () {
            component.set("v.scanValue", '');
            var barcode = "";
            var pressed = false;
            var chars = [];
            $(window).keypress(function (e) {
                
                $(".scanMN").keypress(function (e) {
                    e.stopPropagation()
                });
                
                chars.push(String.fromCharCode(e.which));
                if (pressed == false) {
                    setTimeout(
                        function () {
                            pressed = false;
                            if (chars.length >= 3) {
                                var barcode = chars.join("");
                                barcode = barcode.trim();
                                chars = [];
                                pressed = false;
                                component.set("v.scanValue", barcode);
                                console.log('scanValue : ',component.get("v.scanValue"));
                                chars = [];
                                pressed = false;
                            }
                            chars = [];
                            pressed = false;
                        }, 500);
                }
                pressed = true;
            }); // end of window key press function         
            
            $(window).keydown(function (e) {
                if (e.which === 13) {
                    e.preventDefault();
                }
            });
        });
    },
    
    showToast : function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent != undefined){
            toastEvent.setParams({
                "mode":"dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }
    },
    
    updatevariances : function(component,event,helper,indx,allProductsList,prodId,isSerial,bool){
        try{
            console.log('updatevariances called indx~>'+indx+' prodId~>'+prodId);
            //var allProductsList = component.get("v.allProductsList");
            var stockItem = allProductsList[indx].stockTakeLineItem;
            component.set("v.exceptionError",'');
            if(stockItem.Product__c == prodId){
                if(isSerial){
                    console.log('updatevariances isSerial true');
                    var errmsg = '';
                    var msg = $A.get('$Label.c.Serial_No')+stockItem.Serial__r.Serial_Number__c + ' scanned for product '+stockItem.Product__r.Name+$A.get('$Label.c.please_proceed_further');
                    if(stockItem.Stock_In_Hand__c != undefined && stockItem.Stock_In_Hand__c != null && stockItem.Stock_In_Hand__c != ''){
                        if(stockItem.Stock_In_Hand__c == 1) errmsg = $A.get('$Label.c.Quantity_cannot_be_greated_than_1_for_serialized_products');
                    }
                    stockItem.Stock_In_Hand__c = 1;
                    component.set("v.exceptionError",errmsg);
                    component.set("v.scanmsg",msg);
                    console.log('stockInHand Updated~>'+stockItem.Stock_In_Hand__c);
                }else{
                    console.log('updatevariances isSerial false');
                    var inhand = stockItem.Stock_In_Hand__c;
                    if(inhand == undefined || inhand == null || inhand == ''){
                        stockItem.Stock_In_Hand__c = 1;
                    }else{
                        stockItem.Stock_In_Hand__c = parseInt(inhand) + 1;
                    }
                    var msg = $A.get('$Label.c.Quantity_Updated_for_selected_Product')+stockItem.Product__r.Name+$A.get('$Label.c.please_proceed_further');
                    component.set("v.scanmsg",msg);
                }
                //alignment start//
                let stockInwardItem  = component.get("v.stockInwardItem");
                let stockOutwardItem = component.get("v.stockOutwardItem");
                if(stockItem.Inventory_Stock__c != undefined && stockItem.Inventory_Stock__c != null && stockItem.Inventory_Stock__c != ''){
                    stockInwardItem['Site_ProductService_InventoryStock__r'] = stockItem.Inventory_Stock__r;
                    stockOutwardItem['Site_Product_Service_Inventory_Stock__r'] = stockItem.Inventory_Stock__r;
                    stockInwardItem['Site_ProductService_InventoryStock__c'] = stockItem.Inventory_Stock__c;
                    stockOutwardItem['Site_Product_Service_Inventory_Stock__c'] = stockItem.Inventory_Stock__c;
                    
                    if(stockItem.Inventory_Stock__r.StorageContainer__c != undefined && stockItem.Inventory_Stock__r.StorageContainer__c != null && stockItem.Inventory_Stock__r.StorageContainer__c != ''){
                        stockInwardItem['StorageContainer__c'] = stockItem.Inventory_Stock__r.StorageContainer__c;
                        stockInwardItem['StorageContainer__r'] = stockItem.Inventory_Stock__r.StorageContainer__r;
                    }
                    
                    if(stockItem.Inventory_Stock__r.Location__c != undefined && stockItem.Inventory_Stock__r.Location__c != null && stockItem.Inventory_Stock__r.Location__c != ''){
                        stockInwardItem['Location__r'] = stockItem.Inventory_Stock__r.Location__r;
                        stockInwardItem['Location__c'] = stockItem.Inventory_Stock__r.Location__c;
                    }
                }
                let inwardName = '';
                let outwardName = '';
                stockInwardItem['Product__c'] =  stockItem.Product__c;
                stockInwardItem['Product__r'] = stockItem.Product__r;
                inwardName = stockItem.Product__r.Name;
                stockOutwardItem['Product__c'] =  stockItem.Product__c;
                stockOutwardItem['Product__r'] = stockItem.Product__r;
                outwardName = stockItem.Product__r.Name;
                let stockTakeLineItem = {};
                stockTakeLineItem['Name'] = stockItem.Name;  
                if(stockItem.Id != undefined && stockItem.Id != null && stockItem.Id != '') stockTakeLineItem['Id'] = stockItem.Id;
                stockInwardItem['Stock_Take_Line_Item__r'] = stockTakeLineItem;
                stockInwardItem['Name'] = ($A.util.isEmpty(stockItem.Name) || $A.util.isUndefinedOrNull(stockItem.Name))? inwardName : stockItem.Name;
                stockOutwardItem['Stock_Take_Line_Item__r'] = stockTakeLineItem;
                stockOutwardItem['Name'] = ($A.util.isEmpty(stockItem.Name) || $A.util.isUndefinedOrNull(stockItem.Name))? outwardName : stockItem.Name;
                //stockInwardItem['Material_Batch_Lot__r'] = 
                if(stockItem.Serial__c != undefined && stockItem.Serial__c != null && stockItem.Serial__c != ''){
                    stockInwardItem['Serial__r'] = stockItem.Serial__r;
                    stockInwardItem['Serial__c'] = stockItem.Serial__c;
                    stockOutwardItem['Serial__r'] = stockItem.Serial__r;
                    stockOutwardItem['Serial__c'] = stockItem.Serial__c;
                }
                //alignment end//
                
                stockItem.Variance__c = parseFloat(stockItem.Stock_In_Hand__c) -  parseFloat(stockItem.Stock_Available__c);
                if(parseFloat(stockItem.Variance__c)>0.00){
                    console.log('stockItem.Variance__c > 0 inward');
                    stockInwardItem['Quantity__c'] = parseFloat(stockItem.Variance__c) -  parseFloat(stockItem.Adjusted_Quantity__c);
                    console.log('stockInwardItem~>'+JSON.stringify(stockInwardItem));
                    if(parseFloat(stockItem.Variance__c)>0.00){
                        stockInwardItem['Quantity__c'] =  parseFloat(stockItem.Variance__c);
                    }
                    var ik = []; var arsh = []; var stkowlst = [];
                    ik = allProductsList[indx].stockInWardList;
                    arsh = allProductsList[indx].stockOutWardList;
                    var found = false;
                    for(var x in ik){
                        if(ik[x].Product__c != undefined && ik[x].Product__c != null && ik[x].Product__c != '' && stockInwardItem.Product__c != undefined && stockInwardItem.Product__c != null && stockInwardItem.Product__c != ''){
                            if(ik[x].Product__c == stockInwardItem.Product__c) {
                                ik[x] = stockInwardItem;
                                found = true;
                                break; 
                            }
                        }
                    }
                    for(var x in arsh){
                        if(!$A.util.isUndefinedOrNull(arsh[x].Stock_Take_Line_Item__c) && !$A.util.isEmpty(arsh[x].Stock_Take_Line_Item__c)){
                            stkowlst.push(arsh[x]);
                        }
                    }
                    if(!found){
                        console.log('not found, pushing to ik');
                        ik.push(stockInwardItem); 
                    }else console.log('stockinward found true so not pushing');
                    allProductsList[indx].stockInWardList = ik;
                    allProductsList[indx].stockOutWardList = stkowlst;
                }
                else{
                    console.log('stockItem.Variance__c < 0 outward');
                    stockOutwardItem['Quantity__c'] =  (0.00 - parseFloat(stockItem.Variance__c)) - parseFloat(stockItem.Adjusted_Quantity__c);
                    console.log('stockOutwardItem~>'+JSON.stringify(stockOutwardItem));
                    if(parseFloat(stockItem.Variance__c)<0.00){
                        stockOutwardItem['Quantity__c'] =  (0.00 - parseFloat(stockItem.Variance__c)) -  parseFloat(stockItem.Adjusted_Quantity__c);
                    } 
                    var ik = []; var arsh = []; var stkiwlst = [];
                    ik = allProductsList[indx].stockOutWardList;
                    arsh = allProductsList[indx].stockInWardList;
                    var found = false;
                    for(var x in ik){
                        if(ik[x].Product__c != undefined && ik[x].Product__c != null && ik[x].Product__c != '' && stockOutwardItem.Product__c != undefined && stockOutwardItem.Product__c != null && stockOutwardItem.Product__c != ''){
                            if(ik[x].Product__c == stockOutwardItem.Product__c) {
                                ik[x] = stockOutwardItem;
                                found = true;
                                break; 
                            }
                        }
                    }
                    for(var x in arsh){
                        if(!$A.util.isUndefinedOrNull(arsh[x].Stock_Take_Line_Item__c) && !$A.util.isEmpty(arsh[x].Stock_Take_Line_Item__c)){
                            stkiwlst.push(arsh[x]);
                        }
                    }
                    if(!found){
                        console.log('not found, pushing to ik');
                        ik.push(stockOutwardItem); 
                    } else console.log('stock outward found true so not pushing');
                    allProductsList[indx].stockOutWardList = ik;
                    allProductsList[indx].stockInWardList = stkiwlst;
                }
                console.log('bool here is~>'+bool);
                if(bool) component.set("v.products",allProductsList);
                else component.set("v.allProductsList",allProductsList);
                
                var allProds = component.get("v.allProductsList");
                var prods = component.get("v.products");
                var foundInProds = false;
                for(var i in prods){
                    if (!$A.util.isEmpty(prods[i].stockTakeLineItem) && !$A.util.isUndefinedOrNull(prods[i].stockTakeLineItem)) {
                        if (!$A.util.isEmpty(prods[i].stockTakeLineItem.Inventory_Stock__c) && !$A.util.isUndefinedOrNull(prods[i].stockTakeLineItem.Inventory_Stock__c)) {
                            if (!$A.util.isEmpty(prods[i].stockTakeLineItem.Product__c) && !$A.util.isUndefinedOrNull(prods[i].stockTakeLineItem.Product__c)) {
                                if(prods[i].stockTakeLineItem.Inventory_Stock__c == allProductsList[indx].stockTakeLineItem.Inventory_Stock__c && prods[i].stockTakeLineItem.Product__c == allProds[indx].stockTakeLineItem.Product__c){
                                    foundInProds = true;
                                    prods.splice(i, 1);
                                    prods.unshift(allProductsList[indx]);
                                    //allProds.splice(indx, 1);
                                    break;
                                }
                            }
                        }
                    }
                }
                if(!foundInProds){
                    prods.unshift(allProductsList[indx]);
                    //allProds.splice(indx, 1);
                }
                component.set("v.products",prods);
                component.set("v.allProductsList",allProds);
            } 
        }catch(e){
            console.log('updatevariances error~>'+e);
            component.set("v.scanmsg",'');
            component.set("v.exceptionError",'');
            helper.showToast('Info', 'info', $A.get('$Label.c.PH_OB_Invalid_barcode_scanned'));
        }
    }
    
})
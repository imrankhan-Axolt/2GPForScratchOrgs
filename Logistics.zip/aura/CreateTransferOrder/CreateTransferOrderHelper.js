({    
    
    setTOStatus: function(component, event) {
        console.log('setTOStatus Called');
        component.set("v.showSpinner", true);
        var action = component.get("c.getTOStatuspickval");
        var inputsel = component.find("toStatus");
        var opts = [];
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.toStatusOptions", response.getReturnValue());
                if (component.get("v.toStatusOptions").length > 0) {
                    component.set("v.TO.Status__c", component.get("v.toStatusOptions")[0].value);
                }
            }
            component.set("v.showSpinner", false);
        });
        $A.enqueueAction(action);
    },
    
    setTOShipmenttype: function(component, event) {
        console.log('setTOShipmenttype Called');
        component.set("v.showSpinner", true);
        var action = component.get("c.getTOshipmenttype");
        var opts = [];
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                for (var i = 0; i < response.getReturnValue().length; i++) {
                    opts.push({
                        "class": "optionClass",
                        label: response.getReturnValue()[i],
                        value: response.getReturnValue()[i]
                    });
                }
                component.set("v.toShipmentype", opts);
                if (component.get("v.toShipmentype").length > 0) {
                    component.set("v.TO.Shipment_type__c", component.get("v.toShipmentype")[0].value);
                }
            }
            component.set("v.showSpinner", false);
        });
        $A.enqueueAction(action);
    },
    
    setChannelandDC: function(component, event) {
        console.log('setChannelandDC Called');
        component.set("v.showSpinner", true);
        var action = component.get("c.fetchChannelandDC");
        action.setCallback(this, function(response) {
            if (response.getState() === "SUCCESS") {
                var empData = response.getReturnValue();
                console.log('response : ', response.getReturnValue());
                var transfer = component.get("v.TO");
                transfer.Channel__c = empData.channel;
                if (empData.dontdefaultDC == false) transfer.Distribution_Channel__c = empData.distributionChannel.Id;
                transfer.From_Site__c = empData.distributionChannel.Site__c;
                transfer.From_Address__c = empData.distributionChannel.Site__r.Address__c;
                component.set("v.TO", transfer);
                component.set("v.showToChannel", empData.showToChannel);
                component.set("v.siteID", empData.Site);
                console.log('response : ', empData.Site);
                component.set("v.showDCbelow", empData.showDCbelow);
                component.set("v.showTOName", empData.showTOName);
                component.set("v.processSNBatch", empData.processSNBatch);
                component.set("v.showReadyPickPickTO", empData.showReadyPickPickTO);
                if (empData.showToChannel == false && !$A.util.isEmpty(empData.channel) && !$A.util.isUndefinedOrNull(empData.channel)) {
                    component.set("v.TO.To_Channel__c", empData.channel);
                }
                if ($A.util.isEmpty(component.get("v.TO.To_Channel__c")) || $A.util.isUndefinedOrNull(component.get("v.TO.To_Channel__c"))) {
                    component.set("v.showToChannel", true);
                }
                component.set("v.showSpinner", false);
            } else {
                component.set("v.showSpinner", false);
                var errors = response.getError();
                console.log('errors~>', errors);
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        setTimeout(function() {
                            component.set("v.exceptionError", errors[0].message);
                        }, 5000);
                    }
                } else {
                    setTimeout(function() {
                        component.set("v.exceptionError", "Unknown error");
                    }, 5000);
                }
            }
            component.set("v.showSpinner", false);
        });
        $A.enqueueAction(action);
    },
    
    saveTOandTOLI: function(component, event) {
        console.log('saveTOandTOLI helper called',JSON.stringify(component.get("v.TOLI")));
        var action = component.get("c.save_TO");
        var toliListTemp = [];
        var toliListTemp = component.get("v.TOLI");
        
        // Iterate over the list and remove availableQty property
        for (var i = 0; i < toliListTemp.length; i++) {
            if (toliListTemp[i].hasOwnProperty('Name')) {
                delete toliListTemp[i].Name;
            }
        }
        
        // Log the modified list to verify
        console.log('Modified itemsList:', JSON.stringify(toliListTemp));
        
        action.setParams({
            "newTO": JSON.stringify(component.get("v.TO")),
            "toliList": JSON.stringify(toliListTemp)
        });
        action.setCallback(this, function(response) {
            if (response.getState() === "SUCCESS") {
                console.log('success in saveTOandTOLI');
                this.showToast($A.get('$Label.c.Success'), "success", $A.get('$Label.c.Transfer_Order_created_successfully'));
                var res = response.getReturnValue();
                if (res.Tasks__c != null && res.Tasks__c != undefined && res.Tasks__c != "")
                    this.goBackTask(component, event);
                else {
                    var recordId = res.Id;
                    var RecUrl = "/lightning/r/Transfer_Order__c/" + recordId + "/view";
                    window.open(RecUrl, '_parent');
                }
            } else {
                var errors = response.getError();
                console.log('error in saveTOandTOLI~>', errors);
                component.set("v.showSpinner", false);
                component.set("v.disaSave", false);
                component.set("v.exceptionError", errors[0].message);
            }
        });
        $A.enqueueAction(action);
    },
    
    goBackTask: function(component, event) {
        $A.createComponent("c:AddMilestoneTask", {
            "aura:id": "taskCmp",
            "projectId": component.get("v.projectId"),
            "taskId": component.get("v.Mtask.Id"),
            "newTask": component.get("v.Mtask"),
            "currentMilestones": component.get("v.currentMilestones"),
            "currentProject": component.get("v.currentProject")
        }, function(newCmp, status, errorMessage) {
            if (status === "SUCCESS") {
                var body = component.find("body");
                body.set("v.body", newCmp);
            }
        });
    },
    
    validateFromChannel: function(component, event) {
        var NOerrors = true;
        var fromCh = component.find("toFromChannel");
        if (!$A.util.isUndefined(fromCh) || !$A.util.isEmpty(fromCh))
            NOerrors = this.checkvalidationLookup(fromCh);
        return NOerrors;
    },
    
    validateToChannel: function(component, event) {
        var NOerrors = true;
        var toCh = component.find("tochannelId");
        if (!$A.util.isUndefined(toCh) || !$A.util.isEmpty(toCh))
            NOerrors = this.checkvalidationLookup(toCh);
        return NOerrors;
    },
    
    validateFromDC: function(component, event) {
        var NOerrors = true;
        var fromDC = component.find("toFromDC");
        if (!$A.util.isUndefined(fromDC) || !$A.util.isEmpty(fromDC))
            NOerrors = this.checkvalidationLookup(fromDC);
        return NOerrors;
    },
    
    validateToDC: function(component, event) {
        var NOerrors = true;
        var toDC = component.find("toDC");
        if (!$A.util.isUndefined(toDC) || !$A.util.isEmpty(toDC))
            NOerrors = this.checkvalidationLookup(toDC);
        return NOerrors;
    },
    
    validateTOLIProduct: function(component, event) {
        var NOerrors = true;
        var toliList = component.find("TOLIcmp");
        if (!$A.util.isUndefined(toliList)) {
            if (toliList.length > 0) {
                let flag = true;
                for (let x in toliList)
                    flag = toliList[x].callProdValidate();
                if (!flag) return false;
            } else {
                NOerrors = toliList.callProdValidate();
            }
        } else
            NOerrors = false;
        return NOerrors;
    },
    
    validateTOLIQuantity: function(component, event) {
        var NOerrors = true;
        var toliList = component.find("TOLIcmp");
        if (!$A.util.isUndefined(toliList)) {
            if (toliList.length > 0) {
                let flag = true;
                for (let x in toliList)
                    flag = toliList[x].callQtyValidate();
                if (!flag) return false;
            } else {
                NOerrors = toliList.callQtyValidate();
            }
        } else
            NOerrors = false;
        return NOerrors;
    },
    
    validateTOLISerBat: function(component, event) {
        var NOerrors = true;
        var toliList = component.find("TOLIcmp");
        if (!$A.util.isUndefined(toliList)) {
            if (toliList.length > 0) {
                let flag = true;
                for (let x in toliList)
                    flag = toliList[x].callSerBatValidate();
                if (!flag) return false;
            } else {
                NOerrors = toliList.callSerBatValidate();
            }
        } else
            NOerrors = false;
        return NOerrors;
    },
    
    checkvalidationLookup: function(cmp) {
        if ($A.util.isEmpty(cmp.get("v.selectedRecord.Id"))) {
            cmp.set("v.inputStyleclass", "hasError");
            return false;
        } else {
            cmp.set("v.inputStyleclass", "");
            return true;
        }
    },
    
    checkValidationField: function(cmp) {
        if ($A.util.isEmpty(cmp.get("v.value"))) {
            cmp.set("v.class", "hasError");
            return false;
        } else {
            cmp.set("v.class", "");
            return true;
        }
    },
    
    showToast: function(title, type, message) {
        var toastEvent = $A.get("e.force:showToast");
        if (toastEvent != undefined) {
            toastEvent.setParams({
                "mode": "dismissible",
                "title": title,
                "type": type,
                "message": message
            });
            toastEvent.fire();
        }
    },
    
    /* getDependentPicklists: function(component, event, helper) {
        console.log('getDependentPicklists called');
        var action = component.get("c.getDependentPicklistMap");
        action.setParams({
            ObjectName: component.get("v.objDetail"),
            parentField: component.get("v.controllingFieldAPI"),
            childField: component.get("v.dependingFieldAPI")
        });
        
        action.setCallback(this, function(response) {
            var status = response.getState();
            console.log('status : ', status);
            if (status === "SUCCESS") {
                var pickListResponse = response.getReturnValue();
                console.log('pickListResponse : ', response.getReturnValue());
                component.set("v.depnedentFieldMap", pickListResponse.pickListMap);
                
                var parentkeys = [];
                var parentField = [];
                
                for (var pickKey in pickListResponse.pickListMap) {
                    parentkeys.push(pickKey);
                }
                
                if (parentkeys != undefined && parentkeys.length > 0) {
                    parentField.push('--None--');
                }
                
                for (var i = 0; i < parentkeys.length; i++) {
                    parentField.push(parentkeys[i]);
                }
                component.set("v.listControllingValues", parentField);
                console.log('listControllingValues : ', component.get("v.listControllingValues"));
            } else {
                console.log('err : ', response.getError());
            }
        });
        
        $A.enqueueAction(action);
    },*/
    
    getProductDetails: function(component, helper) {
        var action = component.get("c.getProdDetails");
        action.setParams({
            "prodId": component.get('v.prodRecordId'),
            "DCId": component.get("v.TO.Distribution_Channel__c")
        });
        action.setCallback(this, function(response) {
            console.log('response.getState() getProductDetails: ', response.getState());
            if (response.getState() === 'SUCCESS') {
                if (response.getReturnValue() != null) {
                    console.log('response : ', response.getReturnValue());
                    var standProds = response.getReturnValue();
                    let productsToAdd = [];
                    let poliadd = {};
                    poliadd.availableQty = standProds.stock;
                    poliadd.Products__c = standProds.product.Id;
                    if (component.get("v.processSNBatch")) {
                        poliadd.Serial = standProds.product.Serialise__c;
                        poliadd.batch = standProds.product.Lot_Tracked__c;
                        if (poliadd.Serial) poliadd.Quantity_requested__c = 1;
                    } else {
                        poliadd.Serial = false;
                        poliadd.batch = false;
                    }
                    poliadd.Name = standProds.product.Name;
                    poliadd.Description__c = standProds.product.Description;
                    productsToAdd.push(poliadd);
                    component.set('v.TOLI', productsToAdd);
                    if (standProds.errMsg != null && standProds.errMsg != '' && standProds.errMsg != undefined) {
                        helper.showToast($A.get('$Label.c.warning_UserAvailabilities'), 'warning', standProds.errMsg);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getSearchProducts :function(component){
        //$A.util.removeClass(component.find('mainSpin'), "slds-hide");//15
        component.set("v.showSpinner",true);
        component.set('v.listofProduct',[]);
        //component.set('v.selectedListOfProducts', []);
        var globalsearch = component.get('v.globalProdSearch');
        console.log('globalsearch helper: ',globalsearch);
        component.set('v.addProductsMsg','');
        var selectedProds = component.get('v.selectedListOfProducts');
        var action = component.get("c.getInitialprods");
        action.setParams({
            //"venId":component.get('v.PO.Vendor__c'),
            "searchString": component.get('v.searchItem'),
            "DCId": component.get('v.dChannelId'),
            "family": component.get('v.seachItemFmily'),
            "subFamily": component.get('v.subItemFmily'),
            "search" : globalsearch
        });
        action.setCallback(this,function(response){
            if(response.getState() === 'SUCCESS'){
                console.log('response getSearchProducts: ',JSON.stringify(response.getReturnValue()));
                console.log('setting listofProduct here5');
                component.set('v.listofProduct', response.getReturnValue().prodList);
                component.set('v.globalProdSearch',response.getReturnValue().globalSearch);
                
                
                //Added by Arshad 03 Aug 2023
                try{
                    var standProds = component.get('v.listofProduct');
                    if(standProds != undefined){
                        //added the below code if condition on 18_01_24 shaguftha
                        var indexfound = false;
                        var bfrStandProdslength = standProds.length;
                        if(selectedProds != undefined && selectedProds.length > 0){
                            for(var i = 0; i < selectedProds.length; i++){
                                var index = standProds.findIndex(function(products) {
                                    console.log('products : ',JSON.stringify(products));
                                    return products.prod.Id === selectedProds[i].prod.Id;
                                });
                                console.log('index : ',index);
                                if (index !== -1) {
                                    indexfound = true;
                                    standProds.splice(index, 1);
                                }
                            }
                            
                        }
                        
                        for(var x = 0; x < standProds.length; x++){
                            if(standProds[x].selCostCardId != undefined && standProds[x].selCostCardId != null && standProds[x].selCostCardId != ''){
                                console.log('in here1 standProds[x].selCostCardId~>'+standProds[x].selCostCardId);
                                var res = standProds[x].selectedCostCard;
                                console.log('standProds[x].selectedCostCard res~>',res);
                                
                                standProds[x].unitPrice  = parseFloat(res.Cost__c);
                                
                                if(standProds[x].quantity == null || standProds[x].quantity == '' || standProds[x].quantity == undefined) standProds[x].quantity = parseFloat(0);
                                
                                console.log('defaultTaxRate~>'+component.get("v.defaultTaxRate"));
                                if(standProds[x].taxPercent == null || standProds[x].taxPercent == '' || standProds[x].taxPercent == undefined) standProds[x].taxPercent = parseFloat(component.get("v.defaultTaxRate"));
                                
                                let tax = (standProds[x].unitPrice /100) * standProds[x].taxPercent;
                                console.log('tax  bfr:  ',tax);
                                
                                tax = tax * standProds[x].quantity;
                                
                                standProds[x].taxAmount = tax.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                                
                                if(standProds[x].taxAmount == null || standProds[x].taxAmount == '' || standProds[x].taxAmount == undefined) standProds[x].taxAmount = parseFloat(0);
                                console.log('unitPrice : ',standProds[x].unitPrice);
                                console.log('quantity : ',standProds[x].quantity);
                                console.log('taxAmount : ',standProds[x].taxAmount);
                                console.log('taxPercent : ',standProds[x].taxPercent);
                                
                                standProds[x].TotalPrice = (parseFloat(standProds[x].quantity) * parseFloat(standProds[x].unitPrice)) + parseFloat(standProds[x].taxAmount);
                                console.log('TotalPrice : ',standProds[x].TotalPrice);
                            }
                        }
                        console.log('setting listofProduct here11');
                        component.set('v.listofProduct',standProds);
                        
                        //new code Added by parveez on 24/05/24 for retaining selected products whilw searching for new product line 1696 to line 1706
                        var stdprods = component.get('v.listofProduct');
                        
                        
                        if (selectedProds !== undefined && selectedProds.length > 0) {
                            for (var i = 0; i < selectedProds.length; i++) {
                                stdprods.push(selectedProds[i]);
                            }
                        } 
                        
                        component.set('v.listofProduct', stdprods);
                        
                        if(indexfound == true && standProds.length == 0 && bfrStandProdslength == 1) component.set('v.addProductsMsg',$A.get("$Label.c.Product_is_selected"));
                        else if(standProds.length == 0) component.set('v.addProductsMsg',$A.get("$Label.c.No_products_available_to_view"));
                            else component.set('v.addProductsMsg',response.getReturnValue().Msg);
                    }
                    //for(var x in standProds){
                    
                }catch(e){
                    console.log('err~>',e);
                }
                
                component.set('v.globalProdSearch',response.getReturnValue().globalSearch);
                console.log('globalsearch helpers set: ',component.get('v.globalProdSearch'));
                //$A.util.addClass(component.find('mainSpin'), "slds-hide");//16
                component.set("v.showSpinner",false);
            }else{
                console.log('Error getSearchProducts:',response.getError());
                component.set("v.exceptionError",response.getError());
                //$A.util.addClass(component.find('mainSpin'), "slds-hide");//17
                component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action);
        
    },
    
    
    familyFieldChange : function(component, event, helper){
        try{
            console.log('familyFieldChange called');
            var controllerValue = component.get("v.seachItemFmily");//component.find("parentField").get("v.value");// We can also use event.getSource().get("v.value")
            var pickListMap = component.get("v.FamilydepnedentFieldMap");
            console.log('controllerValue : '+controllerValue);
            console.log('pickListMap : '+JSON.stringify(pickListMap));
            if (controllerValue != '' && controllerValue != null && controllerValue != undefined) {
                //get child picklist value
                var childValues = pickListMap[controllerValue];
                var childValueList = [];
                if(childValues != undefined && childValues != null){
                    if(childValues.length > 0){
                        //childValueList.push('');
                        for (var i = 0; i < childValues.length; i++) {
                            childValueList.push(childValues[i]);
                        }
                    }
                }
                // set the child list
                console.log('childValueList~>'+JSON.stringify(childValueList));
                component.set("v.subfamilylst", childValueList);
                
                if(childValueList.length > 0){
                    component.set("v.bDisabledSubFamilyFld" , false);  
                }else{
                    component.set("v.bDisabledSubFamilyFld" , true); 
                }
            } else {
                var list = [];
                component.set("v.subfamilylst", list);
                component.set("v.bDisabledSubFamilyFld" , true);
            }
            
            /*  if(component.get("v.subfamilylst").length > 0){
                var listdependingValues = component.get("v.subfamilylst");
                component.set("v.subItemFmily",listdependingValues[0].value);
            }*/
            
            console.log('v.subItemFmily~>'+component.get("v.subItemFmily"));
        }catch(e){
            console.log('err parentFieldChange~>',e);
        }
    },
    
    getDependentPicklistsFamily: function(component, event, helper) {
        console.log('getDependentPicklistsFamily called');
        var action = component.get("c.getDependentPicklist");
        action.setParams({
            ObjectName : component.get("v.Poructobj"),
            parentField : component.get("v.FamilycontrollingFieldAPI"),
            childField : component.get("v.SubFamilydependingFieldAPI")
        });
        
        action.setCallback(this, function(response){
            var status = response.getState();
            console.log('getDependentPicklistsFamily status : ',status);
            if(status === "SUCCESS"){
                var pickListResponse = response.getReturnValue();
                console.log('getDependentPicklistsFamily pickListResponse : ',response.getReturnValue());
                //save response 
                component.set("v.FamilydepnedentFieldMap",pickListResponse.pickListMap);
                
                // create a empty array for store parent picklist values 
                var parentkeys = []; // for store all map keys 
                var parentField = []; // for store parent picklist value to set on lightning:select. 
                
                // Iterate over map and store the key
                for (var pickKey in pickListResponse.pickListMap) {
                    console.log('getDependentPicklistsFamily pickKey~>'+JSON.stringify(pickKey));
                    parentkeys.push(pickKey);
                }
                
                //set the parent field value for lightning:select
                /*if (parentkeys != undefined && parentkeys.length > 0) {
                    parentField.push('');
                }*/
                
                for (var i = 0; i < parentkeys.length; i++) {
                    parentField.push(parentkeys[i]);
                }  
                // set the parent picklist
                console.log('getDependentPicklist parentField~>'+JSON.stringify(parentField));
                console.log('getDependentPicklist pickListResponse.controllingValues~>'+JSON.stringify(pickListResponse.controllingValues));
                //component.set("v.listControllingValues", parentField);
                component.set("v.familylst", pickListResponse.controllingValues);
                console.log('familylst  : ',component.get("v.familylst"));       
                component.set("v.seachItemFmily", '');
                component.set("v.subItemFmily", '');
            }
            else{
                console.log('getDependentPicklist err : '+JSON.stringify(response.getError()));
            }
        });
        
        $A.enqueueAction(action);
    },
    
    getfamily: function(component) {
        console.log('calling helper');
        var action = component.get("c.getPicklistvalues");
        action.setParams({ 
            ObjectName : "Product2",
            parentField : "Family",
            childField : "Product_Service_Family__c"
        });
        console.log('setting params helper');
        action.setCallback(this,function(response){
            console.log('getting getPicklistvalues');
            if(response.getState() === 'SUCCESS'){
                console.log('inside success helper');
                console.log('getting getPicklistvalues');
                console.log('response getPicklistvalues : ',response.getReturnValue());
                
                component.set('v.familylst',response.getReturnValue());
            }else{
                console.log('Error addNew:',response.getError());
                component.set("v.showSpinner",false);
            }
            
        }); 
        $A.enqueueAction(action); 
    }
})
s
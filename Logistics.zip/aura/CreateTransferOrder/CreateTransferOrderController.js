({
    doInit : function(component, event, helper) {
        console.log('Create TO doInit');
        helper.setChannelandDC(component, event);
        helper.setTOStatus(component, event);
        //helper.getDependentPicklists(component, event, helper);
        console.log('prodRecordId 1st line: ',component.get('v.prodRecordId'));
        if(component.get('v.prodRecordId') != null && component.get('v.prodRecordId') != '' && component.get('v.prodRecordId') != undefined){
            helper.getProductDetails(component,helper);
        }
        
        
        if(!$A.util.isEmpty(component.get('v.item.Id')) && !$A.util.isUndefinedOrNull(component.get('v.item.Id'))){
            
            component.set("v.proceedChangeHandler",false);
            var currProd = component.get('v.item.Products__c');
            if(currProd == undefined || currProd == null) currProd = '';
            console.log('doInit setting prod null & currProd~>'+currProd);
            component.set('v.item.Products__c',null);
            
            component.set("v.proceedChangeHandler",true);
            component.set('v.item.Products__c',currProd);
            
            component.set("v.disableSave",true);
        }
        
        //helper.setTOShipmenttype(component, event);
    },
    
    addNew : function(component, event, helper) {
        console.log('Inside addNew');
        var transfer = component.get("v.TO");
        let proceed=true;
        if($A.util.isEmpty(transfer.Channel__c) || $A.util.isUndefinedOrNull(transfer.Channel__c)){
            setTimeout(function(){ component.set("v.exceptionError",$A.get('$Label.c.Please_select_a_channel')); }, 2000);
        }else if($A.util.isEmpty(transfer.Distribution_Channel__c) || $A.util.isUndefinedOrNull(transfer.Distribution_Channel__c)){
            setTimeout(function(){ component.set("v.exceptionError",$A.get('$Label.c.Please_Select_a_Distribution_Channel'));  }, 2000);          
        }else if($A.util.isEmpty(transfer.To_Channel__c) || $A.util.isUndefinedOrNull(transfer.To_Channel__c)){
            setTimeout(function(){ component.set("v.exceptionError",$A.get('$Label.c.Please_Select_a_Channel_to_transfer')); }, 2000);
            proceed=false;console.log('no DC');
        }else if($A.util.isEmpty(transfer.To_Distribution_Channel__c) || $A.util.isUndefinedOrNull(transfer.To_Distribution_Channel__c)){
            setTimeout(function(){ component.set("v.exceptionError",$A.get('$Label.c.Please_Select_a_Distribution_Channel_to_transfer')); }, 2000);
            proceed=false;console.log('no DC');
        }/*else{
            /var toliList = [];
            if(component.get("v.TOLI") != null) toliList = component.get("v.TOLI");
            //toliList.unshift({sObjectType :'toliWrap'});
            component.set("v.TOLI",toliList);
        } */
        if(proceed===true){
            component.set("v.showAddProducts",true);      
            component.set("v.showSpinner",true);
            //helper.getfamily(component, event, helper);
            helper.getDependentPicklistsFamily(component, event, helper);
            console.log('after getDependentPicklistsFamily in helper');
            var action = component.get("c.getInitialprods");
            action.setParams({});
            action.setCallback(this,function(response){
                if(response.getState() === 'SUCCESS'){
                    console.log('entered success state');
                    console.log('listofProduct==>'+JSON.stringify(response.getReturnValue().prodList));
                    component.set('v.listofProduct',response.getReturnValue().prodList);
                    var prodlist = component.get('v.listofProduct');
                    for(var i in prodlist){
                        prodlist[i].serials =[];
                        prodlist[i].batches = [];
                        prodlist[i].serialsOfBatch = [];
                    }
                    component.set('v.listofProduct',prodlist);
                    component.set("v.showSpinner",false);
                }else{
                    console.log('Error addNew:',response.getError());
                    component.set("v.showSpinner",false);
                }
                component.set("v.showAddProducts",true);
                component.set("v.showStandardProducts",true);
                component.set("v.toggleChecked",false);
            }); 
            $A.enqueueAction(action); 
        }
    },
    
    /*handleCheckbox: function(component, event, helper) {
        console.log('handleCheckbox1');
        let checkedval = event.getSource().get("v.checked");
        let index = event.getSource().get("v.name");
        var selectedProds = component.get('v.selectedListOfProducts');
        console.log('selectedProds bfr : ',selectedProds);
        if (checkedval && index != null && index != undefined && index != '') {
            console.log('in 1');
            let standProds = component.get('v.listofProduct');
            console.log('listofProduct'+JSON.stringify(standProds));
            for (let i = 0; i < standProds.length; i++) {
                if (i == index || standProds[i].Id == index) {
                    selectedProds.push(standProds[i]);
                }
            }
            component.set('v.selectedListOfProducts', selectedProds);
        } else if (checkedval == false && index != null && index != undefined && index != '') {
            if(selectedProds != undefined && selectedProds != null && selectedProds != []){
                for (let i = selectedProds.length - 1; i >= 0; i--) {
                    if (selectedProds[i].Id == index) {
                        selectedProds.splice(i, 1);
                    }
                }
                component.set('v.selectedListOfProducts', selectedProds); 
            }
        }
        console.log('selectedProds : ',selectedProds);
    },*/
    
    PickMultiSerials : function(cmp, event,helper) {
        console.log('entered pick for serial numbers');
        try {
            if((cmp.get("v.callPickMultiSerials") && cmp.get("v.fromScanFlowforMultiPick")) || (!cmp.get("v.callPickMultiSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('entered pick if');
                cmp.set("v.showSpinnerItem", true);
                var selectedSerials = cmp.get("v.PickSelectedSerialNos");
                console.log('selectedSerials:', JSON.stringify(selectedSerials));
                var serials = [];
                var prodId = cmp.get('v.selectedProductId');
                
                console.log('prodId', prodId);
                
                if (selectedSerials.length > 0) {
                    
                    for (var x in selectedSerials) {
                        serials.push({
                            SerialNo: selectedSerials[x].SerialNo,
                            SerialQuantity: selectedSerials[x].SerialQuantity,
                            ProductId: prodId
                        });
                    }
                    console.log('serials : ', serials);
                    var currentIndex = cmp.get('v.currentIndex');
                    var getprodlist = cmp.get("v.listofProduct");
                    
                    getprodlist[currentIndex].quantity = serials.length;
                    getprodlist[currentIndex].serials = serials;
                    getprodlist[currentIndex].checkSelected = true;
                    cmp.set("v.listofProduct",getprodlist);//selected
                    
                    if (serials.length > 0) {
                        // Close the modal and reset component states
                        $A.util.removeClass(cmp.find("myModalPickSerial"), 'slds-fade-in-open');
                        $A.util.removeClass(cmp.find("myModalMOSerialBackDrop"), "slds-backdrop_open");
                        
                        cmp.set("v.PickSerialNos", []);
                        //cmp.set("v.PickBatchNos", []);
                        cmp.set("v.Location",null);
                        cmp.set("v.currentIndex",'');
                        
                        cmp.set("v.isModalOpen", false);
                        cmp.set("v.showAddProducts", true);
                        
                        //cmp.set("v.showSpinnerItem", false);
                    } else {
                        cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                        cmp.set("v.showSpinnerItem", false);
                    }
                } else {
                    cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                    cmp.set("v.showSpinnerItem", false);
                }
                cmp.set("v.callPickMultiSerials", false);
                cmp.set("v.fromScanFlowforMultiPick", false);  
            }
        } catch (e) {
            console.log(e);
        }
    },
    
    PickMultiBatches : function(cmp, event) {
        console.log('entered pick for batch numbers');
        try {
            if((cmp.get("v.callPickMultiSerials") && cmp.get("v.fromScanFlowforMultiPick")) || (!cmp.get("v.callPickMultiSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('entered pick batch if');
                cmp.set("v.showSpinnerItem", true);
                var selectedBatches = cmp.get("v.PickSelectedBatchNos");
                console.log('selectedBatches:', JSON.stringify(selectedBatches));
                var batches = [];
                var prodId = cmp.get('v.selectedProductId');
                
                console.log('prodId', prodId);
                
                if (selectedBatches.length > 0) {
                    /*
                for (var x in selectedSerials) {
                    serials.push(selectedSerials[x].SerialNo);
                }*/
                    for (var x in selectedBatches) {
                        batches.push({
                            BatchNo: selectedBatches[x].BatchNo,
                            BatchQuantity: selectedBatches[x].BatchQuantity,
                            ProductId: prodId
                        });
                    }
                    console.log('batches : ', batches);
                    var currentIndex = cmp.get('v.currentIndex');
                    var getprodlist = cmp.get("v.listofProduct");
                    
                    getprodlist[currentIndex].quantity = batches.length;
                    getprodlist[currentIndex].batches = batches;
                    getprodlist[currentIndex].checkSelected = true;
                    cmp.set("v.listofProduct",getprodlist);//selected
                    
                    if (batches.length > 0) {
                        // Close the modal and reset component states
                        $A.util.removeClass(cmp.find("myModalPickSerial"), 'slds-fade-in-open');
                        $A.util.removeClass(cmp.find("myModalMOSerialBackDrop"), "slds-backdrop_open");
                        
                        cmp.set("v.PickBatchNos", []);
                        cmp.set("v.PickSelectedBatchNos", []);
                        //cmp.set("v.PickSerialNos", []);
                        cmp.set("v.Location",null);
                        cmp.set("v.currentIndex",'');
                        
                        cmp.set("v.isModalOpen", false);
                        cmp.set("v.showAddProducts", true);
                        //cmp.set("v.showSpinnerItem", false);
                    } else {
                        cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                        cmp.set("v.showSpinnerItem", false);
                    }
                } else {
                    cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                    cmp.set("v.showSpinnerItem", false);
                }
                cmp.set("v.callPickMultiSerials", false);
                cmp.set("v.fromScanFlowforMultiPick", false);  
            }
        } catch (e) {
            console.log(e);
        }
    },
    
    PickMultiSerialsOfBatchNos : function(cmp, event){
        console.log(' entered PickSelectedSerialsOfBatchNos');
        try {
            if((cmp.get("v.callPickMultiSerials") && cmp.get("v.fromScanFlowforMultiPick")) || (!cmp.get("v.callPickMultiSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('entered pick if');
                cmp.set("v.showSpinnerItem", true);
                var selectedSerials = cmp.get("v.PickSelectedSerialsOfBatchNos");
                console.log('selectedSerials:', JSON.stringify(selectedSerials));
                var serialsOfBatch = [];
                var prodId = cmp.get('v.selectedProductId');
                var batchId = cmp.get('v.item.Batch_Lot__c');
                console.log('prodId', prodId);
                console.log('batchid'+batchId);
                
                if (selectedSerials.length > 0) {
                    /*
                for (var x in selectedSerials) {
                    serials.push(selectedSerials[x].SerialNo);
                }*/
                    for (var x in selectedSerials) {
                        serialsOfBatch.push({
                            SerialNo: selectedSerials[x].SerialNo,
                            SerialQuantity: selectedSerials[x].SerialQuantity,
                            ProductId: prodId,
                            batchInfo  : selectedSerials[x].batchInfo
                            
                        });
                    }
                    console.log('serialsOfBatch : ', serialsOfBatch);
                    var currentIndex = cmp.get('v.currentIndex');
                    console.log('currentIndex-->'+currentIndex);
                    var getprodlist = cmp.get("v.listofProduct");
                    
                    
                    getprodlist[currentIndex].quantity = serialsOfBatch.length;
                    getprodlist[currentIndex].serialsOfBatch = serialsOfBatch;
                    getprodlist[currentIndex].checkSelected = true;
                    console.log('serialsOfBatch'+JSON.stringify(serialsOfBatch));
                    /*
                    //error here 
                    //if (serialsOfBatch && serialsOfBatch.batchDetails) {
                        console.log('entered if');
                    	
                        getprodlist[currentIndex].Batch_Lot__c = serialsOfBatch.batchDetails.Id;
                    	console.log('batchId++'+serialsOfBatch.batchDetails.Id);
                        getprodlist[currentIndex].Batch_Lot__r = {
                            Name: serialsOfBatch.batchDetails.Name
                        }
                        console.log('batchname++'+serialsOfBatch.batchDetails.Name);
                    //}*/
                    //error here
                    if (serialsOfBatch.length > 0) {
                        for (var i = 0; i < serialsOfBatch.length; i++) {
                            if (serialsOfBatch[i].batchInfo) {
                                getprodlist[currentIndex].Batch_Lot__c = serialsOfBatch[i].batchInfo.Id;
                                console.log('batchId++' + serialsOfBatch[i].batchInfo.Id);
                                getprodlist[currentIndex].Batch_Lot__r = {
                                    Name: serialsOfBatch[i].batchInfo.Name
                                };
                                console.log('batchname++' + serialsOfBatch[i].batchInfo.Name);
                            } else {
                                console.error('batchDetails is undefined for serial: ' + serialsOfBatch[i].SerialNo.Id);//error here
                            }
                        }
                    } else {
                        console.error('serialsOfBatch array is empty');
                    }

                    //getprodlist[currentIndex].Batch_Lot__c = serialsOfBatch.batchDetails.Id;
                    //getprodlist[currentIndex].Batch_Lot__r.Name = serialsOfBatch.batchDetails.Name;
                    
                    cmp.set("v.listofProduct",getprodlist);//selected
                    
                    
                    if (serialsOfBatch.length > 0) {
                        // Close the modal and reset component states
                        $A.util.removeClass(cmp.find("myModalPickSerial"), 'slds-fade-in-open');
                        $A.util.removeClass(cmp.find("myModalMOSerialBackDrop"), "slds-backdrop_open");
                        
                        cmp.set("v.PickBatchSerialNos", []);
                        cmp.set("v.PickSelectedSerialsOfBatchNos", []);
                        //cmp.set("v.currentIndex",'');
                        cmp.set("v.item.Batch_Lot__c",'');
                        cmp.set("v.Location",null);
                        
                        cmp.set("v.isSerialBatchOpen", false);
                        cmp.set("v.showAddProducts", true);
                        //cmp.set("v.showSpinnerItem", false);
                    } else {
                        cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                        cmp.set("v.showSpinnerItem", false);
                    }
                } else {
                    cmp.set("v.exceptionError", $A.get('$Label.c.Please_enter_serial_number_for_the_product')); 
                    cmp.set("v.showSpinnerItem", false);
                }
                cmp.set("v.callPickMultiSerials", false);
                cmp.set("v.fromScanFlowforMultiPick", false);  
            }
        } catch (e) {
            console.log(e);
        }
    },
    
    navigateToNewPage: function(component, event, helper) {
        var index = event.currentTarget.getAttribute("data-index");
        console.log('Index: ' + index);
        component.set("v.currentIndex", index);
        console.log('serial and batch called')
        component.set("v.showAddProducts", false);
        component.set("v.isModalOpen", true);
        console.log('serial and batch called 2')
        
        var productId = event.currentTarget.dataset.productId;
        console.log('productId-->'+productId)
        component.set("v.selectedProductId", productId);
        
        var siteID = component.get("v.siteID");
        console.log('siteID --> ' + siteID);
        
        var locID  = component.get("v.item.From_Location__c");
        console.log('locID --> ' + locID);
        
        component.set("v.PickSelectedSerialNos", component.get('v.listofProduct')[index].serials);
        component.set("v.PickSelectedBatchNos", component.get('v.listofProduct')[index].batches);
        
        // Simulate retrieving serial numbers or batches based on product type (serialized)
        if(component.get('v.listofProduct')[index].Serialise__c){
            var serialLength = component.get('v.listofProduct')[index].serials.length;
            console.log('serialLength==>'+serialLength);
            
            var pickedSerial = [];
            if(serialLength > 0){
                pickedSerial = component.get('v.listofProduct')[index].serials;
            }
            var Ids = [];
            for(var x in pickedSerial){
                Ids.push(pickedSerial[x].SerialNo.Id);
            }
            
            console.log('Im Here at 266');
            
            console.log('entering if a product is serial')
            var action = component.get("c.PreparePickSerialNos");
            action.setParams({ 
                productId: productId,	
                searchString: "",
                siteID : siteID,
                locId : locID,
                lmt : 100,
                serialIds : Ids
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log(state)
                var validSerials = [];
                if (state === "SUCCESS") {
                    console.log('result.PickSerialNos'+JSON.stringify(response.getReturnValue().PickSerialNos));
                    var Serials = [];
                    Serials = response.getReturnValue().PickSerialNos;
                    if (pickedSerial > 0) {
                        console.log('entered pickser nno if - 1');
                        // Iterate backwards to avoid index issues while splicing
                        for (var i = Serials.length - 1; i >= 0; i--) {
                            if (pickedSerial.includes(Serials[i].SerialNo.Id)) {
                                console.log('entered pickser nno if - 2');
                                Serials.splice(i, 1);
                            }
                        }
                        component.set("v.PickSerialNos", Serials);
                        console.log('PickSerialNos==>'+PickSerialNos);
                    }
                    else component.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                    component.set("v.isModalOpen", true);
                } else {
                    console.error("Error fetching serials");
                }
            });
            $A.enqueueAction(action);
            
        }
        
        // Simulate retrieving batches based on product type (lot-tracked)
        if(component.get('v.listofProduct')[index].Lot_Tracked__c ){
            var batchesLength = component.get('v.listofProduct')[index].batches.length;
            console.log('batchesLength==>'+batchesLength);
            
            var pickedBatches = [];
            if(batchesLength > 0){
                pickedBatches = component.get('v.listofProduct')[index].batches;
            }
            var Ids = [];
            for(var x in pickedBatches){
                Ids.push(pickedBatches[x].BatchNo.Id);
            }
            
            console.log('Im Here at 322');
            
            console.log('entering if a product is batch')
            var action = component.get("c.PreparePickBatchNos");
            action.setParams({ 
                productId: productId,	
                searchString: "",
                siteID : siteID,
                locId : locID,
                lmt : 100,
                batchIds : Ids
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log(state)
                if (state === "SUCCESS") {
                    console.log('result.PickBatchNos'+JSON.stringify(response.getReturnValue().PickBatchNos));
                    var Batches = [];
                    Batches = response.getReturnValue().PickBatchNos;
                    if (selectedBatchesIDs.length > 0) {
                        console.log('entered pickser nno if - 1');
                        // Iterate backwards to avoid index issues while splicing
                        for (var i = Batches.length - 1; i >= 0; i--) {
                            if (selectedBatchesIDs.includes(Batches[i].SerialNo.Id)) {
                                console.log('entered include serials');
                                console.log('entered pickser nno if - 2');
                                Batches.splice(i, 1);
                            }
                        }
                        component.set("v.PickBatchNos", Batches);
                    }
                    console.log('result.PickBatchNos'+JSON.stringify(response.getReturnValue().PickBatchNos));
                    component.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                    component.set("v.isModalOpen", true);
                } else {
                    console.error("Error fetching batches");
                }
            });
            $A.enqueueAction(action);
        }
        
    },
    
    navigateToSerialAndBatch: function(component, event, helper) {
        console.log('If a prod is serial n batch both ');
        var index = event.currentTarget.getAttribute("data-index");
        console.log('Index: ' + index);
        component.set("v.currentIndex", index);
        component.set("v.showAddProducts", false);
        component.set("v.isSerialBatchOpen", true);
        
        var productId = event.currentTarget.dataset.productId;
        console.log('productId-->'+productId)
        component.set("v.selectedProductId", productId);
        component.set("v.qry",'And Product__c = \''+productId +'\'' );
        
        var siteID = component.get("v.siteID");
        console.log('siteID --> ' + siteID);
        
        var locID  = component.get("v.item.From_Location__c");
        console.log('locID --> ' + locID);
       
        
        if(component.get('v.listofProduct')[index].Serialise__c && component.get('v.listofProduct')[index].Lot_Tracked__c){
            console.log('If a prod is serial n batch both ');
        }    
    },
    
    fetchSerialsForBatch: function (component, event, helper) {
        console.log('fetchSerialsForBatch entered');
        var prodId = component.get('v.selectedProductId');
        console.log('fetchSerialsForBatch entered 2');
        console.log('prodId'+prodId);
        var site = component.get("v.siteID");
        console.log('site'+site);
        var loc = component.get("v.item.From_Location__c");
        console.log('loc'+loc);
        var batchId = component.get('v.item.Batch_Lot__c');
        console.log('batchId'+batchId);
        component.set("v.batchNo",batchId);
        var curIndex = component.get("v.currentIndex");
        console.log('currentIndex==>'+curIndex);
        
        component.set("v.PickSelectedSerialsOfBatchNos", component.get('v.listofProduct')[curIndex].serialsOfBatch);
        
        var sOfBLength = component.get('v.listofProduct');
        console.log('sOfBLength==>'+JSON.stringify(sOfBLength));
        
        var serialOfBatchLength = component.get('v.listofProduct')[curIndex].serialsOfBatch.length;
        console.log('serialOfBatchLength==>'+serialOfBatchLength);
        
        var pickedSerialOfBatch = [];
        if(serialOfBatchLength > 0){
            pickedSerialOfBatch = component.get('v.listofProduct')[curIndex].serialsOfBatch;
            console.log('pickedSerialOfBatch==>'+JSON.stringify(pickedSerialOfBatch));
        }
        var Ids = [];
        for(var x in pickedSerialOfBatch){
            Ids.push(pickedSerialOfBatch[x].SerialNo.Id);
        }
        
        console.log('Im Here at 1861');
        
        var actionSerials = component.get("c.PreparePickSerialNosForBatch");
        actionSerials.setParams({
            productId: prodId,
            batchId: batchId,
            searchString: "",
            siteID: site,
            locId: loc,
            lmt: 100,
            serialIds : Ids
        });
        actionSerials.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('state'+state);
                if (response.getReturnValue().error != '') {
                    component.set("v.exceptionError", response.getReturnValue().error);
                    component.set("v.PickBatchSerialNos", response.getReturnValue().PickBatchSerialNos);
                    console.log('PickBatchSerialNos==>'+response.getReturnValue().PickBatchSerialNos);
                    component.set("v.showSpinnerItem", false);
                } else {
                    component.set("v.PickBatchSerialNos", response.getReturnValue().PickBatchSerialNos);
                    console.log('PickBatchSerialNos===>'+JSON.stringify(response.getReturnValue().PickBatchSerialNos));
                    if (cmp.get("v.PickBatchSerialNos").length > 0) component.set("v.disableAdd", false);
                    component.set("v.showSpinnerItem", false);
                }
            }
        });
        $A.enqueueAction(actionSerials);
        
    },
    
    ChangeLocationmanual: function (cmp, event) {
        try{
            console.log('ChangeLocationmanual');
            cmp.set("v.showSpinnerItem", true);
            var prodId = cmp.get('v.selectedProductId');
            console.log('prodId-->'+prodId);
            var site = cmp.get("v.siteID");
            console.log('site-->'+site);
            var loc = cmp.get("v.Location");
            console.log('loc-->'+loc);
            var reqQty = cmp.get("v.requiredQty");
            console.log('reqQty : ',reqQty);
            var curIndex = cmp.get("v.currentIndex");
            console.log('currentIndex==>'+curIndex);
            
            // Check if location is not null before calling PreparePickSerialNos
            if (loc && cmp.get('v.listofProduct')[curIndex].Serialise__c) {
                console.log('entered serial loc');
                var serialLengthLoc = cmp.get('v.listofProduct');
                console.log('serialLengthLoc==>'+JSON.stringify(serialLengthLoc));
                
                var serialLength = cmp.get('v.listofProduct')[curIndex].serials.length;
                console.log('serialLength==>'+serialLength);
                
                var pickedSerial = [];
                if(serialLength > 0){
                    pickedSerial = cmp.get('v.listofProduct')[curIndex].serials;
                    console.log('pickedSerial==>'+JSON.stringify(pickedSerial));
                }
                var Ids = [];
                for(var x in pickedSerial){
                    Ids.push(pickedSerial[x].SerialNo.Id);
                }
                
                console.log('Im Here at 401');
                
                var actionSerials = cmp.get("c.PreparePickSerialNos");
                actionSerials.setParams({
                    productId: prodId,
                    searchString: "",
                    siteID: site,
                    locId: loc,
                    lmt: reqQty,
                    serialIds: Ids
                });
                actionSerials.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        if (response.getReturnValue().error != '') {
                            cmp.set("v.exceptionError", response.getReturnValue().error);
                            cmp.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                            cmp.set("v.showSpinnerItem", false);
                        } else {
                            cmp.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                            if (cmp.get("v.PickSerialNos").length > 0) cmp.set("v.disableAdd", false);
                            cmp.set("v.showSpinnerItem", false);
                        }
                    }
                });
                $A.enqueueAction(actionSerials);
            } 
            else if (loc && cmp.get('v.listofProduct')[curIndex].Lot_Tracked__c) {
                console.log('entered batch loc');
                var batchesLengthLoc = cmp.get('v.listofProduct');
                console.log('batchesLengthLoc==>'+JSON.stringify(batchesLengthLoc));
                
                var batchesLength = cmp.get('v.listofProduct')[curIndex].batches.length;
                console.log('batchesLength==>'+batchesLength);
                
                var pickedBatches = [];
                if(batchesLength > 0){
                    pickedBatches = cmp.get('v.listofProduct')[curIndex].batches;
                    console.log('pickedBatches==>'+JSON.stringify(pickedBatches));
                }
                var Ids = [];
                for(var x in pickedBatches){
                    Ids.push(pickedBatches[x].BatchNo.Id);
                }
                
                console.log('Im Here at 452');
                var actionBatches = cmp.get("c.PreparePickBatchNos");
                actionBatches.setParams({
                    productId: prodId,
                    searchString: "",
                    siteID: site,
                    locId: loc,
                    lmt: reqQty,
                    batchIds: Ids
                });
                actionBatches.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        
                        if (response.getReturnValue().error != '') {
                            cmp.set("v.exceptionError", response.getReturnValue().error);
                            cmp.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                            cmp.set("v.showSpinnerItem", false);
                        } else {
                            cmp.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                        }
                        if (cmp.get("v.PickBatchNos").length > 0) cmp.set("v.disableAdd", false);
                        cmp.set("v.showSpinnerItem", false);
                        
                    }
                });
                $A.enqueueAction(actionBatches);
            }
            else{
                cmp.set("v.PickBatchNos", []);
                cmp.set("v.PickSerialNos", []);
            }
            
        }
        catch(e){console.log('Error in ChangeLocationmanual:',e);}
    },
    
    FindSerials: function (cmp, event) {
        console.log('entered find serials');
        
        var curIndex = cmp.get("v.currentIndex");
        console.log('currentIndex==>'+curIndex);
        
        var serialLengthLoc = cmp.get('v.listofProduct');
        console.log('serialLengthLoc==>'+JSON.stringify(serialLengthLoc));
        
        var serialLength = cmp.get('v.listofProduct')[curIndex].serials.length;
        console.log('serialLength==>'+serialLength);
        
        var pickedSerial = [];
        if(serialLength > 0){
            pickedSerial = cmp.get('v.listofProduct')[curIndex].serials;
            console.log('pickedSerial==>'+JSON.stringify(pickedSerial));
        }
        var Ids = [];
        for(var x in pickedSerial){
            Ids.push(pickedSerial[x].SerialNo.Id);
        }
        
        console.log('Im Here at 366');
        
        let callFindSerials = cmp.get("v.callFindSerials");
        let fromScanFlowforMultiPick = cmp.get("v.fromScanFlowforMultiPick");
        
        if((callFindSerials && fromScanFlowforMultiPick) || (!callFindSerials && !fromScanFlowforMultiPick)) {
            cmp.set("v.showSpinnerItem", true);
            cmp.set("v.exceptionError", '');
            cmp.set("v.disableAdd", true);
            
            let srchString = cmp.get('v.SearchSerialNos');
            console.log('srchString'+srchString);
            let prodId = cmp.get('v.selectedProductId');
            console.log('prodId'+prodId);
            let site = cmp.get("v.siteID");
            console.log('site'+site);
            let loc = cmp.get("v.Location");
            console.log('loc'+loc);
            let reqQty = cmp.get("v.requiredQty");
            console.log('reqQty'+reqQty);
            
            console.log('searchString'+cmp.get('v.SearchSerialNos'));
            let action = cmp.get("c.PreparePickSerialNos");
            
            action.setParams({
                productId: prodId,
                searchString: cmp.get('v.SearchSerialNos'),
                siteID: site,
                locId: loc,
                lmt: reqQty,
                serialIds: Ids
            });
            
            action.setCallback(this, function(response) {
                let state = response.getState();
                
                if (state === "SUCCESS") {
                    let result = JSON.stringify(response.getReturnValue());
                    console.log('result->'+result);
                    //cmp.set("v.PickSerialNos",[]);
                    cmp.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                    let selectedCount = result.PickSerialNos.filter(serial => serial.isSelected).length;
                    cmp.set("v.disableAdd", (selectedCount === 0));                        
                    cmp.set("v.showSpinnerItem", false);
                    if(result.error != '') {
                        
                        //cmp.set("v.PickSerialNos", result.error);
                        cmp.set("v.PickSerialNos", []);
                    }    
                }
            });
            
            $A.enqueueAction(action); 
            cmp.set("v.callFindSerials", false);
            cmp.set("v.fromScanFlowforMultiPick", false);
        }
    },
    
    FindBatches: function (cmp, event) {
        console.log('entered find batches');
        
        var curIndex = cmp.get("v.currentIndex");
        console.log('currentIndex==>'+curIndex);
        
        var batchLengthLoc = cmp.get('v.listofProduct');
        console.log('batchLengthLoc==>'+JSON.stringify(batchLengthLoc));
        
        var batchLength = cmp.get('v.listofProduct')[curIndex].batches.length;
        console.log('batchLength==>'+batchLength);
        
        var pickedBatch = [];
        if(batchLength > 0){
            pickedBatch = cmp.get('v.listofProduct')[curIndex].batches;
            console.log('pickedBatch==>'+JSON.stringify(pickedBatch));
        }
        var Ids = [];
        for(var x in pickedBatch){
            Ids.push(pickedBatch[x].BatchNo.Id);
        }
        
        console.log('Im Here at 588');
        
        let callFindBatches = cmp.get("v.callFindBatches");
        let fromScanFlowforMultiPick = cmp.get("v.fromScanFlowforMultiPick");
        
        if((callFindBatches && fromScanFlowforMultiPick) || (!callFindBatches && !fromScanFlowforMultiPick)) {
            cmp.set("v.showSpinnerItem", true);
            cmp.set("v.exceptionError", '');
            cmp.set("v.disableAdd", true);
            
            let srchString = cmp.get('v.SearchSerialNos');
            console.log('srchString'+srchString);
            let prodId = cmp.get('v.selectedProductId');
            console.log('prodId'+prodId);
            let site = cmp.get("v.siteID");
            console.log('site'+site);
            let loc = cmp.get("v.Location");
            console.log('loc'+loc);
            let reqQty = cmp.get("v.requiredQty");
            console.log('reqQty'+reqQty);
            
            console.log('searchString'+cmp.get('v.SearchSerialNos'));
            let action = cmp.get("c.PreparePickBatchNos");
            
            action.setParams({
                productId: prodId,
                searchString: cmp.get('v.SearchSerialNos'),
                siteID: site,
                locId: loc,
                lmt: reqQty,
                batchIds: Ids
            });
            
            action.setCallback(this, function(response) {
                let state = response.getState();
                
                if (state === "SUCCESS") {
                    let result = JSON.stringify(response.getReturnValue());
                    console.log('result->'+result);
                    //cmp.set("v.PickSerialNos",[]);
                    cmp.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                    let selectedCount = result.PickBatchNos.filter(batches => batches.isSelected).length;
                    cmp.set("v.disableAdd", (selectedCount === 0));                        
                    cmp.set("v.showSpinnerItem", false);
                    if(result.error != '') {
                        
                        //cmp.set("v.PickSerialNos", result.error);
                        cmp.set("v.PickBatchNos", []);
                    }    
                }
            });
            
            $A.enqueueAction(action); 
            cmp.set("v.callFindBatches", false);
            cmp.set("v.fromScanFlowforMultiPick", false);
        }
    },
    
    fetchProducts : function(component, event, helper) {
        console.log('searchItem : ',component.get('v.searchItem'));
        var globalsearch = component.get('v.globalProdSearch');
        console.log('globalsearch : ',globalsearch);
        helper.getSearchProducts(component);
    },
    
    fetchFamilyProducts : function(component, event, helper) {
        console.log('fetch family products called');
        console.log('searchItem : ',component.get('v.seachItemFmily'));
        if(component.get('v.seachItemFmily') == '--None--') component.set('v.seachItemFmily','');
        var globalsearch = component.get('v.globalProdSearch');
        console.log('globalsearch : ',globalsearch);
        helper.getSearchProducts(component);
        helper.familyFieldChange(component, event, helper);
    },
    
    fetchSubFamilyProducts : function(component, event, helper) {
        console.log('searchItem : ',component.get('v.subItemFmily'));
        if(component.get('v.subItemFmily') == '--None--') component.set('v.subItemFmily','');
        var globalsearch = component.get('v.globalProdSearch');
        console.log('globalsearch : ',globalsearch);
        helper.getSearchProducts(component);
    },
    
    handleQuantity : function(component, event, helper) {
        let value= event.getSource().get("v.value");
        var index = event.getSource().get("v.name");
        if(value != null && value != undefined && value != '' && index != null && index != undefined){
            let standProds = component.get('v.listofProduct');
            ///for(var x in standProds){
            for(var x = 0; x < standProds.length; x++){
                if(x == index){
                    console.log('in');
                    standProds[x].quantity = parseFloat(value);
                    if(standProds[x].unitPrice == null || standProds[x].unitPrice == '' || standProds[x].unitPrice == undefined) standProds[x].unitPrice = parseFloat(0);
                    if(standProds[x].taxPercent == null || standProds[x].taxPercent == '' || standProds[x].taxPercent == undefined) standProds[x].taxPercent = parseFloat(0);
                    let tax = (standProds[x].unitPrice /100) * standProds[x].taxPercent;
                    console.log('tax  bfr:  ',tax);
                    tax = tax * standProds[x].quantity;
                    standProds[x].taxAmount = tax.toFixed($A.get("$Label.c.DecimalPlacestoFixed"));
                    if(standProds[x].taxAmount == null || standProds[x].taxAmount == '' || standProds[x].taxAmount == undefined) standProds[x].taxAmount = parseFloat(0);
                    standProds[x].TotalPrice = (parseFloat(standProds[x].quantity) * parseFloat(standProds[x].unitPrice)) + parseFloat(standProds[x].taxAmount);
                    console.log('TotalPrice : ',standProds[x].TotalPrice);
                }
            }
            console.log('setting listofProduct here2');
            component.set('v.listofProduct',standProds);
        }
    },
    
    addProducts : function(component, event, helper) {
        console.log('addProducts called');
        component.set("v.showSpinner", true);
        
        try {
            component.set('v.successMsg', '');
            let customProds = component.get('v.ClistOfProducts');
            
            var selectedProds = component.get('v.selectedListOfProducts');
            if(!selectedProds.length>0){
                var getprodlist = component.get("v.listofProduct");
                for(var i in getprodlist){
                    if(getprodlist[i].checkSelected){
                        selectedProds.push(getprodlist[i]);
                    }
                }
                component.set('v.selectedListOfProducts',selectedProds);
            }
            
            let standProds = component.get('v.selectedListOfProducts');
            console.log('standProds---->', standProds.length);
            console.log('standProds---->', standProds);
            let productsToAdd = [];
            
            
            
            
            for (let x = 0; x < standProds.length; x++) {
                console.log('entered for loop');
                let serials = standProds[x].serials || [];
                console.log('serials:'+JSON.stringify(serials));
                let batches = standProds[x].batches || [];
                console.log('batches:'+JSON.stringify(batches));
                let serialsOfBatch = standProds[x].serialsOfBatch || [];
                console.log('serialsOfBatch:'+JSON.stringify(serialsOfBatch));
                //console.log('serials.ProductId==>'+serials.ProductId);
                console.log('standProds[x].Id==>'+standProds[x].Id);
                if (serials.length > 0) {
                    console.log('entered if add');
                    for (let s = 0; s < serials.length; s++) {
                        console.log('serials[s].ProductId==>'+serials[s].ProductId);
                        if(serials[s].ProductId == standProds[x].Id){
                            let toliadd = {};
                            toliadd.ItemsinStock = standProds[x].Available_Stock__c;
                            console.log('toliadd.ItemsinStock-->', toliadd.ItemsinStock);
                            //toliadd.Products__c = standProds[x].Id;
                            console.log('toliadd.Product__c===>', toliadd.Products__c);
                            if (standProds[x].ProductCode) toliadd.Products__r = { ProductCode: standProds[x].ProductCode };
                            toliadd.Name = standProds[x].Name;
                            toliadd.Products__c = standProds[x].Id;
                            toliadd.Quantity__c = 1; // Each serial number represents one unit
                            toliadd.Description__c = standProds[x].Description;
                            console.log('serials[s].id==>'+serials[s].SerialNo.Id);
                            toliadd.SerialNumber__c = serials[s].SerialNo.Id;
                            console.log('toliadd.SerialNumber__c '+toliadd.SerialNumber__c );    
                            toliadd.Name = serials[s].SerialNo.Name;
                            console.log('toliadd.Name = '+ serials[s].SerialNo.Name);
                            toliadd.availableQty  = serials[s].SerialQuantity;
                            toliadd. Quantity_requested__c  = serials[s].SerialQuantity;
                            console.log('toliadd.availableQty = '+ serials[s].SerialQuantity);
                            console.log('toliadd : ', toliadd);
                            productsToAdd.push(toliadd);
                        }
                    }
                } 
                else if (batches.length > 0) {
                    console.log('entered batch: ', batches.length);
                    for (let s = 0; s < batches.length; s++) {
                        if(batches[s].ProductId == standProds[x].Id){
                            let toliadd = {};
                            toliadd.ItemsinStock = standProds[x].Available_Stock__c;
                            console.log('batch toliadd.ItemsinStock-->', toliadd.ItemsinStock);
                            //toliadd.Products__c = standProds[x].Id;
                            console.log('batch toliadd.Product__c===>', toliadd.Products__c);
                            if (standProds[x].ProductCode) toliadd.Products__r = { ProductCode: standProds[x].ProductCode };
                            toliadd.Name = standProds[x].Name;
                            toliadd.Products__c = standProds[x].Id;
                            //toliadd.Quantity__c = 1; // Each serial number represents one unit
                            toliadd.Description__c = standProds[x].Description;
                            toliadd. Batch_Lot__c  = batches[s].BatchNo.Id;
                            toliadd.batchName = batches[s].BatchNo.Name;
                            console.log(' batch toliadd.Name = '+ batches[s].BatchNo.Name);
                            toliadd.availableQty  = batches[s].BatchQuantity;
                            console.log(' batch toliadd.availableQty = '+ batches[s].BatchQuantity);
                            console.log('batch toliadd : ', toliadd);
                            productsToAdd.push(toliadd);
                        }
                    }
                } 
                    else if (serialsOfBatch.length > 0){
                        console.log('entered serialsOfBatch: ', serialsOfBatch.length);
                        for (let s = 0; s < serialsOfBatch.length; s++) {
                            if(serialsOfBatch[s].ProductId == standProds[x].Id){
                                let toliadd = {};
                                toliadd.ItemsinStock = standProds[x].Available_Stock__c;
                                console.log('batch toliadd.ItemsinStock-->', toliadd.ItemsinStock);
                                //toliadd.Products__c = standProds[x].Id;
                                if (standProds[x].ProductCode) toliadd.Products__r = { ProductCode: standProds[x].ProductCode };
                                toliadd.Name = standProds[x].Name;
                                toliadd.Products__c = standProds[x].Id;
                                console.log('batch toliadd.Product__c===>', toliadd.Products__c);
                                toliadd.Quantity__c = 1; // Each serial number represents one unit
                                toliadd.Description__c = standProds[x].Description;
                                toliadd.Batch_Lot__c = serialsOfBatch[s].batchInfo.Id;
                                toliadd.batchName = serialsOfBatch[s].batchInfo.Name;
                                console.log('batchName==>'+serialsOfBatch[s].batchInfo.Name);
                                toliadd. SerialNumber__c  = serialsOfBatch[s].SerialNo.Id;
                                toliadd.Name = serialsOfBatch[s].SerialNo.Name;
                                console.log(' serialsOfBatch toliadd.Name = '+ serialsOfBatch[s].SerialNo.Name);
                                toliadd.availableQty  = serialsOfBatch[s].SerialQuantity;
                                toliadd.Quantity_requested__c = serialsOfBatch[s].SerialQuantity;
                                console.log(' serialsOfBatch toliadd.availableQty = '+ serialsOfBatch[s].SerialQuantity);
                                console.log('serialsOfBatch toliadd : ', toliadd);
                                productsToAdd.push(toliadd);
                            }
                        }
                        
                    }
                        else {
                            console.log('entered else')
                            let toliadd = {};
                            toliadd.availableQty = standProds[x].Available_Stock__c;
                            console.log('toliadd.ItemsinStock-->', toliadd.ItemsinStock);
                            toliadd.Products__c = standProds[x].Id;
                            console.log('toliadd.Products__c===>', toliadd.Products__c);
                            if (standProds[x].ProductCode) toliadd.Products__r = { ProductCode: standProds[x].ProductCode };
                            toliadd.Name = standProds[x].Name;
                            toliadd.Products__c = standProds[x].Id;
                            //toliadd.Quantity__c = standProds[x].quantity;
                            toliadd.Description__c = standProds[x].Description;
                            toliadd.Lead_Time_Days__c = standProds[x].LeadTime;
                            console.log('toliadd : ', toliadd);
                            productsToAdd.push(toliadd);
                        }
            }
            
            var NameLabel = $A.get('$Label.c.Enter_Name');
            for (let y = 0; y < customProds.length; y++) {
                let toliadd = {};
                if (customProds[y].Name && customProds[y].Name !== NameLabel) {
                    toliadd.Name = customProds[y].Name;
                    toliadd.Available_Stock__c = customProds[y].quantity;
                    toliadd.Quantity__c = customProds[y].quantity;
                    toliadd.Unit_Price__c = customProds[y].unitPrice;
                    toliadd.Tax_Rate__c = customProds[y].taxPercent;
                    toliadd.Tax__c = customProds[y].taxAmount;
                    toliadd.Total_Price__c = customProds[y].TotalPrice;
                    toliadd.Description__c = customProds[y].Description;
                    toliadd.CustomProd = customProds[y].CustomProd;
                    productsToAdd.push(toliadd);
                }
            }
            
            console.log('productsToAdd : ', productsToAdd.length);
            console.log('productsToAdd List: ', JSON.stringify(productsToAdd));
            
            if (productsToAdd.length > 0) {
                let tolilst = component.get('v.TOLI') || [];
                console.log('tolilst before: ', tolilst.length);
                tolilst = tolilst.concat(productsToAdd);
                console.log('tolilst after: ', tolilst.length);
                component.set('v.TOLI', tolilst);
                component.set('v.showAddProducts', false);
                component.set('v.selectedListOfProducts', []);
                component.set('v.successMsg', $A.get('$Label.c.Products_added_successfully'));
                window.setTimeout($A.getCallback(function() { component.set('v.successMsg', ''); }), 5000);
            } else {
                component.set('v.addProductsMsg', $A.get('$Label.c.Please_select_products_to_add'));
                console.log('add prodt msg'+ component.get('v.addProductsMsg'));
                window.setTimeout($A.getCallback(function() { component.set('v.addProductsMsg', ''); }), 2000);
            }
        } catch (err) {
            console.log('error : ', err);
        }
        component.set("v.showSpinner", false);
    },
    
    deletePoli :function(component, event, helper) {
        console.log('inside deletePoli fromRequisition: ',component.get('v.fromRequisition'));
        if(!component.get('v.fromRequisition')){
            component.set("v.reRenderPOLIS",false);
            console.log('inside deletePoli');
            var poliList =[]; 
            poliList=component.get("v.TOLI");
            console.log('poliList before~>',JSON.stringify(poliList));
            var index=event.getParam("Index"); //component.get("v.Index2del");
            poliList.splice(index,1);        
            console.log('poliList after~>',JSON.stringify(poliList));
            //component.set("v.poli",poliList);
            console.log('v.poli after~>',JSON.stringify(component.get("v.TOLI")));
            component.set("v.reRenderPOLIS",true);
            
            var items=component.get('v.TOLI');
            var amt=0;
            /* for(var x in items){
            console.log('inside loop');
            amt+=items[x].Quantity__c * items[x].Unit_Price__c 
        }
        console.log('amt:',amt);
        if(amt>=0) component.set("v.PO.Total_Amount__c",amt.toFixed(2));
        if(amt == 0){
            component.set("v.SubTotal",amt.toFixed(2));
            component.set("v.TotalTax",amt.toFixed(2));
            component.set("v.TotalAmount",amt.toFixed(2));
        }*/
            
            var itemToDel=component.get('v.itemToDel');
            itemToDel.push(event.getParam("itemToDelCurr"));
            console.log('itemToDelCurr in PO:',event.getParam("itemToDelCurr"));
            component.set('v.itemToDel',itemToDel);
            console.log('itemToDel:',component.get('v.itemToDel'));
            
            //$A.enqueueAction(updateTotalPrice.(component, event, helper));
            //component.set('v.itemToDel',event.getParam("itemToDel"));  
        }
        var a = component.get('c.updateTotalPrice');
        $A.enqueueAction(a);
        var taxtotal = component.get('c.updateTotalTax');
        $A.enqueueAction(taxtotal);
        
    },
    
    backToMainPage : function(component, event, helper) {
        component.set("v.showAddProducts",false);
    },
    
    toChannelchange : function(component, event, helper){
        var transfer = component.get("v.TO");
        var qry = 'AND Channel__c = \''+transfer.To_Channel__c+'\' AND Id != \''+transfer.Distribution_Channel__c+'\'';
        component.set("v.toDCqry",qry);
        if($A.util.isEmpty(transfer.To_Channel__c) || $A.util.isUndefinedOrNull(transfer.To_Channel__c)){
            console.log('toChannelchange going to null to DC');
            component.set("v.TO.To_Distribution_Channel__c",null);
        }
    },
    
    fromChannelchange : function(component, event, helper){
        var transfer = component.get("v.TO");
        if($A.util.isEmpty(transfer.Channel__c) || $A.util.isUndefinedOrNull(transfer.Channel__c)){
            console.log('fromChannelchange going to null from DC');
            component.set("v.TO.Distribution_Channel__c",null);
        }
    },
    
    deletetoli :function(component, event, helper) {
        console.log('entered delete toli')
        var toliList =[]; 
        toliList=component.get("v.TOLI");       
        var index=event.getParam("Index");
        toliList.splice(index,1);
        component.set("v.TOLI",toliList);
    },
    
    saveclick : function(component, event, helper) {
        component.set("v.showSpinner",true);
        component.set("v.disaSave",true);
        component.set("v.exceptionError",'');
        
        console.log('saveclick called');
        
        let newTO = JSON.stringify(component.get("v.TO"));
        let toliList = JSON.stringify(component.get("v.TOLI"));
        console.log('newTO JSON:', newTO);
        console.log('toliList JSON:', toliList);
        
        
        if(component.get("v.TO.Shipment_Type__c") == '--None--') component.set("v.TO.Shipment_Preference_Speed__c",'--None--');
        var currTo = component.get("v.TO");
        currTo.Active__c = true;
        if(currTo.Ready_To_Pick_Pack__c) component.set("v.TO.Status__c", 'Requested'); 
        if(component.get("v.Mtask") != null && component.get("v.Mtask") != undefined && component.get("v.Mtask") != ""){
            var task = component.get("v.Mtask");
            component.set("v.TO.Tasks__c", task.Id); 
            component.set("v.TO.Project__c", task.Project__c); 
            //currTo.Tasks__c = task.Id;
            //currTo.Project__c = task.Project__c;
        }
        //component.set("v.TO",currTo);
        var toli = component.get("v.TOLI");
        var toliLength = toli.length;
        var transfer = component.get("v.TO");
        var checkToSerBat = false;
        var errorMessage = '';
        var errbool = false;
        console.log('arsh before vals');
        if($A.util.isEmpty(transfer.Channel__c) || $A.util.isUndefinedOrNull(transfer.Channel__c)){
            errorMessage = $A.get('$Label.c.Please_select_a_Source_Channel');
            errbool = true;
        }else if($A.util.isEmpty(transfer.Distribution_Channel__c) || $A.util.isUndefinedOrNull(transfer.Distribution_Channel__c)){
            errorMessage = $A.get('$Label.c.Please_select_a_Source_Distribution_Channel');
            errbool = true;
        }else if($A.util.isEmpty(transfer.To_Channel__c) || $A.util.isUndefinedOrNull(transfer.To_Channel__c)){
            errorMessage = $A.get('$Label.c.Please_Select_a_Channel_to_transfer');
            errbool = true;
        }else if($A.util.isEmpty(transfer.To_Distribution_Channel__c) || $A.util.isUndefinedOrNull(transfer.To_Distribution_Channel__c)){
            errorMessage = $A.get('$Label.c.Please_Select_a_Distribution_Channel_to_transfer');
            errbool = true;
        }else if(!toliLength > 0){
            errorMessage = $A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item');
            errbool = true;
        }
        
        if(errbool == false){
            console.log('2 errbool false');
            if(toliLength > 0){
                if(component.get("v.processSNBatch")) checkToSerBat  = helper.validateTOLISerBat(component, event);
                var toliqty = component.get("v.TOLI");
                for(var i in toliqty){
                    if($A.util.isEmpty(toliqty[i].Products__c) || $A.util.isUndefinedOrNull(toliqty[i].Products__c)){
                        errorMessage = $A.get('$Label.c.Please_select_a_product_for_the_line_item');
                        errbool = true;
                        break;
                    }
                    if($A.util.isEmpty(toliqty[i].Quantity_requested__c) || $A.util.isUndefinedOrNull(toliqty[i].Quantity_requested__c)){
                        errorMessage = $A.get('$Label.c.Please_enter_a_valid_quantity_for_the_line_item');
                        errbool = true;
                        break;
                    }
                    if($A.util.isEmpty(toliqty[i].availableQty) || $A.util.isUndefinedOrNull(toliqty[i].availableQty)){
                        errorMessage = $A.get('$Label.c.Available_quantity_of_the_stock_cannot_be_empty');
                        errbool = true;
                        break;
                    }
                    if(toliqty[i].Quantity_requested__c > toliqty[i].availableQty){
                        console.log('toliqty[i].Quantity_requested__c==>'+toliqty[i].Quantity_requested__c);
                        console.log('toliqty[i].availableQty==>'+toliqty[i].availableQty);
                        errorMessage = $A.get('$Label.c.Requested_quantity_is_more_than_available_quantity_for_the_line_items');
                        errbool = true;
                        break;
                    }
                    if(toliqty[i].Quantity_requested__c <= 0){
                        errorMessage = $A.get('$Label.c.Requested_quantity_should_be_greater_than_0_for_the_line_items');
                        errbool = true;
                        break;
                    }
                }
            }else{
                errorMessage = $A.get('$Label.c.PH_DebNote_Please_add_a_Line_Item');
                errbool = true;
            }
            if(toliLength > 0 && !checkToSerBat && component.get("v.processSNBatch")){
                errorMessage = $A.get('$Label.c.Please_select_a_Serial_Lot_for_the_line_items');
                errbool = true;
            }
        }
        
        if(errbool && errorMessage != ''){
            console.log('saveclick errbool true');
            component.set("v.showSpinner",false);
            component.set("v.disaSave",false);
            component.set("v.exceptionError", errorMessage);
        }else{
            if(errbool == false) helper.saveTOandTOLI(component, event);
        }
    },
    
    goBackTask : function(component, event) {
        $A.createComponent("c:AddMilestoneTask",{
            "aura:id" : "taskCmp",
            "projectId" : component.get("v.projectId"),
            "taskId" : component.get("v.Mtask.Id"),
            "newTask" : component.get("v.Mtask"),
            "currentMilestones" : component.get("v.currentMilestones"),
            "currentProject" : component.get("v.currentProject")
        },function(newCmp, status, errorMessage){
            if (status === "SUCCESS") {
                var body = component.find("body");
                body.set("v.body", newCmp);
            }
        });
    },
    
    cancelclick : function(component, event, helper) {
        window.history.back();
    },
    
    closeError : function(component, event, helper) {
        component.set("v.exceptionError","");
    },
    
    fromDCchange : function(component, event, helper) {
        console.log('fromDCchange called');
        var chn = component.get('v.TO.Channel__c');
        var Dchn = component.get('v.TO.Distribution_Channel__c');
        console.log('chn : '+chn);
        console.log('Dchn : '+Dchn);
        if(chn != '' && chn != null && Dchn != null && Dchn != '' && chn != undefined && Dchn != undefined){
            var action = component.get("c.getSitefromDC");
            action.setParams({'DChannel' : Dchn});
            action.setCallback(this, function(response) {
                if(response.getState() === "SUCCESS") {
                    var empData = response.getReturnValue();
                    var transfer = component.get("v.TO");
                    //transfer.Channel__c = empData.channel;
                    //transfer.Distribution_Channel__c = empData.distributionChannel.Id;
                    if(!$A.util.isEmpty(empData.distributionChannel.Id) && !$A.util.isUndefinedOrNull(empData.distributionChannel.Id)){
                        if(!$A.util.isEmpty(empData.distributionChannel.Site__c) && !$A.util.isUndefinedOrNull(empData.distributionChannel.Site__c)){
                            component.set("v.TO.From_Site__c",empData.distributionChannel.Site__c);
                            if(!$A.util.isEmpty(empData.distributionChannel.Site__r.Address__c) && !$A.util.isUndefinedOrNull(empData.distributionChannel.Site__r.Address__c)){
                                component.set("v.TO.From_Address__c",empData.distributionChannel.Site__r.Address__c);
                            }
                        }
                    }
                    component.set("v.showSpinner",false);
                }
                else{
                    component.set("v.showSpinner",false);
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            setTimeout(function(){ component.set("v.exceptionError",errors[0].message); }, 5000);
                        }
                    } else {
                        setTimeout(function(){ component.set("v.exceptionError","Unknown error"); }, 5000);
                    }
                }
                component.set("v.showSpinner",false);
            });
            $A.enqueueAction(action);
        }
        //helper.setChannelandDC(component, event);
    },
    
    parentFieldChange : function(component, event, helper) {
        var controllerValue = component.find("parentField").get("v.value");// We can also use event.getSource().get("v.value")
        var pickListMap = component.get("v.depnedentFieldMap");
        
        if (controllerValue != '--None--') {
            //get child picklist value
            var childValues = pickListMap[controllerValue];
            var childValueList = [];
            childValueList.push('--None--');
            for (var i = 0; i < childValues.length; i++) {
                childValueList.push(childValues[i]);
            }
            // set the child list
            component.set("v.listDependingValues", childValueList);
            
            if(childValues.length > 0){
                component.set("v.bDisabledDependentFld" , false);  
            }else{
                component.set("v.bDisabledDependentFld" , true); 
            }
            
        } else {
            component.set("v.listDependingValues", ['--None--']);
            component.set("v.bDisabledDependentFld" , true);
        }
    },
    
    checkready2pick : function(component, event, helper) {
        var currTO = component.get('v.TO');
        var getcheck = event.getSource().get('v.checked');
        console.log('getcheck : '+getcheck);
        currTO.Ready_To_Pick_Pack__c = getcheck;
        component.set('v.TO',currTO);   
    },
    
    /* ChangeLocationmanual : function (cmp, event) {
        console.log('ChangeLocationmanual')
        //if((cmp.get("v.callChangeLocation") && cmp.get("v.fromScanFlowforMultiPick")) ||(!cmp.get("v.callChangeLocation") && !cmp.get("v.fromScanFlowforMultiPick"))) {
        cmp.set("v.showSpinnerItem",true);
        console.log('inside changeLocation');
        var prodId = cmp.get('v.selectedProductId');
        console.log('prodId-->'+prodId);
        var site  = cmp.get("v.siteID");
        console.log('site-->'+site);
        var loc  = cmp.get("v.Location");
        console.log('loc-->'+loc);
        cmp.set('v.item.From_Location__c',loc);
        var reqQty = cmp.get("v.requiredQty");
        console.log('reqQty : ',reqQty);
        var action = cmp.get("c.PreparePickSerialNos");
        action.setParams({
            productId: prodId,
            searchString: "",
            siteID : site,
            locId : loc,
            lmt : reqQty,
            serialIds : []
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert(state);
            if (state === "SUCCESS") {
                //alert(response.getReturnValue().exceptionError);
                if(response.getReturnValue().error != ''){
                    cmp.set("v.exceptionError", response.getReturnValue().error);
                    // cmp.set("v.PickSerialNos",[]);
                    console.log('result.PickSerialNos'+JSON.stringify(response.getReturnValue().PickSerialNos));
                    component.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                    
                    cmp.set("v.showSpinnerItem",false);
                } else{
                    //alert('PickSerialNos : '+response.getReturnValue().PickSerialNos.length);
                    //alert('PickSelectedSerialNos : '+response.getReturnValue().PickSelectedSerialNos.length);
                    console.log('response.getReturnValue().PickSerialNos~>'+JSON.stringify(response.getReturnValue().PickSerialNos));
                    cmp.set("v.PickSerialNos", response.getReturnValue().PickSerialNos);
                    if(cmp.get("v.PickSerialNos").length >0)cmp.set("v.disableAdd",false);
                    cmp.set("v.showSpinnerItem",false);
                    
                    
                }
            }
        });
        $A.enqueueAction(action);
        //cmp.set("v.callChangeLocation",false);
        // }
         
        
        var action = cmp.get("c.PreparePickBatchNos");
        action.setParams({
            productId: prodId,
            searchString: "",
            siteID : site,
            locId : loc,
            lmt : reqQty,
            serialIds : []
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert(state);
            if (state === "SUCCESS") {
                //alert(response.getReturnValue().exceptionError);
                if(response.getReturnValue().error != ''){
                    cmp.set("v.exceptionError", response.getReturnValue().error);
                    // cmp.set("v.PickSerialNos",[]);
                    console.log('result.PickBatchNos'+JSON.stringify(response.getReturnValue().PickBatchNos));
                    component.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                    
                    cmp.set("v.showSpinnerItem",false);
                } else{
                    //alert('PickSerialNos : '+response.getReturnValue().PickSerialNos.length);
                    //alert('PickSelectedSerialNos : '+response.getReturnValue().PickSelectedSerialNos.length);
                    console.log('response.getReturnValue().PickBatchNos~>'+JSON.stringify(response.getReturnValue().PickBatchNos));
                    cmp.set("v.PickBatchNos", response.getReturnValue().PickBatchNos);
                    if(cmp.get("v.PickBatchNos").length >0)cmp.set("v.disableAdd",false);
                    cmp.set("v.showSpinnerItem",false);
                    
                    
                }
            }
        });
        $A.enqueueAction(action);
         
    },*/
        
    selectAllSerials : function (cmp,event) {
        console.log('selectAllSerials')
        var checkedval = event.getSource().get('v.checked');
        cmp.set('v.selectAllSerials', checkedval);
        var obj = cmp.get("v.PickSerialNos");
        var showSerialsCount = cmp.get("v.requiredQty");
        //alert(showSerialsCount);
        var i = 0;
        for(var x in obj){
            if(i < showSerialsCount){
                obj[x].isSelected = checkedval;
                i++;
            }
        }
        //alert(showSerialsCount);
        cmp.set("v.PickSerialNos", obj);
        if(checkedval) cmp.set("v.disableAdd", false);
    },
    
    selectAllBatches : function (cmp,event) {
        console.log('selectAllBatches');
        var checkedval = event.getSource().get('v.checked');
        cmp.set('v.selectAllBatches', checkedval);
        var obj = cmp.get("v.PickBatchNos");
        var showBatchesCount = cmp.get("v.requiredQty");
        //alert(showBatchesCount);
        var i = 0;
        for(var x in obj){
            if(i < showBatchesCount){
                obj[x].isSelected = checkedval;
                i++;
            }
        }
        //alert(showBatchesCount);
        cmp.set("v.PickBatchNos", obj);
        if(checkedval) cmp.set("v.disableAdd", false);
    },
    
    selectAllSerialsOfBatch : function(cmp,event){
        console.log('selectAllSerialsOfBatch')
        var checkedval = event.getSource().get('v.checked');
        cmp.set('v.selectAllSerialsOfBatch', checkedval);
        var obj = cmp.get("v.PickBatchSerialNos");
        var showSerialsCount = cmp.get("v.requiredQty");
        console.log('showSerialsCount--'+showSerialsCount);
        //alert(showSerialsCount);
        var i = 0;
        for(var x in obj){
            if(i < showSerialsCount){
                obj[x].isSelected = checkedval;
                i++;
            }
        }
        //alert(showSerialsCount);
        cmp.set("v.PickBatchSerialNos", obj);
        if(checkedval) cmp.set("v.disableAdd", false);
    },
    
    PickSerialNosDiv : function (cmp, event) {
        console.log('serial pickkkk')
        cmp.set("v.showSpinnerItem",true);
        var SId = event.currentTarget.getAttribute('data-serialId');
        //var BId = event.currentTarget.getAttribute('data-BatchId');
        var obj = cmp.get("v.PickSerialNos");
        console.log('obj serial'+JSON.stringify(obj));
        var selectedCount = 0;
        for(var x in obj){
            if(SId == obj[x].SerialNo.Id) {
                obj[x].isSelected = !obj[x].isSelected;
            }
            if(obj[x].isSelected) selectedCount++;
        }
        /*
        for(var y in obj){
            if(BId == obj[y].BatchNo.Id) {
                obj[y].isSelected = !obj[y].isSelected;
            }
            if(obj[y].isSelected) selectedCount++;
        }*/
        cmp.set("v.disableAdd", (selectedCount == 0));
        cmp.set("v.PickSerialNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    PickSerialBatchNosDiv : function (cmp, event) {
        console.log('serial pick for batch');
        cmp.set("v.showSpinnerItem",true);
        var SId = event.currentTarget.getAttribute('data-serialId');
        var obj = cmp.get("v.PickBatchSerialNos");
        console.log('obj serial'+JSON.stringify(obj));
        var selectedCount = 0;
        for(var x in obj){
            if(SId == obj[x].SerialNo.Id) {
                obj[x].isSelected = !obj[x].isSelected;
            }
            if(obj[x].isSelected) selectedCount++;
        }
        cmp.set("v.disableAdd", (selectedCount == 0));
        cmp.set("v.PickBatchSerialNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    PickSelectedSerialsOfBatchNosDiv : function (cmp, event) {
        console.log('selected serial pick for batch');
        cmp.set("v.showSpinnerItem",true);
        var SId = event.currentTarget.getAttribute('data-serialId');
        var obj = cmp.get("v.PickSelectedSerialsOfBatchNos");
        var selectedCount = 0;
        for(var x in obj){
            if(SId == obj[x].SerialNo.Id) obj[x].isSelected = !obj[x].isSelected;
            if(obj[x].isSelected) selectedCount++;
        }
        cmp.set("v.disableRemove", !(selectedCount > 0));
        cmp.set("v.PickSelectedSerialsOfBatchNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    PickBatchNosDiv : function (cmp, event) {
        console.log('entered pickkkk batch');
        cmp.set("v.showSpinnerItem",true);
        var BId = event.currentTarget.getAttribute('data-batchId');
        var obj = cmp.get("v.PickBatchNos");
        console.log('obj batch'+JSON.stringify(obj));
        var selectedCount = 0;
        
        for (var i = 0; i < obj.length; i++) {
            if (BId == obj[i].BatchNo.Id) {
                obj[i].isSelected = !obj[i].isSelected;
                console.log('Toggled isSelected for Batch ID: ' + BId);
            }
            if (obj[i].isSelected) {
                selectedCount++;
            }
        }
        
        cmp.set("v.disableAdd", (selectedCount == 0));
        cmp.set("v.PickBatchNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    PickSelectedSerialNosDiv: function(cmp, event) {
        cmp.set("v.showSpinnerItem",true);
        var SId = event.currentTarget.getAttribute('data-serialId');
        var obj = cmp.get("v.PickSelectedSerialNos");
        var selectedCount = 0;
        for(var x in obj){
            if(SId == obj[x].SerialNo.Id) obj[x].isSelected = !obj[x].isSelected;
            if(obj[x].isSelected) selectedCount++;
        }
        cmp.set("v.disableRemove", !(selectedCount > 0));
        cmp.set("v.PickSelectedSerialNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    PickSelectedBatchNosDiv: function(cmp, event) {
        cmp.set("v.showSpinnerItem",true);
        var BId = event.currentTarget.getAttribute('data-batchId');
        var obj = cmp.get("v.PickSelectedBatchNos");
        console.log('obj1'+JSON.stringify(obj));
        var selectedCount = 0;
        for(var x in obj){
            if(BId == obj[x].BatchNo.Id) obj[x].isSelected = !obj[x].isSelected;
            if(obj[x].isSelected) selectedCount++;
        }
        cmp.set("v.disableRemove", !(selectedCount > 0));
        cmp.set("v.PickSelectedBatchNos", obj);
        cmp.set("v.showSpinnerItem",false);
    },
    
    AddSerials : function (cmp, event) {
        if((cmp.get("v.callAddSerials") && cmp.get("v.fromScanFlowforMultiPick")) ||(!cmp.get("v.callAddSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
            console.log('Inside AddSerials');
            cmp.set("v.disableAdd", false);
            var objSource = cmp.get("v.PickSerialNos");
            console.log('objSource'+JSON.stringify(objSource));
            var objDestn = cmp.get("v.PickSelectedSerialNos");
            console.log('objDestn'+JSON.stringify(objDestn));
            var i = 0;
            
            while (i < objSource.length) {
                if (objSource[i].isSelected) {
                    objSource[i].isSelected = false;
                    objDestn.unshift(objSource[i]);
                    objSource.splice(i, 1);
                } else {
                    ++i;
                }
            }
            
            cmp.set("v.PickSerialNos",objSource);
            cmp.set("v.PickSelectedSerialNos",objDestn);
            cmp.set('v.selectAllSerials', false);
            cmp.set("v.callAddSerials",false);
            cmp.set("v.fromScanFlowforMultiPick",false);
        }
        //component.set("v.callAddSerials",true);
    },
    
    RemoveSerials: function (cmp, event) {
        try{
            if((cmp.get("v.callRemoveAllSerials") && cmp.get("v.fromScanFlowforMultiPick")) ||(!cmp.get("v.callRemoveAllSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('Inside RemoveSerials');
                
                cmp.set("v.disableRemove", true);
                var objSource = cmp.get("v.PickSelectedSerialNos");
                console.log('objSource'+JSON.stringify(objSource));
                var objDestn = cmp.get("v.PickSerialNos");
                console.log('objDestn'+JSON.stringify(objDestn));
                var i = 0;
                while (i < objSource.length) {
                    console.log('entered while');
                    if (objSource[i].isSelected) {
                        console.log('entered if');
                        objSource[i].isSelected = false;
                        objDestn.unshift(objSource[i]);
                        objSource.splice(i, 1);
                    } else {
                        ++i;
                    }
                }
                cmp.set("v.PickSerialNos",objDestn);
                cmp.set("v.PickSelectedSerialNos",objSource);
                cmp.set('v.selectAllSerials', false);
                cmp.set("v.callRemoveAllSerials",false);
                cmp.set("v.fromScanFlowforMultiPick",false);    
            } 
        }catch(e){
            console.log(e);
        }
        
    },
    
    RemoveAllSerials: function (cmp, event) {
        var objSource = cmp.get("v.PickSelectedSerialNos");
        var objDestn = cmp.get("v.PickSerialNos");
        var i = 0;
        while (i < objSource.length) {
            objSource[i].isSelected = false;
            objDestn.unshift(objSource[i]);
            objSource.splice(i, 1);
        }
        cmp.set("v.PickSerialNos",objDestn);
        cmp.set("v.PickSelectedSerialNos",objSource);
        cmp.set('v.selectAllSerials', false);
    },
    
    AddBatches: function (cmp, event) {
        if ((cmp.get("v.callAddBatches") && cmp.get("v.fromScanFlowforMultiPick")) || (!cmp.get("v.callAddBatches") && !cmp.get("v.fromScanFlowforMultiPick"))) {
            console.log('Inside AddBatches');
            cmp.set("v.disableAdd", false);
            var objSource = cmp.get("v.PickBatchNos");
            console.log('objSource'+JSON.stringify(objSource));
            var objDestn = cmp.get("v.PickSelectedBatchNos");
            console.log('objDestn add'+JSON.stringify(objDestn));
            var i = 0;
            
            while (i < objSource.length) {
                console.log('entered while');
                if (objSource[i].isSelected) {
                    console.log('entered if');
                    objSource[i].isSelected = false;
                    objDestn.unshift(objSource[i]);
                    objSource.splice(i, 1);
                } else {
                    ++i;
                }
            }
            
            cmp.set("v.PickBatchNos", objSource);
            cmp.set("v.PickSelectedBatchNos", objDestn);
            cmp.set('v.selectAllBatches', false);
            cmp.set("v.callAddBatches", false);
            cmp.set("v.fromScanFlowforMultiPick", false); 
        }
    },
    
    RemoveBatches: function (cmp, event) {
        try {
            if ((cmp.get("v.callRemoveAllBatches") && cmp.get("v.fromScanFlowforMultiPick")) || (!cmp.get("v.callRemoveAllBatches") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('Inside RemoveBatches');
                
                cmp.set("v.disableRemove", true);
                var objSource = cmp.get("v.PickSelectedBatchNos");
                var objDestn = cmp.get("v.PickBatchNos");
                var i = 0;
                while (i < objSource.length) {
                    if (objSource[i].isSelected) {
                        objSource[i].isSelected = false;
                        objDestn.unshift(objSource[i]);
                        objSource.splice(i, 1);
                    } else {
                        ++i;
                    }
                }
                cmp.set("v.PickBatchNos", objDestn);
                cmp.set("v.PickSelectedBatchNos", objSource);
                cmp.set('v.selectAllBatches', false);
                cmp.set("v.callRemoveAllBatches", false);
                cmp.set("v.fromScanFlowforMultiPick", false);
            }
        } catch (e) {
            console.log(e);
        }
    },
    
    RemoveAllBatches: function (cmp, event) {
        var objSource = cmp.get("v.PickSelectedBatchNos");
        var objDestn = cmp.get("v.PickBatchNos");
        var i = 0;
        while (i < objSource.length) {
            objSource[i].isSelected = false;
            objDestn.unshift(objSource[i]);
            objSource.splice(i, 1);
        }
        cmp.set("v.PickBatchNos", objDestn);
        cmp.set("v.PickSelectedBatchNos", objSource);
        cmp.set('v.selectAllBatches', false);
    },
    
    AddSerialsOfBatch : function (cmp, event) {
        if((cmp.get("v.callAddSerials") && cmp.get("v.fromScanFlowforMultiPick")) ||(!cmp.get("v.callAddSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
            console.log('Inside AddSerialsOfBatch');
            cmp.set("v.disableAdd", false);
            var objSource = cmp.get("v.PickBatchSerialNos");
            console.log('objSource'+JSON.stringify(objSource));
            var objDestn = cmp.get("v.PickSelectedSerialsOfBatchNos");
            console.log('objDestn'+JSON.stringify(objDestn));
            var i = 0;
            
            while (i < objSource.length) {
                if (objSource[i].isSelected) {
                    objSource[i].isSelected = false;
                    objDestn.unshift(objSource[i]);
                    objSource.splice(i, 1);
                } else {
                    ++i;
                }
            }
            
            cmp.set("v.PickBatchSerialNos",objSource);
            cmp.set("v.PickSelectedSerialsOfBatchNos",objDestn);
            cmp.set('v.selectAllSerials', false);
            cmp.set("v.callAddSerials",false);
            cmp.set("v.fromScanFlowforMultiPick",false);
        }
    },
    
    RemoveSerialsOfBatch : function (cmp, event) {
        try{
            if((cmp.get("v.callRemoveAllSerials") && cmp.get("v.fromScanFlowforMultiPick")) ||(!cmp.get("v.callRemoveAllSerials") && !cmp.get("v.fromScanFlowforMultiPick"))) {
                console.log('Inside RemoveSerialsOfBatch');
                
                cmp.set("v.disableRemove", true);
                var objSource = cmp.get("v.PickSelectedSerialsOfBatchNos");
                console.log('objSource'+JSON.stringify(objSource));
                var objDestn = cmp.get("v.PickBatchSerialNos");
                console.log('objDestn'+JSON.stringify(objDestn));
                var i = 0;
                while (i < objSource.length) {
                    console.log('entered while');
                    if (objSource[i].isSelected) {
                        console.log('entered if');
                        objSource[i].isSelected = false;
                        objDestn.unshift(objSource[i]);
                        objSource.splice(i, 1);
                    } else {
                        ++i;
                    }
                }
                cmp.set("v.PickBatchSerialNos",objDestn);
                cmp.set("v.PickSelectedSerialsOfBatchNos",objSource);
                cmp.set('v.selectAllSerials', false);
                cmp.set("v.callRemoveAllSerials",false);
                cmp.set("v.fromScanFlowforMultiPick",false);    
            } 
        }catch(e){
            console.log(e);
        }
    },
    
    RemoveAllSerialsOfBatch : function (cmp, event) {
        var objSource = cmp.get("v.PickSelectedSerialsOfBatchNos");
        var objDestn = cmp.get("v.PickBatchSerialNos");
        var i = 0;
        while (i < objSource.length) {
            objSource[i].isSelected = false;
            objDestn.unshift(objSource[i]);
            objSource.splice(i, 1);
        }
        cmp.set("v.PickBatchSerialNos", objDestn);
        cmp.set("v.PickSelectedSerialsOfBatchNos", objSource);
        cmp.set('v.selectAllBatches', false);
    },
    
    CloseMyModalPickSerialBatch : function (cmp, event) {
        console.log('enetered CloseMyModalPickSerial');
        //$A.util.removeClass(cmp.find("myModalPickSerial"), 'slds-fade-in-open');
        //$A.util.removeClass(cmp.find("myModalMOSerialBackDrop"),"slds-backdrop_open");
        cmp.set("v.PickSerialNos",[]);
        cmp.set("v.PickBatchNos",[]);
        cmp.set("v.PickBatchNos",[]);
        cmp.set("v.PickSelectedBatchNos",[]);
        cmp.set("v.Location",null);
        cmp.set("v.isModalOpen",false);
        cmp.set("v.showAddProducts",true); 
    },
    
    FindSerialsOfBatch: function (cmp, event) {
        console.log('entered find serials of batch');
        
        let callFindSerials = cmp.get("v.callFindSerials");
        let fromScanFlowforMultiPick = cmp.get("v.fromScanFlowforMultiPick");
        
        if((callFindSerials && fromScanFlowforMultiPick) || (!callFindSerials && !fromScanFlowforMultiPick)) {
            cmp.set("v.showSpinnerItem", true);
            cmp.set("v.exceptionError", '');
            cmp.set("v.disableAdd", true);
            
            let srchString = cmp.get('v.SearchSerialNosOfBatch');
            console.log('srchString'+srchString);
            let prodId = cmp.get('v.selectedProductId');
            console.log('prodId'+prodId);
            let site = cmp.get("v.siteID");
            console.log('site'+site);
            let loc = cmp.get("v.Location");
            console.log('loc'+loc);
            let reqQty = cmp.get("v.requiredQty");
            console.log('reqQty'+reqQty);
            var batchId = cmp.get('v.item.Batch_Lot__c');
            console.log('batchId'+batchId);
            
            var curIndex = cmp.get("v.currentIndex");
            console.log('currentIndex==>'+curIndex);
            
            var sOfBLength = cmp.get('v.listofProduct');
            console.log('sOfBLength==>'+JSON.stringify(sOfBLength));
            
            var serialOfBatchLength = cmp.get('v.listofProduct')[curIndex].serialsOfBatch.length;
            console.log('serialOfBatchLength==>'+serialOfBatchLength);
            
            var pickedSerialOfBatch = [];
            if(serialOfBatchLength > 0){
                pickedSerialOfBatch = cmp.get('v.listofProduct')[curIndex].serials;
                console.log('pickedSerialOfBatch==>'+JSON.stringify(pickedSerialOfBatch));
            }
            var Ids = [];
            for(var x in pickedSerialOfBatch){
                Ids.push(pickedSerialOfBatch[x].SerialNo.Id);
            }
            
            console.log('Im Here at 1784');
            
            console.log('searchString'+cmp.get('v.SearchSerialNosOfBatch'));
            let action = cmp.get("c.PreparePickSerialNosForBatch");
            
            action.setParams({
                productId: prodId,
                searchString: cmp.get('v.SearchSerialNosOfBatch'),
                batchId : batchId,
                siteID: site,
                locId: loc,
                lmt: reqQty,
                serialIds: Ids
            });
            
            action.setCallback(this, function(response) {
                let state = response.getState();
                
                if (state === "SUCCESS") {
                    let result = JSON.stringify(response.getReturnValue());
                    console.log('result->'+result);
                    //cmp.set("v.PickSerialNos",[]);
                    cmp.set("v.PickBatchSerialNos", response.getReturnValue().PickBatchSerialNos);
                    let selectedCount = result.PickBatchSerialNos.filter(serialsOfBatch => serialsOfBatch.isSelected).length;
                    cmp.set("v.disableAdd", (selectedCount === 0));                        
                    cmp.set("v.showSpinnerItem", false);
                    if(result.error != '') {
                        
                        //cmp.set("v.PickSerialNos", result.error);
                        cmp.set("v.PickBatchSerialNos", []);
                    }    
                }
            });
            
            $A.enqueueAction(action); 
            cmp.set("v.callFindSerials", false);
            cmp.set("v.fromScanFlowforMultiPick", false);
        }
    },
    
    CloseMyModalPickSerialBatch : function (cmp, event) {
        //$A.util.removeClass(cmp.find("myModalPickSerial"), 'slds-fade-in-open');
        //$A.util.removeClass(cmp.find("myModalMOSerialBackDrop"),"slds-backdrop_open");
        cmp.set("v.PickSerialNos",[]);
        cmp.set("v.PickBatchNos",[]);
        cmp.set("v.PickBatchSerialNos",[]);       	
        cmp.set("v.PickSelectedBatchNos",[]);
        cmp.set("v.Location",null);
        cmp.set("v.isModalOpen",false);
        cmp.set("v.isSerialBatchOpen",false);
        cmp.set("v.showAddProducts",true); 
    },
    
    
    
    /*fetchInventory: function (component, event, helper) {
        
        try{
            console.log('scannedValueChanged : ',component.get('v.scannedValueChanged'));
            console.log('StopfecthInventory : ',component.get('v.StopfecthInventory'));
            console.log('fromMultipick : ',component.get('v.fromMultipick'));
            if(!component.get('v.StopfecthInventory') && !component.get('v.fromMultipick')){
                if(!component.get('v.scannedValueChanged')){
                    if((component.get('v.item') != undefined && component.get('v.item') != {}) && component.get("v.proceedChangeHandler")){
                        console.log('fetchInventory called');
                        component.set("v.showSpinnerItem",true);
                        
                        component.set("v.proceedChangeHandler",false);
                        
                        //Commented by parveez on 22-jan-24 for preventing recursive execution of the code and setting values.
                        
                        var currProd = component.get('v.item.Products__c');
                        var batch = component.get('v.item.Batch_Lot__c'); 
                        var fromLocation = component.get('v.item.From_Location__c');
                        var serial = component.get('v.item.Serial_Number__c');
                        console.log('currProd',currProd);
                        console.log('fromLocation',fromLocation);
                        console.log('batch',batch);
                        console.log('serial',serial);
                        console.log('siteID',component.get("v.siteID"));
                        var action = component.get("c.fetchProductSiteInvStock");
                        action.setParams({
                            currProdId: currProd,
                            site: component.get("v.siteID"),
                            fromLocation: fromLocation,
                            batch: batch,
                            serial: serial
                        });
                        console.log('before fetchInventory setCallBack',component.get("v.item"));
                        action.setCallback(this, $A.getCallback(function(response) {//function (response) 
                            console.log('After fetchInventory setCallBack');
                            if (response.getState() == "SUCCESS") {
                                console.log('fetchInventory success');
                                console.log('arshad fetchInventory response.getReturnValue() : ',response.getReturnValue());
                                component.set('v.item.Available_Stock__c', response.getReturnValue().totalQuantity);
                                component.set('v.item.Product__r.Serialise__c', response.getReturnValue().isSerial);
                                component.set('v.item.Product__r.Lot_Tracked__c', response.getReturnValue().isBatch);
                                component.set('v.item.Inventory_Stock__c', response.getReturnValue().inventory);
                                var batch = response.getReturnValue().batchId;
                                if(response.getReturnValue().isBatch && response.getReturnValue().isSerial && component.get('v.item.Serial_Number__c') != null && component.get('v.item.Serial_Number__c') != '' && component.get('v.item.Serial_Number__c') != undefined){
                                    if(component.get('v.item.Batch_Lot__c') == null || component.get('v.item.Batch_Lot__c') == '' || component.get('v.item.Batch_Lot__c') == undefined) component.set('v.item.Batch_Lot__c',batch);
                                }
                                if (response.getReturnValue().isSerial && response.getReturnValue().totalQuantity > 0) {
                                    component.set('v.item.Available_Stock__c', 1);
                                    component.set('v.item.Quantity__c',response.getReturnValue().totalQuantity);
                                }
                                var availLocIdsfilter = '';
                                var availLocIds = [];
                                availLocIds = response.getReturnValue().availLocIds;
                                console.log('praveez Location Id length',availLocIds.length);
                                if(availLocIds.length > 0){
                                    for(var obj in availLocIds){
                                        if(obj == 0) availLocIdsfilter = ' And ( Id = \''+availLocIds[obj]+'\' ';
                                        else availLocIdsfilter += ' Or Id = \''+availLocIds[obj]+'\' ';
                                    }
                                    availLocIdsfilter += ') ';
                                } else availLocIdsfilter = ' AND Id = null ';
                                //availLocIdsfilter += ' AND Site__c =\''+component.get("v.siteID")+'\' ';
                                
                                console.log('praveez Location Filter:',availLocIdsfilter);
                                
                                var availBatchIdsfilter = '';
                                var availBatchIds = [];
                                availBatchIds = response.getReturnValue().availBatchIds;
                                if(availBatchIds.length > 0){
                                    for(var obj in availBatchIds){
                                        if(obj == 0) availBatchIdsfilter = ' And ( Id = \''+availBatchIds[obj]+'\' ';
                                        else availBatchIdsfilter += ' Or Id = \''+availBatchIds[obj]+'\' ';
                                    }
                                    availBatchIdsfilter += ') ';
                                } else availBatchIdsfilter = ' AND Id = null ';
                                //availBatchIdsfilter += ' And Expired__c=false And Available_Quantity__c > 0 And Product__c = \''+component.get("v.item.Product__c")+'\' ';
                                
                                var availSerialIdsfilter = '';
                                var availSerialIds = [];
                                availSerialIds = response.getReturnValue().availSerialIds;
                                console.log('arshad availSerialIds list ~>'+availSerialIds);
                                if(availSerialIds.length > 0){
                                    for(var obj in availSerialIds){
                                        if(obj == 0) availSerialIdsfilter = ' And ( Id = \''+availSerialIds[obj]+'\' ';
                                        else availSerialIdsfilter += ' Or Id = \''+availSerialIds[obj]+'\' ';
                                    }
                                    availSerialIdsfilter += ') ';
                                } else availSerialIdsfilter = ' AND Id = null ';
                                //availSerialIdsfilter += ' And Expired__c=false And Product__c = \''+component.get("v.item.Product__c")+'\' AND Available__c = true ';
                                
                                console.log('arshad availLocIdsfilter~>'+availLocIdsfilter);
                                console.log('arshad availBatchIdsfilter~>'+availBatchIdsfilter);
                                console.log('arshad availSerialIdsfilter~>'+availSerialIdsfilter);
                                if(component.get('v.availLocIds') == '' || component.get('v.availLocIds') == null || component.get('v.availLocIds') == undefined) component.set('v.prodLocIds', availLocIdsfilter);
                                else component.set('v.prodLocIds', component.get('v.availLocIds'));
                                component.set('v.availLocIds', availLocIdsfilter);
                                
                                component.set('v.availBatchIds', availBatchIdsfilter);
                                component.set('v.availSerialIds', availSerialIdsfilter);
                                if(component.get("v.fromScanFlowforMultiPick")) component.set("v.callChangeLocation",component.get("v.item.From_Location__c")); //
                                component.set("v.showSpinnerItem",false);
                                component.set("v.proceedChangeHandler",true); 
                            }else {
                                console.log('Error fetchInventory:', response.getError());
                                component.set("v.showSpinnerItem",false);
                                component.set("v.proceedChangeHandler",true); 
                            }
                        }));
                        component.set("v.showSpinnerItem",false);
                        $A.enqueueAction(action);
                    }
                }
            }
            
            //console.log('item :',component.get('v.item'));
            
        }catch(err){
            console.log('err occured fetchInventory~>'+err.message);
            component.set("v.showSpinnerItem",false);
            component.set("v.proceedChangeHandler",true); 
        }
    },*/
    
})